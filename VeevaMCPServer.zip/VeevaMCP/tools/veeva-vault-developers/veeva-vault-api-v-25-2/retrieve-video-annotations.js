/**
 * Function to retrieve video annotations from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.doc_id - The video document ID.
 * @param {string} args.major_version - The major version number of the document.
 * @param {string} args.minor_version - The minor version number of the document.
 * @returns {Promise<Object>} - The result of the video annotations retrieval.
 */
const executeFunction = async ({ doc_id, major_version, minor_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/export-video-annotations`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving video annotations:', error);
    return {
      error: `An error occurred while retrieving video annotations: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving video annotations from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_video_annotations',
      description: 'Retrieve video annotations from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The video document ID.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the document.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the document.'
          }
        },
        required: ['doc_id', 'major_version', 'minor_version']
      }
    }
  }
};

export { apiTool };