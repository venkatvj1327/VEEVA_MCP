/**
 * Function to export documents from Veeva Vault.
 *
 * @param {Object} args - Arguments for the export.
 * @param {Array<Object>} args.documents - An array of document objects to export, each containing an `id`.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} [args.vaultDNS] - The DNS of the Vault.
 * @param {string} [args.version] - The API version.
 * @param {boolean} [args.source=true] - Optional: To exclude source files.
 * @param {boolean} [args.renditions=false] - Optional: To include renditions.
 * @param {boolean} [args.allversions=false] - Optional: To include all versions.
 * @returns {Promise<Object>} - The result of the export operation.
 */
const executeFunction = async ({ documents, sessionId, clientId, vaultDNS, version, source = true, renditions = false, allversions = false }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/batch/actions/fileextract`;
  const payload = documents;

  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  const queryParams = new URLSearchParams({
    source: source.toString(),
    renditions: renditions.toString(),
    allversions: allversions.toString()
  });

  try {
    const response = await fetch(`${url}?${queryParams}`, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error exporting documents:', error);
    return {
      error: `An error occurred while exporting documents: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for exporting documents from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'export_documents',
      description: 'Export a set of documents from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          documents: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                id: {
                  type: 'string',
                  description: 'The ID of the document to export.'
                }
              },
              required: ['id']
            },
            description: 'An array of document objects to export.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          },
          source: {
            type: 'boolean',
            description: 'Optional: To exclude source files.'
          },
          renditions: {
            type: 'boolean',
            description: 'Optional: To include renditions.'
          },
          allversions: {
            type: 'boolean',
            description: 'Optional: To include all versions.'
          }
        },
        required: ['documents', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };