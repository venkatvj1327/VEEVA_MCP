/**
 * Function to replace a document version rendition in Veeva Vault.
 *
 * @param {Object} args - Arguments for the document rendition replacement.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.major_version - The document major version number.
 * @param {string} args.minor_version - The document minor version number.
 * @param {string} args.rendition_type - The document rendition type.
 * @param {Buffer} args.file - The file to upload as the rendition.
 * @returns {Promise<Object>} - The result of the document rendition replacement.
 */
const executeFunction = async ({ doc_id, major_version, minor_version, rendition_type, file }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL with path variables
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/renditions/${rendition_type}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'multipart/form-data',
      'X-VaultAPI-ClientID': clientId,
    };

    // Create form data for the file upload
    const formData = new FormData();
    formData.append('file', file);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error replacing document version rendition:', error);
    return {
      error: `An error occurred while replacing the document version rendition: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for replacing a document version rendition in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'replace_document_version_rendition',
      description: 'Replace a document version rendition in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          major_version: {
            type: 'string',
            description: 'The document major version number.'
          },
          minor_version: {
            type: 'string',
            description: 'The document minor version number.'
          },
          rendition_type: {
            type: 'string',
            description: 'The document rendition type.'
          },
          file: {
            type: 'string',
            description: 'The file to upload as the rendition.'
          }
        },
        required: ['doc_id', 'major_version', 'minor_version', 'rendition_type', 'file']
      }
    }
  }
};

export { apiTool };