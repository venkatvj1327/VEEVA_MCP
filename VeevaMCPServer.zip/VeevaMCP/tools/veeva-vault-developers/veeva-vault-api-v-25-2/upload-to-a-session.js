/**
 * Function to upload a file part to a Veeva Vault session.
 *
 * @param {Object} args - Arguments for the upload.
 * @param {string} args.upload_session_id - The ID of the upload session.
 * @param {Buffer} args.filePart - The binary data of the file part to upload.
 * @param {number} args.partNumber - The part number for the file part being uploaded.
 * @param {string} [args.clientId] - Optional Client ID to identify the request.
 * @param {string} [args.sessionId] - The session ID for authorization.
 * @returns {Promise<Object>} - The result of the upload operation.
 */
const executeFunction = async ({ upload_session_id, filePart, partNumber, clientId, sessionId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/services/file_staging/upload/${upload_session_id}`;
  
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/octet-stream',
      'X-VaultAPI-FilePartNumber': partNumber.toString(),
      'X-VaultAPI-ClientID': clientId || ''
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: filePart
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error uploading file part:', error);
    return {
      error: `An error occurred while uploading the file part: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for uploading a file part to a Veeva Vault session.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'upload_to_session',
      description: 'Upload a file part to a Veeva Vault session.',
      parameters: {
        type: 'object',
        properties: {
          upload_session_id: {
            type: 'string',
            description: 'The ID of the upload session.'
          },
          filePart: {
            type: 'string',
            format: 'binary',
            description: 'The binary data of the file part to upload.'
          },
          partNumber: {
            type: 'integer',
            description: 'The part number for the file part being uploaded.'
          },
          clientId: {
            type: 'string',
            description: 'Optional Client ID to identify the request.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          }
        },
        required: ['upload_session_id', 'filePart', 'partNumber', 'sessionId']
      }
    }
  }
};

export { apiTool };