/**
 * Function to remove users and groups from roles on a single binder in Veeva Vault.
 *
 * @param {Object} args - Arguments for the removal.
 * @param {string} args.binder_id - The ID of the binder from which to remove roles.
 * @param {string} args.role_name_and_user_or_group - The name of the role from which to remove the user or group, formatted as `{role_name}.{user_or_group}`.
 * @param {string} args.id - The ID of the user or group to remove from the role.
 * @returns {Promise<Object>} - The result of the removal operation.
 */
const executeFunction = async ({ binder_id, role_name_and_user_or_group, id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/roles/${role_name_and_user_or_group}/${id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return an empty response or success message
    return {};
  } catch (error) {
    console.error('Error removing users and groups from roles:', error);
    return {
      error: `An error occurred while removing users and groups from roles: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for removing users and groups from roles on a single binder in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'remove_users_groups_from_role_single_binder',
      description: 'Remove users and groups from roles on a single binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder from which to remove roles.'
          },
          role_name_and_user_or_group: {
            type: 'string',
            description: 'The name of the role from which to remove the user or group, formatted as `{role_name}.{user_or_group}`.'
          },
          id: {
            type: 'string',
            description: 'The ID of the user or group to remove from the role.'
          }
        },
        required: ['binder_id', 'role_name_and_user_or_group', 'id']
      }
    }
  }
};

export { apiTool };