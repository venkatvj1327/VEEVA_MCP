/**
 * Function to delete lifecycle role assignment override rules in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the API request.
 * @returns {Promise<Object>} - The result of the deletion request.
 */
const executeFunction = async ({ vaultDNS, version, sessionId, clientId }) => {
  const url = `https://${vaultDNS}/api/${version}/configuration/role_assignment_rule`;
  const token = process.env.VEEVA_VAULT_DEVELOPERS_API_KEY;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response data
    return await response.json();
  } catch (error) {
    console.error('Error deleting lifecycle role assignment override rules:', error);
    return {
      error: `An error occurred while deleting override rules: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting lifecycle role assignment override rules in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_lifecycle_role_assignment_override_rules',
      description: 'Delete lifecycle role assignment override rules in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the API request.'
          }
        },
        required: ['vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };