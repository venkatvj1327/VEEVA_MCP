/**
 * Function to get details of an active upload session in Veeva Vault.
 *
 * @param {Object} args - Arguments for the upload session details.
 * @param {string} args.upload_session_id - The ID of the upload session to retrieve details for.
 * @returns {Promise<Object>} - The details of the upload session.
 */
const executeFunction = async ({ upload_session_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/services/file_staging/upload/${upload_session_id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving upload session details:', error);
    return {
      error: `An error occurred while retrieving upload session details: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for getting upload session details in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'get_upload_session_details',
      description: 'Retrieve details of an active upload session in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          upload_session_id: {
            type: 'string',
            description: 'The ID of the upload session to retrieve details for.'
          }
        },
        required: ['upload_session_id']
      }
    }
  }
};

export { apiTool };