/**
 * Function to update the binding rule for a specified binder in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update binding rule.
 * @param {string} args.binder_id - The ID of the binder to update.
 * @param {string} [args.binding_rule='default'] - Indicates which binding rule to apply.
 * @param {boolean} [args.binding_rule_override=true] - Indicates if the specified binding rule should override existing rules.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ binder_id, binding_rule = 'default', binding_rule_override = true }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/binding_rule`;

    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId,
    };

    const body = new URLSearchParams();
    body.append('binding_rule__v', binding_rule);
    body.append('binding_rule_override__v', binding_rule_override.toString());

    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: body.toString(),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating binding rule:', error);
    return {
      error: `An error occurred while updating the binding rule: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating binding rules in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_binding_rule',
      description: 'Update the binding rule for a specified binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder to update.'
          },
          binding_rule: {
            type: 'string',
            description: 'Indicates which binding rule to apply.'
          },
          binding_rule_override: {
            type: 'boolean',
            description: 'Indicates if the specified binding rule should override existing rules.'
          }
        },
        required: ['binder_id']
      }
    }
  }
};

export { apiTool };