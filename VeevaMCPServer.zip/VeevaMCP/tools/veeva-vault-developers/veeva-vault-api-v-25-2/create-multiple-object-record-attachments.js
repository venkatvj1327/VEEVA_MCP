/**
 * Function to create multiple object record attachments in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating attachments.
 * @param {string} args.object_name - The object name__v field value (e.g., product__v, country__v).
 * @param {Buffer} args.fileData - The binary data of the file to be uploaded.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @returns {Promise<Object>} - The result of the attachment creation.
 */
const executeFunction = async ({ object_name, fileData, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/attachments/batch`;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: fileData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating attachments:', error);
    return {
      error: `An error occurred while creating attachments: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating multiple object record attachments in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_multiple_object_record_attachments',
      description: 'Create multiple object record attachments in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name__v field value (e.g., product__v, country__v).'
          },
          fileData: {
            type: 'string',
            format: 'binary',
            description: 'The binary data of the file to be uploaded.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          }
        },
        required: ['object_name', 'fileData', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };