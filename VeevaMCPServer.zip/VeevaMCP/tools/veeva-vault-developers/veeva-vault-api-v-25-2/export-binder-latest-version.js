/**
 * Function to export the latest version of a binder from Veeva Vault.
 *
 * @param {Object} args - Arguments for the export.
 * @param {string} args.binder_id - The ID of the binder to export.
 * @param {boolean} [args.source=true] - Whether to include source content.
 * @param {string} [args.renditiontype='viewable_rendition__v'] - The type of rendition to include.
 * @param {string} [args.docversion='major'] - The version of documents to include.
 * @param {string} [args.attachments='all'] - The version of attachments to include.
 * @param {string} [args.export='name__v,title__v,document_number__v'] - Configurable filename metadata.
 * @param {boolean} [args.docfield=false] - Whether to exclude document metadata CSV.
 * @returns {Promise<Object>} - The result of the export request.
 */
const executeFunction = async ({ binder_id, source = true, renditiontype = 'viewable_rendition__v', docversion = 'major', attachments = 'all', docfield = false, export_detials = 'name__v,title__v,document_number__v' }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL with the binder ID
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/actions/export`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Construct the query parameters
    const queryParams = new URLSearchParams({
      source,
      renditiontype,
      docversion,
      attachments,
      export_detials,
      docfield
    });

    // Perform the fetch request
    const response = await fetch(`${url}?${queryParams}`, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error exporting binder:', error);
    return {
      error: `An error occurred while exporting the binder: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for exporting a binder from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'export_binder',
      description: 'Export the latest version of a binder from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder to export.'
          },
          source: {
            type: 'boolean',
            description: 'Whether to include source content.'
          },
          renditiontype: {
            type: 'string',
            description: 'The type of rendition to include.'
          },
          docversion: {
            type: 'string',
            description: 'The version of documents to include.'
          },
          attachments: {
            type: 'string',
            description: 'The version of attachments to include.'
          },
          export: {
            type: 'string',
            description: 'Configurable filename metadata.'
          },
          docfield: {
            type: 'boolean',
            description: 'Whether to exclude document metadata CSV.'
          }
        },
        required: ['binder_id']
      }
    }
  }
};

export { apiTool };