/**
 * Function to create an object record attachment in Veeva Vault.
 *
 * @param {Object} args - Arguments for the attachment creation.
 * @param {string} args.object_name - The object name (e.g., product__v, country__v).
 * @param {string} args.object_record_id - The object record ID.
 * @param {Buffer} args.file - The file to be uploaded as an attachment.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version.
 * @returns {Promise<Object>} - The result of the attachment creation.
 */
const executeFunction = async ({ object_name, object_record_id, file, sessionId, clientId, vaultDNS, version }) => {
  const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/attachments`;
  
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating object record attachment:', error);
    return {
      error: `An error occurred while creating the attachment: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating object record attachments in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_object_record_attachment',
      description: 'Create an object record attachment in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name (e.g., product__v, country__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The object record ID.'
          },
          file: {
            type: 'string',
            description: 'The file to be uploaded as an attachment.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          }
        },
        required: ['object_name', 'object_record_id', 'file', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };