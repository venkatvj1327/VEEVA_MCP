/**
 * Function to add a single document rendition to Veeva Vault.
 *
 * @param {Object} args - Arguments for the document rendition.
 * @param {string} args.doc_id - The document ID to which the rendition will be added.
 * @param {string} args.rendition_type - The type of the document rendition.
 * @param {Buffer} args.file - The file to be uploaded as the document rendition.
 * @returns {Promise<Object>} - The result of the document rendition upload.
 */
const executeFunction = async ({ doc_id, rendition_type, file }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/renditions/${rendition_type}`;

    const formData = new FormData();
    formData.append('file', file);

    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error adding document rendition:', error);
    return {
      error: `An error occurred while adding the document rendition: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for adding a single document rendition to Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'add_document_rendition',
      description: 'Add a single document rendition to Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID to which the rendition will be added.'
          },
          rendition_type: {
            type: 'string',
            description: 'The type of the document rendition.'
          },
          file: {
            type: 'string',
            description: 'The file to be uploaded as the document rendition.'
          }
        },
        required: ['doc_id', 'rendition_type', 'file']
      }
    }
  }
};

export { apiTool };