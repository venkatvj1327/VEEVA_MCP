/**
 * Function to retrieve document workflow details from Veeva Vault API.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.workflow_name - The name of the document workflow to retrieve details for.
 * @param {boolean} [args.loc=false] - When set to true, retrieves localized (translated) strings if available.
 * @returns {Promise<Object>} - The result of the document workflow retrieval.
 */
const executeFunction = async ({ workflow_name, loc = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/documents/actions/${workflow_name}`);
    if (loc) {
      url.searchParams.append('loc', 'true');
    }

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving document workflow details:', error);
    return {
      error: `An error occurred while retrieving document workflow details: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document workflow details from Veeva Vault API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_workflow_details',
      description: 'Retrieve details for a specific document workflow from Veeva Vault API.',
      parameters: {
        type: 'object',
        properties: {
          workflow_name: {
            type: 'string',
            description: 'The name of the document workflow to retrieve details for.'
          },
          loc: {
            type: 'boolean',
            description: 'When set to true, retrieves localized (translated) strings if available.'
          }
        },
        required: ['workflow_name']
      }
    }
  }
};

export { apiTool };