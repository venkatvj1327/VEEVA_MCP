/**
 * Function to retrieve workflow task details from Veeva Vault.
 *
 * @param {Object} args - Arguments for the task retrieval.
 * @param {string} args.task_id - The ID of the workflow task to retrieve.
 * @param {boolean} [args.loc=false] - When true, retrieve localized (translated) strings.
 * @returns {Promise<Object>} - The details of the workflow task.
 */
const executeFunction = async ({ task_id, loc = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  
  try {
    // Construct the URL with the task ID and query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/objectworkflows/tasks/${task_id}`);
    if (loc) {
      url.searchParams.append('loc', 'true');
    }

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving workflow task details:', error);
    return {
      error: `An error occurred while retrieving workflow task details: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving workflow task details from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_workflow_task_details',
      description: 'Retrieve details of a specific workflow task from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          task_id: {
            type: 'string',
            description: 'The ID of the workflow task to retrieve.'
          },
          loc: {
            type: 'boolean',
            description: 'When true, retrieve localized (translated) strings.'
          }
        },
        required: ['task_id']
      }
    }
  }
};

export { apiTool };