/**
 * Function to update multiple object record attachment descriptions in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.object_name - The object name (e.g., product__v, country__v).
 * @param {Buffer} args.fileData - The CSV file data to be uploaded.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ object_name, fileData, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/attachments/batch`;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: fileData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating attachment descriptions:', error);
    return {
      error: `An error occurred while updating attachment descriptions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating multiple object record attachment descriptions in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_multiple_attachment_descriptions',
      description: 'Update multiple object record attachment descriptions in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name (e.g., product__v, country__v).'
          },
          fileData: {
            type: 'string',
            description: 'The CSV file data to be uploaded.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['object_name', 'fileData', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };