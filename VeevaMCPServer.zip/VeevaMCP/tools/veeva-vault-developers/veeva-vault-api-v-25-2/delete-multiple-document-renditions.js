/**
 * Function to delete multiple document renditions in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version.
 * @param {Buffer} args.fileData - The CSV file data to be sent in the request body.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, fileData }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/renditions/batch`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers,
      body: fileData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error deleting document renditions:', error);
    return {
      error: `An error occurred while deleting document renditions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting multiple document renditions in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_multiple_document_renditions',
      description: 'Delete multiple document renditions in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          },
          fileData: {
            type: 'string',
            description: 'The CSV file data to be sent in the request body.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version', 'fileData']
      }
    }
  }
};

export { apiTool };