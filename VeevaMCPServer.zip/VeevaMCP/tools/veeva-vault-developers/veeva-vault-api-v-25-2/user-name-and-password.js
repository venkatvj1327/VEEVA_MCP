/**
 * Function to authenticate a user with Veeva Vault using username and password.
 *
 * @param {Object} args - Arguments for the authentication.
 * @param {string} args.username - The Vault user name assigned by your administrator.
 * @param {string} args.password - The Vault password associated with your assigned vault user name.
 * @param {string} [args.vaultDNS] - Optional: The DNS of the Vault for which you want to generate a session.
 * @param {string} [args.clientId] - Optional: Client ID to identify this request.
 * @returns {Promise<Object>} - The result of the authentication request.
 */
const executeFunction = async ({ username, password, vaultDNS, clientId }) => {
  const baseUrl = `https://${vaultDNS}/api`;
  const version = 'v25.2'; // Assuming version is fixed as per the request
  const url = `${baseUrl}/${version}/auth`;
  
  const headers = {
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId || ''
  };

  const body = new URLSearchParams();
  body.append('username', username);
  body.append('password', password);
  
  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error authenticating user:', error);
    return {
      error: `An error occurred while authenticating: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for authenticating a user with Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'authenticate_user',
      description: 'Authenticate a user with Veeva Vault using username and password.',
      parameters: {
        type: 'object',
        properties: {
          username: {
            type: 'string',
            description: 'The Vault user name assigned by your administrator.'
          },
          password: {
            type: 'string',
            description: 'The Vault password associated with your assigned vault user name.'
          },
          vaultDNS: {
            type: 'string',
            description: 'Optional: The DNS of the Vault for which you want to generate a session.'
          },
          clientId: {
            type: 'string',
            description: 'Optional: Client ID to identify this request.'
          }
        },
        required: ['username', 'password']
      }
    }
  }
};

export { apiTool };