/**
 * Function to retrieve all users from Veeva Vault.
 *
 * @param {Object} args - Arguments for the user retrieval.
 * @param {string} args.vaults - Comma-separated list of Vault IDs to filter users (optional).
 * @param {boolean} args.exclude_vault_membership - Set to false to include vault_membership fields (optional).
 * @param {boolean} args.exclude_app_licensing - Set to false to include app_licensing fields (optional).
 * @returns {Promise<Object>} - The result of the user retrieval.
 */
const executeFunction = async ({ vaults = '', exclude_vault_membership = true, exclude_app_licensing = true }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/users/`);
    if (vaults) url.searchParams.append('vaults', vaults);
    if (exclude_vault_membership !== undefined) url.searchParams.append('exclude_vault_membership', exclude_vault_membership);
    if (exclude_app_licensing !== undefined) url.searchParams.append('exclude_app_licensing', exclude_app_licensing);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving users:', error);
    return {
      error: `An error occurred while retrieving users: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving all users from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_all_users',
      description: 'Retrieve all users from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaults: {
            type: 'string',
            description: 'Comma-separated list of Vault IDs to filter users.'
          },
          exclude_vault_membership: {
            type: 'boolean',
            description: 'Set to false to include vault_membership fields.'
          },
          exclude_app_licensing: {
            type: 'boolean',
            description: 'Set to false to include app_licensing fields.'
          }
        }
      }
    }
  }
};

export { apiTool };