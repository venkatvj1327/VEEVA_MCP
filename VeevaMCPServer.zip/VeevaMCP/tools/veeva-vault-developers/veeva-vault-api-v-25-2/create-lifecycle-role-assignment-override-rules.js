/**
 * Function to create lifecycle role assignment override rules in Veeva Vault.
 *
 * @param {Object} args - Arguments for the override rule creation.
 * @param {string} args.name__v - The name__v field values of the lifecycle and role to which the override rule is being added.
 * @param {string} [args.allowedGroups] - The name__v field values of the allowed and default groups who will be assigned to the role when the override condition is met.
 * @param {string} [args.overrideConditionId] - The id or name__v field values of the object records which define the override condition.
 * @param {string} [args.allowedUsers] - The user_name__v field values of the allowed and default users who will be assigned to the role when the override condition is met.
 * @returns {Promise<Object>} - The result of the override rule creation.
 */
const executeFunction = async ({ name__v, allowedGroups = '', overrideConditionId = '', allowedUsers = '' }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/configuration/role_assignment_rule`;

  // Prepare the form data
  const formData = new URLSearchParams();
  formData.append('name__v', name__v);
  if (allowedGroups) formData.append('allowed_groups__v', allowedGroups);
  if (overrideConditionId) formData.append('id', overrideConditionId);
  if (allowedUsers) formData.append('user_name__v', allowedUsers);

  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating lifecycle role assignment override rules:', error);
    return {
      error: `An error occurred while creating the override rules: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating lifecycle role assignment override rules in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_lifecycle_role_assignment_override_rules',
      description: 'Create lifecycle role assignment override rules in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          name__v: {
            type: 'string',
            description: 'The name__v field values of the lifecycle and role to which the override rule is being added.'
          },
          allowedGroups: {
            type: 'string',
            description: 'The name__v field values of the allowed and default groups who will be assigned to the role when the override condition is met.'
          },
          overrideConditionId: {
            type: 'string',
            description: 'The id or name__v field values of the object records which define the override condition.'
          },
          allowedUsers: {
            type: 'string',
            description: 'The user_name__v field values of the allowed and default users who will be assigned to the role when the override condition is met.'
          }
        },
        required: ['name__v']
      }
    }
  }
};

export { apiTool };