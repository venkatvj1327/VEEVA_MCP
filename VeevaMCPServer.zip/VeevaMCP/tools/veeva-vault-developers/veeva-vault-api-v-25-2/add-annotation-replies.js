/**
 * Function to add annotation replies in Veeva Vault.
 *
 * @param {Object} args - Arguments for adding annotation replies.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {Array<Object>} args.replies - An array of annotation reply objects to be added.
 * @returns {Promise<Object>} - The result of the annotation replies addition.
 */
const executeFunction = async ({ sessionId, clientId, replies }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/objects/documents/annotations/replies/batch`;

  const body = JSON.stringify(replies);
  
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error adding annotation replies:', error);
    return {
      error: `An error occurred while adding annotation replies: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for adding annotation replies in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'add_annotation_replies',
      description: 'Add annotation replies in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          replies: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                document_version_id__sys: { type: 'string' },
                type__sys: { type: 'string' },
                comment__sys: { type: 'string' },
                placemark: {
                  type: 'object',
                  properties: {
                    type__sys: { type: 'string' },
                    reply_parent__sys: { type: 'string' }
                  },
                  required: ['type__sys', 'reply_parent__sys']
                }
              },
              required: ['document_version_id__sys', 'type__sys', 'comment__sys', 'placemark']
            },
            description: 'An array of annotation reply objects to be added.'
          }
        },
        required: ['sessionId', 'clientId', 'replies']
      }
    }
  }
};

export { apiTool };