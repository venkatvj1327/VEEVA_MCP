/**
 * Function to delete a file or folder from the Veeva Vault file staging server.
 *
 * @param {Object} args - Arguments for the delete request.
 * @param {string} args.item - The absolute path to the file or folder to delete.
 * @param {boolean} [args.recursive=false] - If true, deletes the contents of a folder and all subfolders (applicable to folders only).
 * @returns {Promise<Object>} - The result of the delete operation.
 */
const executeFunction = async ({ item, recursive = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the delete request
    const url = `https://${vaultDNS}/api/${version}/services/file_staging/items/${encodeURIComponent(item)}`;
    
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Set up query parameters
    const params = new URLSearchParams();
    if (recursive) {
      params.append('recursive', 'true');
    }

    // Perform the fetch request
    const response = await fetch(`${url}?${params.toString()}`, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response data
    return await response.json();
  } catch (error) {
    console.error('Error deleting file or folder:', error);
    return {
      error: `An error occurred while deleting the file or folder: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting a file or folder from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_file_or_folder',
      description: 'Delete a file or folder from the Veeva Vault file staging server.',
      parameters: {
        type: 'object',
        properties: {
          item: {
            type: 'string',
            description: 'The absolute path to the file or folder to delete.'
          },
          recursive: {
            type: 'boolean',
            description: 'If true, deletes the contents of a folder and all subfolders (applicable to folders only).'
          }
        },
        required: ['item']
      }
    }
  }
};

export { apiTool };