/**
 * Function to undo collaborative authoring checkout on documents in Veeva Vault.
 *
 * @param {Object} args - Arguments for the undo checkout.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @param {Array<string>} args.ids - The list of document IDs to undo checkout for.
 * @returns {Promise<Object>} - The response from the Veeva Vault API.
 */
const executeFunction = async ({ sessionId, clientId, ids }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/objects/documents/batch/lock`;
  
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'text/csv',
    'X-VaultAPI-ClientID': clientId
  };

  // Prepare the body as CSV format
  const body = `id\n${ids.join('\n')}`;

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error undoing collaborative authoring checkout:', error);
    return {
      error: `An error occurred while undoing checkout: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for undoing collaborative authoring checkout on documents in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'undo_collaborative_authoring_checkout',
      description: 'Undo collaborative authoring checkout on documents in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          ids: {
            type: 'array',
            items: {
              type: 'string'
            },
            description: 'The list of document IDs to undo checkout for.'
          }
        },
        required: ['sessionId', 'clientId', 'ids']
      }
    }
  }
};

export { apiTool };