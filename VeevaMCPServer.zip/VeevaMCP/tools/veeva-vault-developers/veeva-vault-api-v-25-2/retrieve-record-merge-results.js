/**
 * Function to retrieve record merge results from Veeva Vault API.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.job_id - The job ID for the merge records job.
 * @param {string} [args.vaultDNS] - The DNS of the Veeva Vault.
 * @param {string} [args.version] - The API version to use.
 * @param {string} [args.sessionId] - The session ID for authorization.
 * @param {string} [args.clientId] - The client ID for the request.
 * @returns {Promise<Object>} - The result of the record merge results retrieval.
 */
const executeFunction = async ({ job_id, vaultDNS, version, sessionId = '', clientId = '' }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/vobjects/merges/${job_id}/results`;
  
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving record merge results:', error);
    return {
      error: `An error occurred while retrieving record merge results: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving record merge results from Veeva Vault API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_record_merge_results',
      description: 'Retrieve results of a record merge job from Veeva Vault API.',
      parameters: {
        type: 'object',
        properties: {
          job_id: {
            type: 'string',
            description: 'The job ID for the merge records job.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['job_id', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };