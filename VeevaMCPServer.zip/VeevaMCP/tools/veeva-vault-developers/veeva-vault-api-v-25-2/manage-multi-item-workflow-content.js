/**
 * Function to manage multi-item workflow content in Veeva Vault.
 *
 * @param {Object} args - Arguments for managing workflow content.
 * @param {string} args.task_id - The ID of the workflow task.
 * @param {Array} args.contents - An array of content objects to manage.
 * @returns {Promise<Object>} - The response from the Veeva Vault API.
 */
const executeFunction = async ({ task_id, contents }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/objectworkflows/tasks/${task_id}/actions/mdwmanagecontent`;

    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    const body = JSON.stringify({ contents__sys: contents });

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error managing multi-item workflow content:', error);
    return {
      error: `An error occurred while managing workflow content: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for managing multi-item workflow content in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'manage_multi_item_workflow_content',
      description: 'Manage content in a multi-item workflow in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          task_id: {
            type: 'string',
            description: 'The ID of the workflow task.'
          },
          contents: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                object__v: {
                  type: 'string',
                  description: 'The object type.'
                },
                record_id__v: {
                  type: 'string',
                  description: 'The record ID of the object.'
                },
                verdict_public_key__c: {
                  type: 'string',
                  description: 'The verdict name.'
                },
                verdict_not_approved_comment__c: {
                  type: 'string',
                  description: 'Comment for not approved verdict.'
                }
              },
              required: ['object__v', 'record_id__v']
            },
            description: 'An array of content objects to manage.'
          }
        },
        required: ['task_id', 'contents']
      }
    }
  }
};

export { apiTool };