/**
 * Function to create a resumable upload session in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating the upload session.
 * @param {string} args.path - The absolute path, including file name, to place the file in the staging server.
 * @param {number} args.size - The size of the file in bytes.
 * @param {boolean} [args.overwrite=false] - If set to true, Vault will overwrite any existing files with the same name at the specified destination.
 * @returns {Promise<Object>} - The result of the upload session creation.
 */
const executeFunction = async ({ path, size, overwrite = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/services/file_staging/upload`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId,
      'Content-Type': 'application/x-www-form-urlencoded'
    };

    // Prepare the body data
    const body = new URLSearchParams();
    body.append('path', path);
    body.append('size', size.toString());
    if (overwrite) {
      body.append('overwrite', 'true');
    }

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating upload session:', error);
    return {
      error: `An error occurred while creating the upload session: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a resumable upload session in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_resumable_upload_session',
      description: 'Create a resumable upload session in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          path: {
            type: 'string',
            description: 'The absolute path, including file name, to place the file in the staging server.'
          },
          size: {
            type: 'number',
            description: 'The size of the file in bytes.'
          },
          overwrite: {
            type: 'boolean',
            description: 'If set to true, Vault will overwrite any existing files with the same name at the specified destination.'
          }
        },
        required: ['path', 'size']
      }
    }
  }
};

export { apiTool };