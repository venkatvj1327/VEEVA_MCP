/**
 * Function to load data objects into Veeva Vault.
 *
 * @param {Object} args - Arguments for loading data objects.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {Array<Object>} args.dataObjects - The data objects to load.
 * @returns {Promise<Object>} - The result of the load data objects operation.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, dataObjects }) => {
  const url = `https://${vaultDNS}/api/${version}/services/loader/load`;
  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId,
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(dataObjects),
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error loading data objects:', error);
    return {
      error: `An error occurred while loading data objects: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for loading data objects into Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'load_data_objects',
      description: 'Load data objects into Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          dataObjects: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                object_type: { type: 'string' },
                action: { type: 'string' },
                file: { type: 'string' },
                order: { type: 'integer' },
                object: { type: 'string', nullable: true },
                idparam: { type: 'string', nullable: true },
                recordmigrationmode: { type: 'boolean', nullable: true }
              },
              required: ['object_type', 'action', 'file', 'order']
            },
            description: 'The data objects to load.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version', 'dataObjects']
      }
    }
  }
};

export { apiTool };