/**
 * Function to create a new section in a binder using the Veeva Vault API.
 *
 * @param {Object} args - Arguments for creating the binder section.
 * @param {string} args.binder_id - The ID of the binder where the section will be created.
 * @param {string} args.name__v - The name for the new section (required).
 * @param {string} [args.section_number__v] - The numerical value for the new section (optional).
 * @param {string} [args.parent_id__v] - The Node ID of the parent section (optional).
 * @param {number} [args.order__v] - The position of the section within the binder (optional).
 * @returns {Promise<Object>} - The result of the section creation.
 */
const executeFunction = async ({ binder_id, name__v, section_number__v, parent_id__v, order__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/sections`;

    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    const body = new URLSearchParams();
    body.append('name__v', name__v);
    if (section_number__v) body.append('section_number__v', section_number__v);
    if (parent_id__v) body.append('parent_id__v', parent_id__v);
    if (order__v) body.append('order__v', order__v);

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating binder section:', error);
    return {
      error: `An error occurred while creating the binder section: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a binder section in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_binder_section',
      description: 'Create a new section in a binder.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder where the section will be created.'
          },
          name__v: {
            type: 'string',
            description: 'The name for the new section (required).'
          },
          section_number__v: {
            type: 'string',
            description: 'The numerical value for the new section (optional).'
          },
          parent_id__v: {
            type: 'string',
            description: 'The Node ID of the parent section (optional).'
          },
          order__v: {
            type: 'number',
            description: 'The position of the section within the binder (optional).'
          }
        },
        required: ['binder_id', 'name__v']
      }
    }
  }
};

export { apiTool };