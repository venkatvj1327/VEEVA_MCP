/**
 * Function to delete object records in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.object_name - The name of the object to delete records from.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @param {string} args.vaultDNS - The DNS for the Veeva Vault instance.
 * @param {string} args.version - The API version to use.
 * @param {string} args.csvData - The CSV data containing the records to delete.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ object_name, sessionId, clientId, vaultDNS, version, csvData }) => {
  const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'text/csv',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers,
      body: csvData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error deleting object records:', error);
    return {
      error: `An error occurred while deleting object records: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting object records in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_object_records',
      description: 'Delete object records in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object to delete records from.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS for the Veeva Vault instance.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          csvData: {
            type: 'string',
            description: 'The CSV data containing the records to delete.'
          }
        },
        required: ['object_name', 'sessionId', 'clientId', 'vaultDNS', 'version', 'csvData']
      }
    }
  }
};

export { apiTool };