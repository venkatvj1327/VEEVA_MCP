/**
 * Function to retrieve deleted document IDs from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} [args.start_date] - Specify a date after which Vault will look for deleted documents (format: YYYY-MM-DDTHH:MM:SSZ).
 * @param {string} [args.end_date] - Specify a date before which Vault will look for deleted documents (format: YYYY-MM-DDTHH:MM:SSZ).
 * @returns {Promise<Object>} - The result of the retrieval of deleted document IDs.
 */
const executeFunction = async ({ start_date = '', end_date = '' }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/deletions/documents`);
    if (start_date) url.searchParams.append('start_date', start_date);
    if (end_date) url.searchParams.append('end_date', end_date);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId,
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving deleted document IDs:', error);
    return {
      error: `An error occurred while retrieving deleted document IDs: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving deleted document IDs from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_deleted_documents',
      description: 'Retrieve IDs of documents deleted within the past 30 days.',
      parameters: {
        type: 'object',
        properties: {
          start_date: {
            type: 'string',
            description: 'Specify a date after which Vault will look for deleted documents (format: YYYY-MM-DDTHH:MM:SSZ).'
          },
          end_date: {
            type: 'string',
            description: 'Specify a date before which Vault will look for deleted documents (format: YYYY-MM-DDTHH:MM:SSZ).'
          }
        }
      }
    }
  }
};

export { apiTool };