/**
 * Function to update the binder section binding rule in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.binder_id - The ID of the binder to update.
 * @param {string} args.node_id - The ID of the node to update.
 * @param {string} [args.binding_rule_v='default'] - The binding rule version.
 * @param {boolean} [args.binding_rule_override_v=true] - Whether to override the binding rule.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ binder_id, node_id, binding_rule_v = 'default', binding_rule_override_v = true }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/sections/${node_id}/binding_rule`;

    // Set up headers for the request
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body data
    const bodyData = new URLSearchParams();
    bodyData.append('binding_rule__v', binding_rule_v);
    bodyData.append('binding_rule_override__v', binding_rule_override_v);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: bodyData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating binder section binding rule:', error);
    return {
      error: `An error occurred while updating the binder section binding rule: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating the binder section binding rule in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_binder_section_binding_rule',
      description: 'Update the binder section binding rule in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder to update.'
          },
          node_id: {
            type: 'string',
            description: 'The ID of the node to update.'
          },
          binding_rule_v: {
            type: 'string',
            description: 'The binding rule version.'
          },
          binding_rule_override_v: {
            type: 'boolean',
            description: 'Whether to override the binding rule.'
          }
        },
        required: ['binder_id', 'node_id']
      }
    }
  }
};

export { apiTool };