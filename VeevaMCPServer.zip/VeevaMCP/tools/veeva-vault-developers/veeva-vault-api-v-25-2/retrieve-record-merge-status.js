/**
 * Function to retrieve the status of a record merge job in Veeva Vault.
 *
 * @param {Object} args - Arguments for the status retrieval.
 * @param {string} args.job_id - The job_id field value returned from the merge operation.
 * @returns {Promise<Object>} - The result of the job status retrieval.
 */
const executeFunction = async ({ job_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  
  try {
    // Construct the URL for the API request
    const url = `https://${vaultDNS}/api/${version}/vobjects/merges/${job_id}/status`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving merge job status:', error);
    return {
      error: `An error occurred while retrieving the merge job status: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving record merge job status in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_record_merge_status',
      description: 'Retrieve the status of a record merge job in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          job_id: {
            type: 'string',
            description: 'The job_id field value returned from the merge operation.'
          }
        },
        required: ['job_id']
      }
    }
  }
};

export { apiTool };