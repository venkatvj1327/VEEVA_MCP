/**
 * Function to update the description of an object record attachment in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.object_name - The name of the object (e.g., product__v, country__v).
 * @param {string} args.object_record_id - The ID of the object record to update.
 * @param {string} args.attachment_id - The ID of the attachment to update.
 * @param {string} args.description__v - The new description for the attachment (max 1000 characters).
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ object_name, object_record_id, attachment_id, description__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/attachments/${attachment_id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Create the body for the request
    const body = JSON.stringify({ description__v });

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating attachment description:', error);
    return {
      error: `An error occurred while updating the attachment description: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating object record attachment description in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_attachment_description',
      description: 'Update the description of an object record attachment in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object (e.g., product__v, country__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The ID of the object record to update.'
          },
          attachment_id: {
            type: 'string',
            description: 'The ID of the attachment to update.'
          },
          description__v: {
            type: 'string',
            description: 'The new description for the attachment (max 1000 characters).'
          }
        },
        required: ['object_name', 'object_record_id', 'attachment_id', 'description__v']
      }
    }
  }
};

export { apiTool };