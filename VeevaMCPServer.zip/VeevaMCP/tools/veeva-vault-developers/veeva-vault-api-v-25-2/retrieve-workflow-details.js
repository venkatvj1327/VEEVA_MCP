/**
 * Function to retrieve workflow details from Veeva Vault API.
 *
 * @param {Object} args - Arguments for the workflow retrieval.
 * @param {string} args.workflow_id - The ID of the workflow to retrieve details for.
 * @param {boolean} [args.loc=false] - When true, retrieves localized (translated) strings if available.
 * @returns {Promise<Object>} - The details of the specified workflow.
 */
const executeFunction = async ({ workflow_id, loc = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with the workflow ID
    const url = `https://${vaultDNS}/api/${version}/objects/objectworkflows/${workflow_id}`;
    
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Append query parameters if loc is true
    const queryParams = new URLSearchParams();
    if (loc) {
      queryParams.append('loc', 'true');
    }

    // Perform the fetch request
    const response = await fetch(`${url}?${queryParams.toString()}`, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving workflow details:', error);
    return {
      error: `An error occurred while retrieving workflow details: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving workflow details from Veeva Vault API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_workflow_details',
      description: 'Retrieve details for a specific object workflow from Veeva Vault API.',
      parameters: {
        type: 'object',
        properties: {
          workflow_id: {
            type: 'string',
            description: 'The ID of the workflow to retrieve details for.'
          },
          loc: {
            type: 'boolean',
            description: 'When true, retrieves localized (translated) strings if available.'
          }
        },
        required: ['workflow_id']
      }
    }
  }
};

export { apiTool };