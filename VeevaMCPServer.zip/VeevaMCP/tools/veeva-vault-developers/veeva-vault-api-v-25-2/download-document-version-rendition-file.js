/**
 * Function to download a rendition for a specified version of a document from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.doc_id - The document id field value.
 * @param {string} args.major_version - The document major version number.
 * @param {string} args.minor_version - The document minor version number.
 * @param {string} args.rendition_type - The document rendition type.
 * @returns {Promise<Object>} - The result of the download request.
 */
const executeFunction = async ({ doc_id, major_version, minor_version, rendition_type }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path parameters
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/renditions/${rendition_type}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading document rendition:', error);
    return {
      error: `An error occurred while downloading the document rendition: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading document version rendition file from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_document_rendition',
      description: 'Download a rendition for a specified version of a document from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document id field value.'
          },
          major_version: {
            type: 'string',
            description: 'The document major version number.'
          },
          minor_version: {
            type: 'string',
            description: 'The document minor version number.'
          },
          rendition_type: {
            type: 'string',
            description: 'The document rendition type.'
          }
        },
        required: ['doc_id', 'major_version', 'minor_version', 'rendition_type']
      }
    }
  }
};

export { apiTool };