/**
 * Function to read annotations by document version and type from Veeva Vault.
 *
 * @param {Object} args - Arguments for the annotation retrieval.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.doc_id - The document ID to retrieve annotations for.
 * @param {string} args.major_version - The major version of the document.
 * @param {string} args.minor_version - The minor version of the document.
 * @param {string} [args.sessionId=''] - The session ID for authentication.
 * @param {string} [args.clientId=''] - The client ID for API usage logs.
 * @param {number} [args.limit=500] - The maximum number of records per page.
 * @param {number} [args.offset=0] - The offset for pagination.
 * @param {string} [args.annotation_types=''] - The types of annotations to retrieve.
 * @returns {Promise<Object>} - The result of the annotation retrieval.
 */
const executeFunction = async ({ vaultDNS, version, doc_id, major_version, minor_version, sessionId = '', clientId = '', limit = 500, offset = 0, annotation_types = '' }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/annotations`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Construct the URL with query parameters
    const url = new URL(baseUrl);
    if (limit) url.searchParams.append('limit', limit);
    if (offset) url.searchParams.append('offset', offset);
    if (annotation_types) url.searchParams.append('annotation_types', annotation_types);

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error reading annotations:', error);
    return {
      error: `An error occurred while reading annotations: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for reading annotations from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'read_annotations',
      description: 'Read annotations by document version and type from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          doc_id: {
            type: 'string',
            description: 'The document ID to retrieve annotations for.'
          },
          major_version: {
            type: 'string',
            description: 'The major version of the document.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version of the document.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for API usage logs.'
          },
          limit: {
            type: 'integer',
            description: 'The maximum number of records per page.'
          },
          offset: {
            type: 'integer',
            description: 'The offset for pagination.'
          },
          annotation_types: {
            type: 'string',
            description: 'The types of annotations to retrieve.'
          }
        },
        required: ['vaultDNS', 'version', 'doc_id', 'major_version', 'minor_version']
      }
    }
  }
};

export { apiTool };