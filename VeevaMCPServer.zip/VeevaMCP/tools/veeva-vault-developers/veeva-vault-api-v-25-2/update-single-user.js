/**
 * Function to update a single user in Veeva Vault.
 *
 * @param {Object} args - Arguments for the user update.
 * @param {string} args.id - The user ID to update. Use 'me' to update the currently authenticated user.
 * @param {Object} [args.data] - The data to update for the user.
 * @param {string} [args.data.company__v] - The company information to update for the user.
 * @returns {Promise<Object>} - The result of the user update operation.
 */
const executeFunction = async ({ id, data }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/users/${id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body data for the request
    const body = new URLSearchParams();
    if (data && data.company__v) {
      body.append('company__v', data.company__v);
    }

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const responseData = await response.json();
    return responseData;
  } catch (error) {
    console.error('Error updating user:', error);
    return {
      error: `An error occurred while updating the user: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating a single user in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_single_user',
      description: 'Update a single user in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          id: {
            type: 'string',
            description: 'The user ID to update. Use "me" to update the currently authenticated user.'
          },
          data: {
            type: 'object',
            properties: {
              company__v: {
                type: 'string',
                description: 'The company information to update for the user.'
              }
            },
            required: []
          }
        },
        required: ['id']
      }
    }
  }
};

export { apiTool };