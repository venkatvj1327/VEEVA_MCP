/**
 * Function to retrieve document type relationships from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.type - The document type to retrieve relationships for.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @returns {Promise<Object>} - The result of the document type relationships retrieval.
 */
const executeFunction = async ({ type, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  try {
    // Construct the URL with the document type
    const url = `https://${vaultDNS}/api/${version}/metadata/objects/documents/types/${type}/relationships`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving document type relationships:', error);
    return {
      error: `An error occurred while retrieving document type relationships: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document type relationships from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_type_relationships',
      description: 'Retrieve document type relationships from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          type: {
            type: 'string',
            description: 'The document type to retrieve relationships for.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          }
        },
        required: ['type', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };