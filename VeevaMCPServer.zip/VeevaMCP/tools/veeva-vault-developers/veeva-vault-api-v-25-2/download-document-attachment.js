/**
 * Function to download a document attachment from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.doc_id - The document ID from which to download the attachment.
 * @param {string} args.attachment_id - The attachment ID to download.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} [args.sessionId=''] - The session ID for authorization.
 * @param {string} [args.clientId=''] - The client ID for the request.
 * @returns {Promise<Object>} - The result of the download request.
 */
const executeFunction = async ({ doc_id, attachment_id, vaultDNS, version, sessionId = '', clientId = '' }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/attachments/${attachment_id}/file`;
  
  try {
    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading document attachment:', error);
    return {
      error: `An error occurred while downloading the document attachment: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading document attachments from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_document_attachment',
      description: 'Download a document attachment from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID from which to download the attachment.'
          },
          attachment_id: {
            type: 'string',
            description: 'The attachment ID to download.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['doc_id', 'attachment_id', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };