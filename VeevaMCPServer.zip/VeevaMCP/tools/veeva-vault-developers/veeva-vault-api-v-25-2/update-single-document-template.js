/**
 * Function to update a single document template in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.template_name - The name of the existing document template.
 * @param {string} args.new_name - The new name for the document template.
 * @param {string} args.label - The new label for the document template.
 * @param {boolean} args.active - Indicates whether the document template should be active.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ template_name, new_name, label, active }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/documents/templates/${template_name}`;
    
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId,
      'Content-Type': 'application/x-www-form-urlencoded'
    };

    const body = new URLSearchParams();
    if (new_name) body.append('new_name', new_name);
    if (label) body.append('label__v', label);
    body.append('active__v', active.toString());

    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: body.toString()
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating document template:', error);
    return {
      error: `An error occurred while updating the document template: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating a document template in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_document_template',
      description: 'Update a single document template in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          template_name: {
            type: 'string',
            description: 'The name of the existing document template.'
          },
          new_name: {
            type: 'string',
            description: 'The new name for the document template.'
          },
          label: {
            type: 'string',
            description: 'The new label for the document template.'
          },
          active: {
            type: 'boolean',
            description: 'Indicates whether the document template should be active.'
          }
        },
        required: ['template_name']
      }
    }
  }
};

export { apiTool };