/**
 * Function to retrieve deleted document attachments from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.attachment_id - The attachment ID.
 * @param {string} args.attachment_version - The attachment version.
 * @returns {Promise<Object>} - The result of the retrieval of deleted document attachments.
 */
const executeFunction = async ({ doc_id, attachment_id, attachment_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL with path parameters
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/attachments/${attachment_id}/versions/${attachment_version}`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving deleted document attachments:', error);
    return {
      error: `An error occurred while retrieving deleted document attachments: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving deleted document attachments from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_deleted_document_attachments',
      description: 'Retrieve deleted document attachments from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          attachment_id: {
            type: 'string',
            description: 'The attachment ID.'
          },
          attachment_version: {
            type: 'string',
            description: 'The attachment version.'
          }
        },
        required: ['doc_id', 'attachment_id', 'attachment_version']
      }
    }
  }
};

export { apiTool };