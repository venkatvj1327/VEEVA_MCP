/**
 * Function to download all attachment field files from a specified object record in Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.object_name - The object name (e.g., product__v).
 * @param {string} args.object_record_id - The object record ID.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @returns {Promise<Object>} - The result of the download request.
 */
const executeFunction = async ({ object_name, object_record_id, vaultDNS, version, sessionId, clientId }) => {
  const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/attachment_fields/file`;
  
  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading attachment field files:', error);
    return {
      error: `An error occurred while downloading attachment field files: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading attachment field files from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_attachment_field_files',
      description: 'Download all attachment field files from a specified object record in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name (e.g., product__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The object record ID.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['object_name', 'object_record_id', 'vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };