/**
 * Function to create multiple users in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating users.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {Object} args.userData - The user data to be created.
 * @returns {Promise<Object>} - The result of the user creation request.
 */
const executeFunction = async ({ sessionId, clientId, userData }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/objects/users`;
  
  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/json',
    'Accept': 'text/csv',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(userData)
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating multiple users:', error);
    return {
      error: `An error occurred while creating users: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating multiple users in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_multiple_users',
      description: 'Create multiple users in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          userData: {
            type: 'object',
            description: 'The user data to be created.',
            additionalProperties: true // Allow any user data fields
          }
        },
        required: ['sessionId', 'clientId', 'userData']
      }
    }
  }
};

export { apiTool };