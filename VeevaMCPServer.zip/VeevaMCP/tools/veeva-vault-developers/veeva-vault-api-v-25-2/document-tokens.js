/**
 * Function to generate document access tokens for Veeva Vault documents.
 *
 * @param {Object} args - Arguments for generating document tokens.
 * @param {string} args.docIds - Required: A comma-separated string of document id values.
 * @param {string} [args.expiryDateOffset] - Optional: Number of days after which the tokens will expire.
 * @param {string} [args.downloadOption] - Optional: Download option for the document (PDF, source, both, or none).
 * @param {string} [args.channel] - Optional: Distribution channel record id.
 * @param {string} [args.tokenGroup] - Optional: Group for generated tokens for multiple documents.
 * @param {boolean} [args.steadyState] - Optional: If true, generates a token for the latest steady state version of a document.
 * @returns {Promise<Object>} - The result of the token generation.
 */
const executeFunction = async ({ docIds, expiryDateOffset, downloadOption, channel, tokenGroup, steadyState }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL
    const url = `https://${vaultDNS}/api/${version}/objects/documents/tokens`;

    // Create the request body
    const body = new URLSearchParams();
    body.append('docIds', docIds);
    if (expiryDateOffset) body.append('expiryDateOffset', expiryDateOffset);
    if (downloadOption) body.append('downloadOption', downloadOption);
    if (channel) body.append('channel', channel);
    if (tokenGroup) body.append('tokenGroup', tokenGroup);
    if (steadyState) body.append('steadyState', steadyState);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error generating document tokens:', error);
    return {
      error: `An error occurred while generating document tokens: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for generating document tokens in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'generate_document_tokens',
      description: 'Generate document access tokens for Veeva Vault documents.',
      parameters: {
        type: 'object',
        properties: {
          docIds: {
            type: 'string',
            description: 'A comma-separated string of document id values.'
          },
          expiryDateOffset: {
            type: 'string',
            description: 'Number of days after which the tokens will expire.'
          },
          downloadOption: {
            type: 'string',
            description: 'Download option for the document (PDF, source, both, or none).'
          },
          channel: {
            type: 'string',
            description: 'Distribution channel record id.'
          },
          tokenGroup: {
            type: 'string',
            description: 'Group for generated tokens for multiple documents.'
          },
          steadyState: {
            type: 'boolean',
            description: 'If true, generates a token for the latest steady state version of a document.'
          }
        },
        required: ['docIds']
      }
    }
  }
};

export { apiTool };