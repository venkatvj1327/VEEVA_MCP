/**
 * Function to retrieve the object collection from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} [args.loc] - Include this parameter to retrieve localized strings.
 * @returns {Promise<Object>} - The result of the object collection retrieval.
 */
const executeFunction = async ({ vaultDNS, version, loc }) => {
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const baseUrl = `https://${vaultDNS}/api/${version}/metadata/vobjects`;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Construct the URL with query parameters if loc is provided
    const url = new URL(baseUrl);
    if (loc) {
      url.searchParams.append('loc', loc);
    }

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving object collection:', error);
    return {
      error: `An error occurred while retrieving the object collection: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving the object collection from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_object_collection',
      description: 'Retrieve all Vault objects in the authenticated Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          loc: {
            type: 'string',
            description: 'Include this parameter to retrieve localized strings.'
          }
        },
        required: ['vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };