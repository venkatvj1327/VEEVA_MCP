/**
 * Function to retrieve domain information from Veeva Vault.
 *
 * @param {Object} args - Arguments for the domain information retrieval.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @returns {Promise<Object>} - The result of the domain information retrieval.
 */
const executeFunction = async ({ vaultDNS, version, sessionId, clientId }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/objects/domain?include_application=true`;
  const token = process.env.VEEVA_VAULT_DEVELOPERS_API_KEY;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving domain information:', error);
    return {
      error: `An error occurred while retrieving domain information: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving domain information from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_domain_information',
      description: 'Retrieve domain information from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          }
        },
        required: ['vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };