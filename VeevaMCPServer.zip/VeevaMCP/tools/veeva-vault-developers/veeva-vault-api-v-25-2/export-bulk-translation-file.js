/**
 * Function to export a bulk translation file from Veeva Vault.
 *
 * @param {Object} args - Arguments for the export.
 * @param {string} args.message_type - The message type name (e.g., field_labels__sys).
 * @param {string} args.lang - A valid language code value (e.g., en).
 * @returns {Promise<Object>} - The result of the export request.
 */
const executeFunction = async ({ message_type, lang }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL
    const url = `https://${vaultDNS}/api/${version}/messages/${message_type}/language/${lang}/actions/export`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error exporting bulk translation file:', error);
    return {
      error: `An error occurred while exporting the bulk translation file: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for exporting a bulk translation file from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'export_bulk_translation_file',
      description: 'Export a bulk translation file from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          message_type: {
            type: 'string',
            description: 'The message type name (e.g., field_labels__sys).'
          },
          lang: {
            type: 'string',
            description: 'A valid language code value (e.g., en).'
          }
        },
        required: ['message_type', 'lang']
      }
    }
  }
};

export { apiTool };