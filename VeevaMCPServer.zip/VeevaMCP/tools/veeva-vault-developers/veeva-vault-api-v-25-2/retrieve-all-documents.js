/**
 * Function to retrieve all documents from Veeva Vault.
 *
 * @param {Object} args - Arguments for retrieving documents.
 * @param {string} [args.named_filter] - Filter to retrieve specific documents (e.g., "My Documents", "Favorites").
 * @param {string} [args.scope] - Scope of the search (e.g., "contents", "all").
 * @param {string} [args.versionscope] - Scope of document versions (e.g., "all").
 * @param {string} [args.search] - Keyword to search for in document fields.
 * @param {number} [args.limit] - Limit the number of documents returned.
 * @param {string} [args.sort] - Sort order for the documents.
 * @param {number} [args.start] - Start index for pagination.
 * @returns {Promise<Object>} - The result of the document retrieval.
 */
const executeFunction = async ({ named_filter, scope, versionscope, search, limit, sort, start }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/documents`);
    if (named_filter) url.searchParams.append('named_filter', named_filter);
    if (scope) url.searchParams.append('scope', scope);
    if (versionscope) url.searchParams.append('versionscope', versionscope);
    if (search) url.searchParams.append('search', search);
    if (limit) url.searchParams.append('limit', limit);
    if (sort) url.searchParams.append('sort', sort);
    if (start) url.searchParams.append('start', start);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving documents:', error);
    return {
      error: `An error occurred while retrieving documents: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving documents from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_all_documents',
      description: 'Retrieve all documents from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          named_filter: {
            type: 'string',
            description: 'Filter to retrieve specific documents.'
          },
          scope: {
            type: 'string',
            description: 'Scope of the search.'
          },
          versionscope: {
            type: 'string',
            description: 'Scope of document versions.'
          },
          search: {
            type: 'string',
            description: 'Keyword to search for in document fields.'
          },
          limit: {
            type: 'integer',
            description: 'Limit the number of documents returned.'
          },
          sort: {
            type: 'string',
            description: 'Sort order for the documents.'
          },
          start: {
            type: 'integer',
            description: 'Start index for pagination.'
          }
        }
      }
    }
  }
};

export { apiTool };