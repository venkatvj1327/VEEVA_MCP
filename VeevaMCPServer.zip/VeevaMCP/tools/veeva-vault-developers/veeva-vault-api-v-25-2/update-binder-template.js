/**
 * Function to update a binder template in Veeva Vault.
 *
 * @param {Object} args - Arguments for updating the binder template.
 * @param {string} args.name__v - The new name of the binder template.
 * @param {string} args.label__v - The new label of the binder template.
 * @param {string} args.type__v - The document type associated with the template.
 * @param {string} [args.subtype__v] - The document subtype associated with the template.
 * @param {string} [args.classification__v] - The document classification associated with the template.
 * @param {boolean} [args.active__v] - Indicates whether the binder template should be active.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ name__v, label__v, type__v, subtype__v, classification__v, active__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/binders/templates`;

    // Prepare the form data
    const formData = new URLSearchParams();
    if (name__v) formData.append('name__v', name__v);
    if (label__v) formData.append('label__v', label__v);
    if (type__v) formData.append('type__v', type__v);
    if (subtype__v) formData.append('subtype__v', subtype__v);
    if (classification__v) formData.append('classification__v', classification__v);
    if (active__v !== undefined) formData.append('active__v', active__v.toString());

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating binder template:', error);
    return {
      error: `An error occurred while updating the binder template: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating a binder template in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_binder_template',
      description: 'Update an existing binder template in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          name__v: {
            type: 'string',
            description: 'The new name of the binder template.'
          },
          label__v: {
            type: 'string',
            description: 'The new label of the binder template.'
          },
          type__v: {
            type: 'string',
            description: 'The document type associated with the template.'
          },
          subtype__v: {
            type: 'string',
            description: 'The document subtype associated with the template.'
          },
          classification__v: {
            type: 'string',
            description: 'The document classification associated with the template.'
          },
          active__v: {
            type: 'boolean',
            description: 'Indicates whether the binder template should be active.'
          }
        },
        required: ['type__v']
      }
    }
  }
};

export { apiTool };