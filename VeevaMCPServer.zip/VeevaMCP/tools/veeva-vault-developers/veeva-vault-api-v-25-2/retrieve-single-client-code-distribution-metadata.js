/**
 * Function to retrieve metadata for a specific client code distribution from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.distribution_name - The name attribute of the client code distribution to retrieve.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @returns {Promise<Object>} - The metadata of the specified client code distribution.
 */
const executeFunction = async ({ distribution_name, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/uicode/distributions/${distribution_name}`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving client code distribution metadata:', error);
    return {
      error: `An error occurred while retrieving metadata: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving client code distribution metadata from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_client_code_distribution_metadata',
      description: 'Retrieve metadata for a specific client code distribution from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          distribution_name: {
            type: 'string',
            description: 'The name attribute of the client code distribution to retrieve.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          }
        },
        required: ['distribution_name', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };