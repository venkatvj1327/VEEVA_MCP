/**
 * Function to retrieve job histories from Veeva Vault.
 *
 * @param {Object} args - Arguments for retrieving job histories.
 * @param {string} [args.start_date] - The start date for retrieving completed jobs in the format YYYY-MM-DDTHH:MM:SSZ.
 * @param {string} [args.end_date] - The end date for retrieving completed jobs in the format YYYY-MM-DDTHH:MM:SSZ.
 * @param {string} [args.status] - Filter to only retrieve jobs in a certain status (success, errors_encountered, failed_to_run, missed_schedule, cancelled).
 * @param {number} [args.limit=50] - The maximum number of histories per page (1 to 200).
 * @param {number} [args.offset=0] - The offset for pagination.
 * @returns {Promise<Object>} - The result of the job histories retrieval.
 */
const executeFunction = async ({ start_date, end_date, status, limit = 50, offset = 0 }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/services/jobs/histories`);
    if (start_date) url.searchParams.append('start_date', start_date);
    if (end_date) url.searchParams.append('end_date', end_date);
    if (status) url.searchParams.append('status', status);
    if (limit) url.searchParams.append('limit', limit.toString());
    if (offset) url.searchParams.append('offset', offset.toString());

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving job histories:', error);
    return {
      error: `An error occurred while retrieving job histories: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving job histories from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_job_histories',
      description: 'Retrieve a history of all completed jobs in the authenticated Vault.',
      parameters: {
        type: 'object',
        properties: {
          start_date: {
            type: 'string',
            description: 'The start date for retrieving completed jobs in the format YYYY-MM-DDTHH:MM:SSZ.'
          },
          end_date: {
            type: 'string',
            description: 'The end date for retrieving completed jobs in the format YYYY-MM-DDTHH:MM:SSZ.'
          },
          status: {
            type: 'string',
            enum: ['success', 'errors_encountered', 'failed_to_run', 'missed_schedule', 'cancelled'],
            description: 'Filter to only retrieve jobs in a certain status.'
          },
          limit: {
            type: 'integer',
            description: 'The maximum number of histories per page (1 to 200).'
          },
          offset: {
            type: 'integer',
            description: 'The offset for pagination.'
          }
        }
      }
    }
  }
};

export { apiTool };