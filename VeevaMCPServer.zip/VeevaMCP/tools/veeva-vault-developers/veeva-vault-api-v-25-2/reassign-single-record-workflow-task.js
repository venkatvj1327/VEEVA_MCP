/**
 * Function to reassign a single record workflow task in Veeva Vault.
 *
 * @param {Object} args - Arguments for the reassignment.
 * @param {string} args.task_id - The ID of the task to reassign.
 * @param {string} args.task_assignee__v - The ID of the user who will become the new task assignee, in the format user:{id}.
 * @returns {Promise<Object>} - The result of the reassignment operation.
 */
const executeFunction = async ({ task_id, task_assignee__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/objectworkflows/tasks/${task_id}/actions/reassign`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body data for the request
    const body = new URLSearchParams();
    body.append('task_assignee__v', task_assignee__v);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error reassigning workflow task:', error);
    return {
      error: `An error occurred while reassigning the workflow task: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for reassigning a single record workflow task in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'reassign_single_record_workflow_task',
      description: 'Reassign a single record workflow task in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          task_id: {
            type: 'string',
            description: 'The ID of the task to reassign.'
          },
          task_assignee__v: {
            type: 'string',
            description: 'The ID of the user who will become the new task assignee, in the format user:{id}.'
          }
        },
        required: ['task_id', 'task_assignee__v']
      }
    }
  }
};

export { apiTool };