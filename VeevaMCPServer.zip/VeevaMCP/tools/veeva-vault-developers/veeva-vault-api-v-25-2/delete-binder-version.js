/**
 * Function to delete a binder version in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.binder_id - The ID of the binder to delete.
 * @param {string} args.major_version - The major version number of the binder.
 * @param {string} args.minor_version - The minor version number of the binder.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ binder_id, major_version, minor_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL for the DELETE request
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/versions/${major_version}/${minor_version}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response data
    return await response.json();
  } catch (error) {
    console.error('Error deleting binder version:', error);
    return {
      error: `An error occurred while deleting the binder version: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting a binder version in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_binder_version',
      description: 'Delete a specific version of a binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder to delete.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the binder.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the binder.'
          }
        },
        required: ['binder_id', 'major_version', 'minor_version']
      }
    }
  }
};

export { apiTool };