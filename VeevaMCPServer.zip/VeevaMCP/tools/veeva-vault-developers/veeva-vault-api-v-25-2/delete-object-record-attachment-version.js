/**
 * Function to delete an object record attachment version in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version.
 * @param {string} args.object_name - The object name (e.g., product__v).
 * @param {string} args.object_record_id - The object record ID.
 * @param {string} args.attachment_id - The attachment ID.
 * @param {string} args.attachment_version - The attachment version.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ vaultDNS, version, object_name, object_record_id, attachment_id, attachment_version }) => {
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const baseUrl = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/attachments/${attachment_id}/versions/${attachment_version}`;
  
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return success response
    return { message: 'Attachment version deleted successfully.' };
  } catch (error) {
    console.error('Error deleting attachment version:', error);
    return {
      error: `An error occurred while deleting the attachment version: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting an object record attachment version in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_object_record_attachment_version',
      description: 'Delete an object record attachment version in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          },
          object_name: {
            type: 'string',
            description: 'The object name (e.g., product__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The object record ID.'
          },
          attachment_id: {
            type: 'string',
            description: 'The attachment ID.'
          },
          attachment_version: {
            type: 'string',
            description: 'The attachment version.'
          }
        },
        required: ['vaultDNS', 'version', 'object_name', 'object_record_id', 'attachment_id', 'attachment_version']
      }
    }
  }
};

export { apiTool };