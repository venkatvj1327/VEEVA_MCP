/**
 * Function to download the thumbnail image file of a specific document version from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.doc_id - The document ID.
 * @param {number} args.major_version - The document major version number.
 * @param {number} args.minor_version - The document minor version number.
 * @returns {Promise<Buffer>} - The thumbnail image file as a buffer.
 */
const executeFunction = async ({ doc_id, major_version, minor_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL with path variables
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/thumbnail`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response as a buffer
    const buffer = await response.buffer();
    return buffer;
  } catch (error) {
    console.error('Error downloading document version thumbnail:', error);
    return {
      error: `An error occurred while downloading the thumbnail: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading document version thumbnail from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_document_thumbnail',
      description: 'Download the thumbnail image file of a specific document version from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          major_version: {
            type: 'number',
            description: 'The document major version number.'
          },
          minor_version: {
            type: 'number',
            description: 'The document minor version number.'
          }
        },
        required: ['doc_id', 'major_version', 'minor_version']
      }
    }
  }
};

export { apiTool };