/**
 * Function to list items at a specified path in Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.item - The absolute path to a file or folder.
 * @param {boolean} [args.recursive=false] - If true, the response will contain the contents of all subfolders.
 * @param {number} [args.limit=1000] - The maximum number of items per page in the response (1 to 1000).
 * @param {string} [args.format_result] - If set to 'csv', the response includes a job_id.
 * @returns {Promise<Object>} - The result of the list items request.
 */
const executeFunction = async ({ item, recursive = false, limit = 1000, format_result }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with the path variable and query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/services/file_staging/items/${encodeURIComponent(item)}`);
    if (recursive) url.searchParams.append('recursive', 'true');
    if (limit) url.searchParams.append('limit', limit.toString());
    if (format_result) url.searchParams.append('format_result', format_result);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error listing items at path:', error);
    return {
      error: `An error occurred while listing items: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for listing items at a specified path in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'list_items_at_path',
      description: 'List items at a specified path in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          item: {
            type: 'string',
            description: 'The absolute path to a file or folder.'
          },
          recursive: {
            type: 'boolean',
            description: 'If true, the response will contain the contents of all subfolders.'
          },
          limit: {
            type: 'integer',
            description: 'The maximum number of items per page in the response (1 to 1000).'
          },
          format_result: {
            type: 'string',
            description: 'If set to csv, the response includes a job_id.'
          }
        },
        required: ['item']
      }
    }
  }
};

export { apiTool };