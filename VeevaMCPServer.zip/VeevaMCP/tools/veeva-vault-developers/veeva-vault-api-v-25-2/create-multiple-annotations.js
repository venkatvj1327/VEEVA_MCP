/**
 * Function to create multiple annotations in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating annotations.
 * @param {Array} args.annotations - An array of annotation objects to be created.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @returns {Promise<Object>} - The result of the annotation creation.
 */
const executeFunction = async ({ annotations, vaultDNS, version, sessionId, clientId }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/annotations/batch`;
  const token = process.env.VEEVA_VAULT_DEVELOPERS_API_KEY;
  const clientID = ''; // will be provided by the user

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId || token,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId || clientID
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(annotations)
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating annotations:', error);
    return {
      error: `An error occurred while creating annotations: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating multiple annotations in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_multiple_annotations',
      description: 'Create multiple annotations in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          annotations: {
            type: 'array',
            description: 'An array of annotation objects to be created.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          }
        },
        required: ['annotations', 'vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };