/**
 * Function to create a single user in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating a user.
 * @param {string} args.user_name - The username of the user.
 * @param {string} args.user_first_name - The first name of the user.
 * @param {string} args.user_last_name - The last name of the user.
 * @param {string} args.user_email - The email address of the user.
 * @param {string} args.user_timezone - The timezone of the user.
 * @param {string} args.user_locale - The locale of the user.
 * @param {string} args.security_policy_id - The security policy ID for the user.
 * @param {string} args.user_language - The language preference of the user.
 * @param {string} [args.security_profile] - The security profile of the user (optional).
 * @param {string} [args.license_type] - The license type for the user (optional).
 * @returns {Promise<Object>} - The result of the user creation.
 */
const executeFunction = async ({
  user_name,
  user_first_name,
  user_last_name,
  user_email,
  user_timezone,
  user_locale,
  security_policy_id,
  user_language,
  security_profile = '',
  license_type = ''
}) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/objects/users`;

  const body = new URLSearchParams({
    user_name__v: user_name,
    user_first_name__v: user_first_name,
    user_last_name__v: user_last_name,
    user_email__v: user_email,
    user_timezone__v: user_timezone,
    user_locale__v: user_locale,
    security_policy_id__v: security_policy_id,
    user_language__v: user_language,
    security_profile__v: security_profile,
    license_type__v: license_type
  });

  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating user:', error);
    return {
      error: `An error occurred while creating the user: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a single user in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_single_user',
      description: 'Create a single user in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          user_name: {
            type: 'string',
            description: 'The username of the user.'
          },
          user_first_name: {
            type: 'string',
            description: 'The first name of the user.'
          },
          user_last_name: {
            type: 'string',
            description: 'The last name of the user.'
          },
          user_email: {
            type: 'string',
            description: 'The email address of the user.'
          },
          user_timezone: {
            type: 'string',
            description: 'The timezone of the user.'
          },
          user_locale: {
            type: 'string',
            description: 'The locale of the user.'
          },
          security_policy_id: {
            type: 'string',
            description: 'The security policy ID for the user.'
          },
          user_language: {
            type: 'string',
            description: 'The language preference of the user.'
          },
          security_profile: {
            type: 'string',
            description: 'The security profile of the user.'
          },
          license_type: {
            type: 'string',
            description: 'The license type for the user.'
          }
        },
        required: ['user_name', 'user_first_name', 'user_last_name', 'user_email', 'user_timezone', 'user_locale', 'security_policy_id', 'user_language']
      }
    }
  }
};

export { apiTool };