/**
 * Function to retrieve the results of a cascade delete job from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.object_name - The object name__v field value (e.g., product__v, country__v).
 * @param {string} args.job_status - The status of the job.
 * @param {string} args.job_id - The ID of the job to retrieve results for.
 * @returns {Promise<Object>} - The results of the cascade delete job.
 */
const executeFunction = async ({ object_name, job_status, job_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path parameters
    const url = `https://${vaultDNS}/api/${version}/vobjects/cascadedelete/results/${object_name}/${job_status}/${job_id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(errorData);
    }

    // Parse and return the response data
    const data = await response.text();
    return data;
  } catch (error) {
    console.error('Error retrieving cascade delete job results:', error);
    return {
      error: `An error occurred while retrieving cascade delete job results: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving results of a cascade delete job from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_cascade_delete_results',
      description: 'Retrieve results of a cascade delete job from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name__v field value (e.g., product__v, country__v).'
          },
          job_status: {
            type: 'string',
            description: 'The status of the job.'
          },
          job_id: {
            type: 'string',
            description: 'The ID of the job to retrieve results for.'
          }
        },
        required: ['object_name', 'job_status', 'job_id']
      }
    }
  }
};

export { apiTool };