/**
 * Function to create a single document relationship in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating the document relationship.
 * @param {string} args.doc_id - The document id of the target document.
 * @param {string} args.relationship_type - The relationship type retrieved from the Document Relationships Metadata.
 * @param {string} [args.major_version] - The major version number of the target document (optional).
 * @param {string} [args.minor_version] - The minor version number of the target document (optional).
 * @returns {Promise<Object>} - The result of the document relationship creation.
 */
const executeFunction = async ({ doc_id, relationship_type, major_version, minor_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/relationships`;

    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    const body = new URLSearchParams();
    body.append('target_doc_id__v', doc_id);
    body.append('relationship_type__v', relationship_type);
    if (major_version) body.append('target_major_version__v', major_version);
    if (minor_version) body.append('target_minor_version__v', minor_version);

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating document relationship:', error);
    return {
      error: `An error occurred while creating the document relationship: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a single document relationship in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_document_relationship',
      description: 'Create a single document relationship in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document id of the target document.'
          },
          relationship_type: {
            type: 'string',
            description: 'The relationship type retrieved from the Document Relationships Metadata.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the target document (optional).'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the target document (optional).'
          }
        },
        required: ['doc_id', 'relationship_type']
      }
    }
  }
};

export { apiTool };