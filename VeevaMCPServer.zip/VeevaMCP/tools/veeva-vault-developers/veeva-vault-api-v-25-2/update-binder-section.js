/**
 * Function to update a binder section in Veeva Vault.
 *
 * @param {Object} args - Arguments for updating the binder section.
 * @param {string} args.binder_id - The ID of the binder to update.
 * @param {string} args.node_id - The ID of the section to update.
 * @param {string} [args.name__v] - Change the name of the binder section.
 * @param {string} [args.section_number__v] - Update the section number value.
 * @param {string} [args.order__v] - To move the section to a different section in the binder.
 * @param {string} [args.parent_id__v] - Optional: Enter a number reflecting the position of the section within the binder or parent section.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ binder_id, node_id, name__v, section_number__v, order__v, parent_id__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/sections/${node_id}`;
    
    const formData = new URLSearchParams();
    if (name__v) formData.append('name__v', name__v);
    if (section_number__v) formData.append('section_number__v', section_number__v);
    if (order__v) formData.append('order__v', order__v);
    if (parent_id__v) formData.append('parent_id__v', parent_id__v);

    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: formData
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating binder section:', error);
    return {
      error: `An error occurred while updating the binder section: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating a binder section in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_binder_section',
      description: 'Update a section in a binder.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder to update.'
          },
          node_id: {
            type: 'string',
            description: 'The ID of the section to update.'
          },
          name__v: {
            type: 'string',
            description: 'Change the name of the binder section.'
          },
          section_number__v: {
            type: 'string',
            description: 'Update the section number value.'
          },
          order__v: {
            type: 'string',
            description: 'To move the section to a different section in the binder.'
          },
          parent_id__v: {
            type: 'string',
            description: 'Optional: Enter a number reflecting the position of the section within the binder or parent section.'
          }
        },
        required: ['binder_id', 'node_id']
      }
    }
  }
};

export { apiTool };