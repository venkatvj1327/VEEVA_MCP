/**
 * Function to retrieve a security policy from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.security_policy_name - The name of the security policy to retrieve.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for the request.
 * @param {string} args.vaultDNS - The DNS of the vault.
 * @param {string} args.version - The API version.
 * @returns {Promise<Object>} - The result of the security policy retrieval.
 */
const executeFunction = async ({ security_policy_name, sessionId, clientId, vaultDNS, version }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/securitypolicies/${security_policy_name}`;
  
  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving security policy:', error);
    return {
      error: `An error occurred while retrieving the security policy: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving a security policy from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_security_policy',
      description: 'Retrieve a security policy from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          security_policy_name: {
            type: 'string',
            description: 'The name of the security policy to retrieve.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the vault.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          }
        },
        required: ['security_policy_name', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };