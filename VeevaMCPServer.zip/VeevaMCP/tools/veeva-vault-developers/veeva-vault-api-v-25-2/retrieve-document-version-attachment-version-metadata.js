/**
 * Function to retrieve document version attachment version metadata from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.major_version - The major version number of the document.
 * @param {string} args.minor_version - The minor version number of the document.
 * @param {string} args.attachment_id - The ID of the document attachment to retrieve.
 * @param {string} [args.attachment_version] - The version of the attachment to retrieve (optional).
 * @returns {Promise<Object>} - The result of the retrieval.
 */
const executeFunction = async ({ doc_id, major_version, minor_version, attachment_id, attachment_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path parameters
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/attachments/${attachment_id}/versions/${attachment_version || ''}`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving document version attachment metadata:', error);
    return {
      error: `An error occurred while retrieving document version attachment metadata: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document version attachment version metadata from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_version_attachment_metadata',
      description: 'Retrieve a specific version of an attachment on a document version.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the document.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the document.'
          },
          attachment_id: {
            type: 'string',
            description: 'The ID of the document attachment to retrieve.'
          },
          attachment_version: {
            type: 'string',
            description: 'Optional: The version of the attachment to retrieve.'
          }
        },
        required: ['doc_id', 'major_version', 'minor_version', 'attachment_id']
      }
    }
  }
};

export { apiTool };