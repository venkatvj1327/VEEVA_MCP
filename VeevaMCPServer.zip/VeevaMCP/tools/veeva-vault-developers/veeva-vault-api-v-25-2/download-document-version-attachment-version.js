/**
 * Function to download a document version attachment from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.major_version - The major version number of the document.
 * @param {string} args.minor_version - The minor version number of the document.
 * @param {string} args.attachment_id - The ID of the attachment.
 * @param {string} args.attachment_version - The version of the attachment.
 * @returns {Promise<Object>} - The result of the download request.
 */
const executeFunction = async ({ doc_id, major_version, minor_version, attachment_id, attachment_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL with path parameters
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/attachments/${attachment_id}/versions/${attachment_version}/file`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading document version attachment:', error);
    return {
      error: `An error occurred while downloading the document version attachment: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading document version attachments from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_document_version_attachment',
      description: 'Download a document version attachment from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the document.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the document.'
          },
          attachment_id: {
            type: 'string',
            description: 'The ID of the attachment.'
          },
          attachment_version: {
            type: 'string',
            description: 'The version of the attachment.'
          }
        },
        required: ['doc_id', 'major_version', 'minor_version', 'attachment_id', 'attachment_version']
      }
    }
  }
};

export { apiTool };