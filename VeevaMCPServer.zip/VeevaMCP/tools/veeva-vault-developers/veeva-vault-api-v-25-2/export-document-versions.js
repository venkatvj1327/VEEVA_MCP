/**
 * Function to export document versions to Veeva Vault.
 *
 * @param {Object} args - Arguments for the export.
 * @param {Array<Object>} args.documentVersions - An array of document version objects to export.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {boolean} [args.source=true] - Optional: To exclude source files, set to false.
 * @param {boolean} [args.renditions=false] - Optional: To include renditions, set to true.
 * @returns {Promise<Object>} - The result of the export operation.
 */
const executeFunction = async ({ documentVersions, sessionId, clientId, vaultDNS, version, source = true, renditions = false }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/versions/batch/actions/fileextract`;
  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  const body = JSON.stringify(documentVersions);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body,
      query: {
        source,
        renditions
      }
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error exporting document versions:', error);
    return {
      error: `An error occurred while exporting document versions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for exporting document versions to Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'export_document_versions',
      description: 'Export document versions to Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          documentVersions: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                id: { type: 'string' },
                major_version_number__v: { type: 'string' },
                minor_version_number__v: { type: 'string' }
              },
              required: ['id', 'major_version_number__v', 'minor_version_number__v']
            },
            description: 'An array of document version objects to export.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          source: {
            type: 'boolean',
            description: 'Optional: To exclude source files, set to false.'
          },
          renditions: {
            type: 'boolean',
            description: 'Optional: To include renditions, set to true.'
          }
        },
        required: ['documentVersions', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };