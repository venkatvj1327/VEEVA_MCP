/**
 * Function to create a new binder in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating a binder.
 * @param {string} args.lifecycle__v - The lifecycle version of the binder.
 * @param {string} args.name__v - The name of the binder.
 * @param {string} args.type__v - The type of the binder.
 * @param {string} args.subtype__v - The subtype of the binder.
 * @param {string} args.classification__v - The classification of the binder.
 * @param {string} args.major_version_number__v - The major version number of the binder.
 * @param {string} args.minor_version_number__v - The minor version number of the binder.
 * @param {string} [args.vaultDNS] - The DNS of the Vault (default: 'yourvault.veevavault.com').
 * @param {string} [args.version] - The API version (default: '25.2').
 * @param {string} [args.sessionId] - The session ID for authorization.
 * @param {string} [args.clientId] - The client ID for the request.
 * @returns {Promise<Object>} - The result of the binder creation.
 */
const executeFunction = async ({ lifecycle__v, name__v, type__v, subtype__v, classification__v, major_version_number__v, minor_version_number__v, vaultDNS = 'yourvault.veevavault.com', version = '25.2', sessionId = '', clientId = '' }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/binders`;
  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  const body = new URLSearchParams({
    lifecycle__v,
    name__v,
    type__v,
    subtype__v,
    classification__v,
    major_version_number__v,
    minor_version_number__v
  });

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating binder:', error);
    return {
      error: `An error occurred while creating the binder: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a binder in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_binder',
      description: 'Create a new binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          lifecycle__v: {
            type: 'string',
            description: 'The lifecycle version of the binder.'
          },
          name__v: {
            type: 'string',
            description: 'The name of the binder.'
          },
          type__v: {
            type: 'string',
            description: 'The type of the binder.'
          },
          subtype__v: {
            type: 'string',
            description: 'The subtype of the binder.'
          },
          classification__v: {
            type: 'string',
            description: 'The classification of the binder.'
          },
          major_version_number__v: {
            type: 'string',
            description: 'The major version number of the binder.'
          },
          minor_version_number__v: {
            type: 'string',
            description: 'The minor version number of the binder.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['lifecycle__v', 'name__v', 'type__v', 'subtype__v', 'classification__v', 'major_version_number__v', 'minor_version_number__v']
      }
    }
  }
};

export { apiTool };