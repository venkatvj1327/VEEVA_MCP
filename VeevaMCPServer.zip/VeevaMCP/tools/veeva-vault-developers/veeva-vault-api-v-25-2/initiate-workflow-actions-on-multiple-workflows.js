/**
 * Function to initiate workflow actions on multiple workflows in Veeva Vault.
 *
 * @param {Object} args - Arguments for the workflow action initiation.
 * @param {string} args.workflow_ids - A comma-separated list of workflow_id__v field values (maximum 500 workflows).
 * @param {string} args.action - The action to be performed on the workflows.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @returns {Promise<Object>} - The result of the workflow action initiation.
 */
const executeFunction = async ({ workflow_ids, action, vaultDNS, version, sessionId, clientId }) => {
  const url = `https://${vaultDNS}/api/${version}/object/workflow/actions/${action}`;
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId
  };

  const body = new URLSearchParams();
  body.append('workflow_ids', workflow_ids);

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error initiating workflow actions:', error);
    return {
      error: `An error occurred while initiating workflow actions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for initiating workflow actions on multiple workflows in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'initiate_workflow_actions',
      description: 'Initiate workflow actions on multiple workflows in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          workflow_ids: {
            type: 'string',
            description: 'A comma-separated list of workflow_id__v field values (maximum 500 workflows).'
          },
          action: {
            type: 'string',
            description: 'The action to be performed on the workflows.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['workflow_ids', 'action', 'vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };