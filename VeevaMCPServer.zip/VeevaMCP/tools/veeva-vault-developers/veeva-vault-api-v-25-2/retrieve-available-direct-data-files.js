/**
 * Function to retrieve available Direct Data files from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @param {string} [args.extract_type] - The Direct Data file type (incremental_directdata, full_directdata, or log_directdata).
 * @param {string} [args.start_time] - The start time in YYYY-MM-DDTHH:MM:SSZ format.
 * @param {string} [args.stop_time] - The stop time in YYYY-MM-DDTHH:MM:SSZ format.
 * @returns {Promise<Object>} - The list of available Direct Data files.
 */
const executeFunction = async ({ vaultDNS, version, sessionId, clientId, extract_type, start_time, stop_time }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/services/directdata/files`;
  const token = process.env.VEEVA_VAULT_DEVELOPERS_API_KEY;
  const clientID = ''; // will be provided by the user

  try {
    // Construct the URL with query parameters
    const url = new URL(baseUrl);
    if (extract_type) url.searchParams.append('extract_type', extract_type);
    if (start_time) url.searchParams.append('start_time', start_time);
    if (stop_time) url.searchParams.append('stop_time', stop_time);

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving Direct Data files:', error);
    return {
      error: `An error occurred while retrieving Direct Data files: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving available Direct Data files from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_direct_data_files',
      description: 'Retrieve a list of all Direct Data files available for download.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          extract_type: {
            type: 'string',
            description: 'The Direct Data file type (incremental_directdata, full_directdata, or log_directdata).'
          },
          start_time: {
            type: 'string',
            description: 'The start time in YYYY-MM-DDTHH:MM:SSZ format.'
          },
          stop_time: {
            type: 'string',
            description: 'The stop time in YYYY-MM-DDTHH:MM:SSZ format.'
          }
        },
        required: ['vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };