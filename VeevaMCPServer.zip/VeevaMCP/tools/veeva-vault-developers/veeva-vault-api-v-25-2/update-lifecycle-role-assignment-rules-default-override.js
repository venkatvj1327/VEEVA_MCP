/**
 * Function to update lifecycle role assignment rules in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault instance.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {Object} args.data - The JSON object containing the role assignment rules to update.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ vaultDNS, version, sessionId, clientId, data }) => {
  const url = `https://${vaultDNS}/api/${version}/configuration/role_assignment_rule`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: JSON.stringify(data)
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('Error updating lifecycle role assignment rules:', error);
    return {
      error: `An error occurred while updating lifecycle role assignment rules: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating lifecycle role assignment rules in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_lifecycle_role_assignment_rules',
      description: 'Update lifecycle role assignment rules in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault instance.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          data: {
            type: 'object',
            description: 'The JSON object containing the role assignment rules to update.'
          }
        },
        required: ['vaultDNS', 'version', 'sessionId', 'clientId', 'data']
      }
    }
  }
};

export { apiTool };