/**
 * Function to determine if a document has attachments in Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.doc_id - The ID of the document to check for attachments.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @returns {Promise<Object>} - The result of the document attachment check.
 */
const executeFunction = async ({ doc_id, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  try {
    // Construct the URL with the document ID
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error determining document attachments:', error);
    return {
      error: `An error occurred while determining document attachments: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for determining if a document has attachments in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'determine_document_attachments',
      description: 'Determine if a document has attachments in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The ID of the document to check for attachments.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['doc_id', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };