/**
 * Function to download a single client code distribution from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.distribution_name - The name attribute of the client code distribution to download.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID to identify the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @returns {Promise<Buffer>} - The ZIP file containing the client code distribution.
 */
const executeFunction = async ({ distribution_name, sessionId, clientId, vaultDNS, version }) => {
  const url = `https://${vaultDNS}/api/${version}/uicode/distributions/${distribution_name}/code`;
  
  try {
    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response as a buffer (ZIP file)
    const data = await response.buffer();
    return data;
  } catch (error) {
    console.error('Error downloading client code distribution:', error);
    return {
      error: `An error occurred while downloading the client code distribution: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading a single client code distribution from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_client_code_distribution',
      description: 'Download a single client code distribution from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          distribution_name: {
            type: 'string',
            description: 'The name attribute of the client code distribution to download.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID to identify the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['distribution_name', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };