/**
 * Function to update a folder or file in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.item - The absolute path to a file or folder.
 * @param {string} [args.parent] - The absolute path to the parent directory for moving a file or folder.
 * @param {string} [args.name] - The new name for the file or folder.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ item, parent, name }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/services/file_staging/items/${encodeURIComponent(item)}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId,
      'Content-Type': 'application/x-www-form-urlencoded'
    };

    // Prepare the body of the request
    const body = new URLSearchParams();
    if (parent) body.append('parent', parent);
    if (name) body.append('name', name);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating folder or file:', error);
    return {
      error: `An error occurred while updating the folder or file: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating a folder or file in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_folder_or_file',
      description: 'Update a folder or file in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          item: {
            type: 'string',
            description: 'The absolute path to a file or folder.'
          },
          parent: {
            type: 'string',
            description: 'The absolute path to the parent directory for moving a file or folder.'
          },
          name: {
            type: 'string',
            description: 'The new name for the file or folder.'
          }
        },
        required: ['item']
      }
    }
  }
};

export { apiTool };