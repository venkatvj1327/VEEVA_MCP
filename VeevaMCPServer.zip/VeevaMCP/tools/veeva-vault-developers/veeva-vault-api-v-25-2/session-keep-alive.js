/**
 * Function to keep the Veeva Vault session alive by refreshing the session duration.
 *
 * @param {Object} args - Arguments for the keep-alive request.
 * @param {string} args.sessionId - The session ID to keep alive.
 * @param {string} args.clientId - The client ID to identify the request.
 * @returns {Promise<Object>} - The result of the keep-alive request.
 */
const executeFunction = async ({ sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/keep-alive`;

  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error keeping session alive:', error);
    return {
      error: `An error occurred while keeping the session alive: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for keeping the Veeva Vault session alive.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'keep_session_alive',
      description: 'Keep the Veeva Vault session active by refreshing the session duration.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID to keep alive.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID to identify the request.'
          }
        },
        required: ['sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };