/**
 * Function to update the binder document binding rule in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.binder_id - The ID of the binder.
 * @param {string} args.node_id - The ID of the document node.
 * @param {string} [args.binding_rule__v] - Optional binding rule to apply.
 * @param {string} [args.major_version_number__v] - Major version number if binding_rule is specific.
 * @param {string} [args.minor_version_number__v] - Minor version number if binding_rule is specific.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ binder_id, node_id, binding_rule__v = '', major_version_number__v = '', minor_version_number__v = '' }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/documents/${node_id}/binding_rule`;

    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    const body = new URLSearchParams();
    if (binding_rule__v) body.append('binding_rule__v', binding_rule__v);
    if (major_version_number__v) body.append('major_version_number__v', major_version_number__v);
    if (minor_version_number__v) body.append('minor_version_number__v', minor_version_number__v);

    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: body.toString()
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    return await response.json();
  } catch (error) {
    console.error('Error updating binder document binding rule:', error);
    return {
      error: `An error occurred while updating the binder document binding rule: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating binder document binding rule in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_binder_document_binding_rule',
      description: 'Update the binder document binding rule in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder.'
          },
          node_id: {
            type: 'string',
            description: 'The ID of the document node.'
          },
          binding_rule__v: {
            type: 'string',
            description: 'Optional binding rule to apply.'
          },
          major_version_number__v: {
            type: 'string',
            description: 'Major version number if binding_rule is specific.'
          },
          minor_version_number__v: {
            type: 'string',
            description: 'Minor version number if binding_rule is specific.'
          }
        },
        required: ['binder_id', 'node_id']
      }
    }
  }
};

export { apiTool };