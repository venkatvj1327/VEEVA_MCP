/**
 * Function to export a package from Veeva Vault.
 *
 * @param {Object} args - Arguments for the export package request.
 * @param {string} args.packageName - The name of the Outbound Package to export.
 * @returns {Promise<Object>} - The result of the export package request.
 */
const executeFunction = async ({ packageName }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/services/package`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the request body
    const body = new URLSearchParams();
    body.append('packageName', packageName);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error exporting package:', error);
    return {
      error: `An error occurred while exporting the package: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for exporting a package from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'export_package',
      description: 'Export a package from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          packageName: {
            type: 'string',
            description: 'The name of the Outbound Package to export.'
          }
        },
        required: ['packageName']
      }
    }
  }
};

export { apiTool };