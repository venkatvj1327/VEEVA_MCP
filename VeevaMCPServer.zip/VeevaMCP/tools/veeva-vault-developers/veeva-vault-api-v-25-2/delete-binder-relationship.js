/**
 * Function to delete a binder relationship in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.binder_id - The ID of the binder.
 * @param {string} args.major_version - The major version number of the binder.
 * @param {string} args.minor_version - The minor version number of the binder.
 * @param {string} args.relationship_id - The ID of the relationship to be deleted.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ binder_id, major_version, minor_version, relationship_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL for the DELETE request
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/versions/${major_version}/${minor_version}/relationships/${relationship_id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return success response
    return { message: 'Binder relationship deleted successfully.' };
  } catch (error) {
    console.error('Error deleting binder relationship:', error);
    return {
      error: `An error occurred while deleting the binder relationship: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting a binder relationship in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_binder_relationship',
      description: 'Delete a binder relationship in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the binder.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the binder.'
          },
          relationship_id: {
            type: 'string',
            description: 'The ID of the relationship to be deleted.'
          }
        },
        required: ['binder_id', 'major_version', 'minor_version', 'relationship_id']
      }
    }
  }
};

export { apiTool };