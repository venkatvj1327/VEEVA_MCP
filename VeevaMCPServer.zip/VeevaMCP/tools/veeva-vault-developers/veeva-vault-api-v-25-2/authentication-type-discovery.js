/**
 * Function to discover the authentication type for a user in Veeva Vault.
 *
 * @param {Object} args - Arguments for the authentication discovery.
 * @param {string} args.username - The username of the user.
 * @param {string} args.client_id - The client ID for the request.
 * @returns {Promise<Object>} - The result of the authentication type discovery.
 */
const executeFunction = async ({ username, client_id }) => {
  const url = 'https://login.veevavault.com/auth/discovery';
  const clientId = ''; // will be provided by the user
  try {
    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Set up the request body
    const body = new URLSearchParams();
    body.append('username', username);
    body.append('client_id', client_id);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error discovering authentication type:', error);
    return {
      error: `An error occurred while discovering authentication type: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for discovering authentication type in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'discover_auth_type',
      description: 'Discover the authentication type for a user in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          username: {
            type: 'string',
            description: 'The username of the user.'
          },
          client_id: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['username', 'client_id']
      }
    }
  }
};

export { apiTool };