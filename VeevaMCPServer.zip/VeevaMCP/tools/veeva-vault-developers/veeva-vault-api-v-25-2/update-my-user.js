/**
 * Function to update the currently authenticated user's information in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.company__v - The company information to update for the user.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ company__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/users/me`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body of the request
    const body = new URLSearchParams();
    if (company__v) {
      body.append('company__v', company__v);
    }

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating user information:', error);
    return {
      error: `An error occurred while updating user information: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating user information in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_my_user',
      description: 'Update information for the currently authenticated user in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          company__v: {
            type: 'string',
            description: 'The company information to update for the user.'
          }
        },
        required: []
      }
    }
  }
};

export { apiTool };