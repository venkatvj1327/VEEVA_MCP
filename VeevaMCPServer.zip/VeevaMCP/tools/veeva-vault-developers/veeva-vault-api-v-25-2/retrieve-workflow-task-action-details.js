/**
 * Function to retrieve workflow task action details from Veeva Vault API.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.task_id - The ID of the workflow task.
 * @param {string} args.task_action - The name of the task action.
 * @param {boolean} [args.loc=false] - When true, retrieves localized strings if available.
 * @returns {Promise<Object>} - The details of the workflow task action.
 */
const executeFunction = async ({ task_id, task_action, loc = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path variables
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/objectworkflows/tasks/${task_id}/actions/${task_action}`);
    if (loc) {
      url.searchParams.append('loc', 'true');
    }

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving workflow task action details:', error);
    return {
      error: `An error occurred while retrieving workflow task action details: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving workflow task action details from Veeva Vault API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_workflow_task_action_details',
      description: 'Retrieve details of a specific workflow task action.',
      parameters: {
        type: 'object',
        properties: {
          task_id: {
            type: 'string',
            description: 'The ID of the workflow task.'
          },
          task_action: {
            type: 'string',
            description: 'The name of the task action.'
          },
          loc: {
            type: 'boolean',
            description: 'When true, retrieves localized strings if available.'
          }
        },
        required: ['task_id', 'task_action']
      }
    }
  }
};

export { apiTool };