/**
 * Function to create a document attachment in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating the document attachment.
 * @param {string} args.doc_id - The ID of the document to attach the file to.
 * @param {Buffer} args.file - The file to be attached.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @returns {Promise<Object>} - The result of the attachment creation.
 */
const executeFunction = async ({ doc_id, file, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/attachments`;

  const formData = new FormData();
  formData.append('file', file);

  const headers = {
    'Accept': 'application/json',
    'Authorization': sessionId,
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating document attachment:', error);
    return {
      error: `An error occurred while creating the document attachment: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating document attachments in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_document_attachment',
      description: 'Create a document attachment in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The ID of the document to attach the file to.'
          },
          file: {
            type: 'string',
            description: 'The file to be attached.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          }
        },
        required: ['doc_id', 'file', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };