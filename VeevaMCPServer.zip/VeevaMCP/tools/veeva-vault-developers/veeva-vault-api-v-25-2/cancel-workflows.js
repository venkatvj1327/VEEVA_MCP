/**
 * Function to cancel workflows in Veeva Vault.
 *
 * @param {Object} args - Arguments for the cancellation.
 * @param {string} args.workflow_ids - A comma-separated list of workflow_id__v field values (maximum 500 workflows).
 * @param {string} [args.cancellation_comment] - A comment for cancellation if required.
 * @returns {Promise<Object>} - The result of the workflow cancellation.
 */
const executeFunction = async ({ workflow_ids, cancellation_comment }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/object/workflow/actions/cancelworkflows`;

    // Prepare the form data
    const formData = new URLSearchParams();
    formData.append('workflow_ids', workflow_ids);
    if (cancellation_comment) {
      formData.append('cancellation_comment', cancellation_comment);
    }

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId,
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData,
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error canceling workflows:', error);
    return {
      error: `An error occurred while canceling workflows: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for canceling workflows in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'cancel_workflows',
      description: 'Cancel workflows in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          workflow_ids: {
            type: 'string',
            description: 'A comma-separated list of workflow_id__v field values (maximum 500 workflows).'
          },
          cancellation_comment: {
            type: 'string',
            description: 'A comment for cancellation if required.'
          }
        },
        required: ['workflow_ids']
      }
    }
  }
};

export { apiTool };