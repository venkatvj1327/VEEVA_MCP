/**
 * Function to delete a specific client code distribution in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.distribution_name - The name of the client code distribution to delete.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ distribution_name }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the DELETE request
    const url = `https://${vaultDNS}/api/${version}/uicode/distributions/${distribution_name}`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return a success message or response
    return { message: 'Distribution deleted successfully.' };
  } catch (error) {
    console.error('Error deleting distribution:', error);
    return {
      error: `An error occurred while deleting the distribution: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting a client code distribution in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_client_code_distribution',
      description: 'Delete a specific client code distribution in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          distribution_name: {
            type: 'string',
            description: 'The name of the client code distribution to delete.'
          }
        },
        required: ['distribution_name']
      }
    }
  }
};

export { apiTool };