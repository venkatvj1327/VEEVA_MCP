/**
 * Function to assign users and groups to roles on multiple documents and binders in bulk.
 *
 * @param {Object} args - Arguments for the assignment.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.csvData - The CSV data to be sent in the request body.
 * @returns {Promise<Object>} - The result of the assignment operation.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, csvData }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/roles/batch`;
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId
  };

  const body = new URLSearchParams();
  body.append('csvData', csvData);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error assigning users and groups to roles:', error);
    return {
      error: `An error occurred while assigning users and groups to roles: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for assigning users and groups to roles on documents and binders.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'assign_users_groups_to_roles',
      description: 'Assign users and groups to roles on multiple documents and binders in bulk.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          csvData: {
            type: 'string',
            description: 'The CSV data to be sent in the request body.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version', 'csvData']
      }
    }
  }
};

export { apiTool };