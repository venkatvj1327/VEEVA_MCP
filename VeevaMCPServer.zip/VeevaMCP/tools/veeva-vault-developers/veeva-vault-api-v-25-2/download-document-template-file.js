/**
 * Function to download a document template file from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.template_name - The name of the document template to download.
 * @returns {Promise<Object>} - The result of the download operation.
 */
const executeFunction = async ({ template_name }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/documents/templates/${template_name}/file`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading document template file:', error);
    return {
      error: `An error occurred while downloading the document template file: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading document template files from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_document_template_file',
      description: 'Download a document template file from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          template_name: {
            type: 'string',
            description: 'The name of the document template to download.'
          }
        },
        required: ['template_name']
      }
    }
  }
};

export { apiTool };