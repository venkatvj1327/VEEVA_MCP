/**
 * Function to disable a user in Veeva Vault.
 *
 * @param {Object} args - Arguments for disabling a user.
 * @param {string} args.user_id - The ID of the user to disable.
 * @param {boolean} [args.domain=false] - When true, disables the user account in all vaults in the domain.
 * @returns {Promise<Object>} - The result of the disable user operation.
 */
const executeFunction = async ({ user_id, domain = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/users/${user_id}`;
    
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Set up query parameters
    const queryParams = new URLSearchParams();
    if (domain) {
      queryParams.append('domain', 'true');
    }

    // Perform the fetch request
    const response = await fetch(`${url}?${queryParams.toString()}`, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response data
    return await response.json();
  } catch (error) {
    console.error('Error disabling user:', error);
    return {
      error: `An error occurred while disabling the user: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for disabling a user in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'disable_user',
      description: 'Disable a user in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          user_id: {
            type: 'string',
            description: 'The ID of the user to disable.'
          },
          domain: {
            type: 'boolean',
            description: 'When true, disables the user account in all vaults in the domain.'
          }
        },
        required: ['user_id']
      }
    }
  }
};

export { apiTool };