/**
 * Function to submit a VQL query to the Veeva Vault API.
 *
 * @param {Object} args - Arguments for the query submission.
 * @param {string} args.query - The VQL query to be submitted.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @returns {Promise<Object>} - The result of the query submission.
 */
const executeFunction = async ({ query, sessionId, clientId, vaultDNS, version }) => {
  const url = `https://${vaultDNS}/api/${version}/query`;
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-DescribeQuery': 'true',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId
  };

  const body = new URLSearchParams();
  body.append('q', query);

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error submitting query:', error);
    return {
      error: `An error occurred while submitting the query: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for submitting a VQL query to the Veeva Vault API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'submit_query',
      description: 'Submit a VQL query to the Veeva Vault API.',
      parameters: {
        type: 'object',
        properties: {
          query: {
            type: 'string',
            description: 'The VQL query to be submitted.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['query', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };