/**
 * Function to retrieve workflow actions from Veeva Vault API.
 *
 * @param {Object} args - Arguments for the workflow actions retrieval.
 * @param {string} args.workflow_id - The ID of the workflow to retrieve actions for.
 * @param {string} [args.loc] - When localized strings are available, set to true to retrieve them.
 * @returns {Promise<Object>} - The result of the workflow actions retrieval.
 */
const executeFunction = async ({ workflow_id, loc }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with the workflow ID
    const url = `https://${vaultDNS}/api/${version}/objects/objectworkflows/${workflow_id}/actions`;
    
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // If loc is provided, append it as a query parameter
    const queryParams = loc ? `?loc=${loc}` : '';
    
    // Perform the fetch request
    const response = await fetch(url + queryParams, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving workflow actions:', error);
    return {
      error: `An error occurred while retrieving workflow actions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving workflow actions from Veeva Vault API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_workflow_actions',
      description: 'Retrieve all available workflow actions for a specific object workflow.',
      parameters: {
        type: 'object',
        properties: {
          workflow_id: {
            type: 'string',
            description: 'The ID of the workflow to retrieve actions for.'
          },
          loc: {
            type: 'string',
            description: 'When localized strings are available, set to true to retrieve them.'
          }
        },
        required: ['workflow_id']
      }
    }
  }
};

export { apiTool };