/**
 * Function to replace the workflow owner in Veeva Vault.
 *
 * @param {Object} args - Arguments for the workflow owner replacement.
 * @param {string} args.current_workflow_owner__v - The ID of the current workflow owner.
 * @param {string} args.new_workflow_owner__v - The ID of the new workflow owner.
 * @returns {Promise<Object>} - The result of the workflow owner replacement action.
 */
const executeFunction = async ({ current_workflow_owner__v, new_workflow_owner__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/object/workflow/actions/replaceworkflowowner`;

    // Prepare the request body
    const body = new URLSearchParams();
    body.append('current_workflow_owner__v', current_workflow_owner__v);
    body.append('new_workflow_owner__v', new_workflow_owner__v);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId,
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString(),
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error replacing workflow owner:', error);
    return {
      error: `An error occurred while replacing the workflow owner: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for replacing workflow owner in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'replace_workflow_owner',
      description: 'Replace the workflow owner in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          current_workflow_owner__v: {
            type: 'string',
            description: 'The ID of the current workflow owner.'
          },
          new_workflow_owner__v: {
            type: 'string',
            description: 'The ID of the new workflow owner.'
          }
        },
        required: ['current_workflow_owner__v', 'new_workflow_owner__v']
      }
    }
  }
};

export { apiTool };