/**
 * Function to download an object record attachment version file from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.object_name - The object name (e.g., product__v, country__v).
 * @param {string} args.object_record_id - The object record ID.
 * @param {string} args.attachment_id - The attachment ID.
 * @param {string} args.attachment_version - The attachment version.
 * @returns {Promise<Object>} - The result of the download request.
 */
const executeFunction = async ({ object_name, object_record_id, attachment_id, attachment_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/attachments/${attachment_id}/versions/${attachment_version}/file`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading attachment version file:', error);
    return {
      error: `An error occurred while downloading the attachment version file: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading object record attachment version file from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_attachment_version_file',
      description: 'Download an object record attachment version file from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name (e.g., product__v, country__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The object record ID.'
          },
          attachment_id: {
            type: 'string',
            description: 'The attachment ID.'
          },
          attachment_version: {
            type: 'string',
            description: 'The attachment version.'
          }
        },
        required: ['object_name', 'object_record_id', 'attachment_id', 'attachment_version']
      }
    }
  }
};

export { apiTool };