/**
 * Function to assign users and groups to roles on a single binder in Veeva Vault.
 *
 * @param {Object} args - Arguments for assigning users and groups.
 * @param {string} args.id - The ID of the binder to which roles will be assigned.
 * @param {string} args.role_name__v_users - The users to assign to the role, formatted as "userId1,userId2".
 * @param {string} args.role_name__v_groups - The groups to assign to the role, formatted as "groupId1,groupId2".
 * @returns {Promise<Object>} - The result of the assignment operation.
 */
const executeFunction = async ({ id, role_name__v_users, role_name__v_groups }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${id}/roles`;

    // Prepare the form data
    const formData = new URLSearchParams();
    if (role_name__v_users) {
      formData.append('role_name__v.users', role_name__v_users);
    }
    if (role_name__v_groups) {
      formData.append('role_name__v.groups', role_name__v_groups);
    }

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId,
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error assigning users and groups to roles:', error);
    return {
      error: `An error occurred while assigning users and groups to roles: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for assigning users and groups to roles on a single binder in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'assign_users_groups_to_roles_single_binder',
      description: 'Assign users and groups to roles on a single binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          id: {
            type: 'string',
            description: 'The ID of the binder to which roles will be assigned.'
          },
          role_name__v_users: {
            type: 'string',
            description: 'The users to assign to the role, formatted as "userId1,userId2".'
          },
          role_name__v_groups: {
            type: 'string',
            description: 'The groups to assign to the role, formatted as "groupId1,groupId2".'
          }
        },
        required: ['id']
      }
    }
  }
};

export { apiTool };