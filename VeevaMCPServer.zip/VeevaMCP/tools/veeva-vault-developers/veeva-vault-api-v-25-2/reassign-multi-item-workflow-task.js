/**
 * Function to reassign a multi-item workflow task in Veeva Vault.
 *
 * @param {Object} args - Arguments for the reassignment.
 * @param {string} args.task_id - The ID of the task to reassign.
 * @param {string} args.task_assignee - The ID of the user who will become the new task assignee, in the format user:{id}.
 * @returns {Promise<Object>} - The result of the reassignment.
 */
const executeFunction = async ({ task_id, task_assignee }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/objectworkflows/tasks/${task_id}/actions/mdwreassign`;

    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    const body = new URLSearchParams();
    body.append('task_assignee__v', task_assignee);

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error reassigning the workflow task:', error);
    return {
      error: `An error occurred while reassigning the workflow task: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for reassigning a multi-item workflow task in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'reassign_multi_item_workflow_task',
      description: 'Reassign a multi-item workflow task in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          task_id: {
            type: 'string',
            description: 'The ID of the task to reassign.'
          },
          task_assignee: {
            type: 'string',
            description: 'The ID of the user who will become the new task assignee, in the format user:{id}.'
          }
        },
        required: ['task_id', 'task_assignee']
      }
    }
  }
};

export { apiTool };