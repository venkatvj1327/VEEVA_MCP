/**
 * Function to recalculate roll-up fields for a specified object in Veeva Vault.
 *
 * @param {Object} args - Arguments for the recalculation.
 * @param {string} args.object_name - The name of the object on which to start the Roll-up field recalculation.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID to identify the request.
 * @returns {Promise<Object>} - The result of the roll-up field recalculation.
 */
const executeFunction = async ({ object_name, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // specify the API version
  const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/actions/recalculaterollups`;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error recalculating roll-up fields:', error);
    return {
      error: `An error occurred while recalculating roll-up fields: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for recalculating roll-up fields in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'recalculate_rollup_fields',
      description: 'Recalculate roll-up fields for a specified object in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object on which to start the Roll-up field recalculation.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID to identify the request.'
          }
        },
        required: ['object_name', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };