/**
 * Function to retrieve object record attachment versions from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.object_name - The object name (e.g., product__v, country__v).
 * @param {string} args.object_record_id - The ID of the object record.
 * @param {string} args.attachment_id - The ID of the attachment.
 * @returns {Promise<Object>} - The result of the retrieval operation.
 */
const executeFunction = async ({ vaultDNS, version, object_name, object_record_id, attachment_id }) => {
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const baseUrl = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/attachments/${attachment_id}/versions`;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving attachment versions:', error);
    return {
      error: `An error occurred while retrieving attachment versions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving object record attachment versions from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_attachment_versions',
      description: 'Retrieve object record attachment versions from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          object_name: {
            type: 'string',
            description: 'The object name (e.g., product__v, country__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The ID of the object record.'
          },
          attachment_id: {
            type: 'string',
            description: 'The ID of the attachment.'
          }
        },
        required: ['vaultDNS', 'version', 'object_name', 'object_record_id', 'attachment_id']
      }
    }
  }
};

export { apiTool };