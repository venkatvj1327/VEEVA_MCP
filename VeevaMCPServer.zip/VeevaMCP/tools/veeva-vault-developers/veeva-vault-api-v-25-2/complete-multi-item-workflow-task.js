/**
 * Function to complete a multi-item workflow task in Veeva Vault.
 *
 * @param {Object} args - Arguments for completing the workflow task.
 * @param {string} args.task_id - The ID of the task to complete.
 * @param {Object} args.body - The body parameters for the workflow task completion.
 * @param {string} args.body.verdict_public_key__c - The verdict name.
 * @param {string} [args.body.reason__c] - The reason name (optional).
 * @param {string} [args.body.capacity__c] - The capacity name (optional).
 * @returns {Promise<Object>} - The result of the workflow task completion.
 */
const executeFunction = async ({ task_id, body }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/objectworkflows/tasks/${task_id}/actions/mdwcomplete`;

    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error completing workflow task:', error);
    return {
      error: `An error occurred while completing the workflow task: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for completing a multi-item workflow task in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'complete_multi_item_workflow_task',
      description: 'Complete a multi-item workflow task in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          task_id: {
            type: 'string',
            description: 'The ID of the task to complete.'
          },
          body: {
            type: 'object',
            properties: {
              verdict_public_key__c: {
                type: 'string',
                description: 'The verdict name.'
              },
              reason__c: {
                type: 'string',
                description: 'The reason name (optional).'
              },
              capacity__c: {
                type: 'string',
                description: 'The capacity name (optional).'
              }
            },
            required: ['verdict_public_key__c']
          }
        },
        required: ['task_id', 'body']
      }
    }
  }
};

export { apiTool };