/**
 * Function to retrieve document event subtype metadata from Veeva Vault API.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.event_type - The event type (e.g., distribution__v).
 * @param {string} args.event_subtype - The event subtype (e.g., approved_email__v).
 * @returns {Promise<Object>} - The metadata of the document event subtype.
 */
const executeFunction = async ({ event_type, event_subtype }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path variables
    const url = `https://${vaultDNS}/api/${version}/metadata/objects/documents/events/${event_type}/types/${event_subtype}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving document event subtype metadata:', error);
    return {
      error: `An error occurred while retrieving metadata: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document event subtype metadata from Veeva Vault API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_event_subtype_metadata',
      description: 'Retrieve document event subtype metadata from Veeva Vault API.',
      parameters: {
        type: 'object',
        properties: {
          event_type: {
            type: 'string',
            description: 'The event type (e.g., distribution__v).'
          },
          event_subtype: {
            type: 'string',
            description: 'The event subtype (e.g., approved_email__v).'
          }
        },
        required: ['event_type', 'event_subtype']
      }
    }
  }
};

export { apiTool };