/**
 * Function to retrieve details from all object types in Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @returns {Promise<Object>} - The response from the Veeva Vault API.
 */
const executeFunction = async ({ vaultDNS, version, sessionId, clientId }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/configuration/Objecttype`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving details from all object types:', error);
    return {
      error: `An error occurred while retrieving details: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving details from all object types in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_object_types',
      description: 'Retrieve details from all object types in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          }
        },
        required: ['vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };