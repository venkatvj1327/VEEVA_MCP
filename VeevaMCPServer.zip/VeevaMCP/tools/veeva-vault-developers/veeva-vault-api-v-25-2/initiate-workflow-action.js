/**
 * Function to initiate a workflow action on a specific object workflow in Veeva Vault.
 *
 * @param {Object} args - Arguments for the workflow action.
 * @param {string} args.workflow_id - The ID of the workflow.
 * @param {string} args.workflow_action - The name of the workflow action.
 * @param {string} [args.documents__sys] - Comma-separated list of document IDs to be removed from the workflow (if applicable).
 * @returns {Promise<Object>} - The result of the workflow action initiation.
 */
const executeFunction = async ({ workflow_id, workflow_action, documents__sys }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/objectworkflows/${workflow_id}/actions/${workflow_action}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body of the request
    const body = new URLSearchParams();
    if (documents__sys) {
      body.append('documents__sys', documents__sys);
    }

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error initiating workflow action:', error);
    return {
      error: `An error occurred while initiating the workflow action: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for initiating a workflow action in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'initiate_workflow_action',
      description: 'Initiate a workflow action on a specific object workflow in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          workflow_id: {
            type: 'string',
            description: 'The ID of the workflow.'
          },
          workflow_action: {
            type: 'string',
            description: 'The name of the workflow action.'
          },
          documents__sys: {
            type: 'string',
            description: 'Comma-separated list of document IDs to be removed from the workflow (if applicable).'
          }
        },
        required: ['workflow_id', 'workflow_action']
      }
    }
  }
};

export { apiTool };