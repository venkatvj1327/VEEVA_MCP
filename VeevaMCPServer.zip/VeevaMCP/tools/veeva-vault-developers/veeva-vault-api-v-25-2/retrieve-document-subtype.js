/**
 * Function to retrieve metadata from a document subtype in Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.type - The document type.
 * @param {string} args.subtype - The document subtype.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @returns {Promise<Object>} - The metadata of the document subtype.
 */
const executeFunction = async ({ type, subtype, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  try {
    // Construct the URL with path parameters
    const url = `https://${vaultDNS}/api/${version}/metadata/objects/documents/types/${type}/subtypes/${subtype}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving document subtype:', error);
    return {
      error: `An error occurred while retrieving the document subtype: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document subtype metadata in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_subtype',
      description: 'Retrieve metadata from a document subtype in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          type: {
            type: 'string',
            description: 'The document type.'
          },
          subtype: {
            type: 'string',
            description: 'The document subtype.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          }
        },
        required: ['type', 'subtype', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };