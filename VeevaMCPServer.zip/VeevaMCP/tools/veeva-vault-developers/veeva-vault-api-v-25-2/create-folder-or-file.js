/**
 * Function to create a folder or file in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating a folder or file.
 * @param {File} args.file - The file to upload (maximum size 50MB).
 * @param {string} args.kind - The kind of item to create (either 'file' or 'folder').
 * @param {string} args.path - The absolute path to place the item in the file staging server.
 * @param {boolean} [args.overwrite=false] - If true, overwrite any existing files with the same name.
 * @returns {Promise<Object>} - The result of the create folder or file operation.
 */
const executeFunction = async ({ file, kind, path, overwrite = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/services/file_staging/items`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId,
    };

    // Create FormData to handle file upload
    const formData = new FormData();
    if (file) {
      formData.append('file', file);
    }
    formData.append('kind', kind);
    formData.append('path', path);
    formData.append('overwrite', overwrite.toString());

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData,
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating folder or file:', error);
    return {
      error: `An error occurred while creating the folder or file: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a folder or file in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_folder_or_file',
      description: 'Create a folder or file in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          file: {
            type: 'string',
            description: 'The file to upload (maximum size 50MB).'
          },
          kind: {
            type: 'string',
            enum: ['file', 'folder'],
            description: 'The kind of item to create.'
          },
          path: {
            type: 'string',
            description: 'The absolute path to place the item in the file staging server.'
          },
          overwrite: {
            type: 'boolean',
            description: 'If true, overwrite any existing files with the same name.'
          }
        },
        required: ['file', 'kind', 'path']
      }
    }
  }
};

export { apiTool };