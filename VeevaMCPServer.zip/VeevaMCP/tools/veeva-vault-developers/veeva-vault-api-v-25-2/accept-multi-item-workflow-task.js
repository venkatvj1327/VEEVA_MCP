/**
 * Function to accept a multi-item workflow task in Veeva Vault.
 *
 * @param {Object} args - Arguments for accepting the workflow task.
 * @param {string} args.task_id - The ID of the task to accept.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault instance.
 * @param {string} args.version - The API version to use.
 * @returns {Promise<Object>} - The result of the task acceptance.
 */
const executeFunction = async ({ task_id, sessionId, clientId, vaultDNS, version }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/objects/objectworkflows/tasks/${task_id}/actions/mdwaccept`;
  
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error accepting workflow task:', error);
    return {
      error: `An error occurred while accepting the workflow task: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for accepting a multi-item workflow task in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'accept_multi_item_workflow_task',
      description: 'Accept a multi-item workflow task in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          task_id: {
            type: 'string',
            description: 'The ID of the task to accept.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault instance.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['task_id', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };