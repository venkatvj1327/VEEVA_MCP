/**
 * Function to delete multiple annotations in Veeva Vault.
 *
 * @param {Object} args - Arguments for the delete annotations request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault instance.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {Buffer} args.fileData - The binary data of the CSV file containing annotations to delete.
 * @returns {Promise<Object>} - The result of the delete annotations request.
 */
const executeFunction = async ({ vaultDNS, version, sessionId, clientId, fileData }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/annotations/batch`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers,
      body: fileData // Sending the binary file data
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error deleting annotations:', error);
    return {
      error: `An error occurred while deleting annotations: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting annotations in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_annotations',
      description: 'Delete multiple annotations in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault instance.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          fileData: {
            type: 'string',
            description: 'The binary data of the CSV file containing annotations to delete.'
          }
        },
        required: ['vaultDNS', 'version', 'sessionId', 'clientId', 'fileData']
      }
    }
  }
};

export { apiTool };