/**
 * Function to retrieve a binder from Veeva Vault.
 *
 * @param {Object} args - Arguments for the binder retrieval.
 * @param {string} args.binder_id - The ID of the binder to retrieve.
 * @param {string} [args.depth] - To retrieve all information in all levels of the binder, set this to 'all'. By default, only one level is returned.
 * @returns {Promise<Object>} - The result of the binder retrieval.
 */
const executeFunction = async ({ binder_id, depth }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/binders/${binder_id}`);
    if (depth) {
      url.searchParams.append('depth', depth);
    }

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving binder:', error);
    return {
      error: `An error occurred while retrieving the binder: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving a binder from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_binder',
      description: 'Retrieve a binder from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder to retrieve.'
          },
          depth: {
            type: 'string',
            description: 'To retrieve all information in all levels of the binder, set this to "all". By default, only one level is returned.'
          }
        },
        required: ['binder_id']
      }
    }
  }
};

export { apiTool };