/**
 * Function to retrieve annotation reference type metadata from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.reference_type - The reference type to retrieve metadata for.
 * @returns {Promise<Object>} - The metadata of the specified annotation reference type.
 */
const executeFunction = async ({ reference_type }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with the reference type
    const url = `https://${vaultDNS}/api/${version}/metadata/objects/documents/annotations/references/types/${reference_type}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving annotation reference type metadata:', error);
    return {
      error: `An error occurred while retrieving metadata: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving annotation reference type metadata from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_annotation_reference_type_metadata',
      description: 'Retrieve metadata for a specified annotation reference type.',
      parameters: {
        type: 'object',
        properties: {
          reference_type: {
            type: 'string',
            description: 'The reference type to retrieve metadata for.'
          }
        },
        required: ['reference_type']
      }
    }
  }
};

export { apiTool };