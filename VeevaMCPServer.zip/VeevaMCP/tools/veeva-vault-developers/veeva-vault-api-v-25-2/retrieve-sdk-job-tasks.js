/**
 * Function to retrieve SDK job tasks from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.job_id - The ID of the SDK job.
 * @param {string} [args.vaultDNS] - The DNS of the Veeva Vault.
 * @param {string} [args.version] - The API version to use.
 * @param {string} [args.sessionId] - The session ID for authorization.
 * @param {string} [args.clientId] - The client ID for the request.
 * @returns {Promise<Object>} - The result of the SDK job tasks retrieval.
 */
const executeFunction = async ({ job_id, vaultDNS, version, sessionId, clientId }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/services/jobs/${job_id}/tasks`;
  const token = process.env.VEEVA_VAULT_DEVELOPERS_API_KEY;
  const client = ''; // will be provided by the user

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving SDK job tasks:', error);
    return {
      error: `An error occurred while retrieving SDK job tasks: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving SDK job tasks from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_sdk_job_tasks',
      description: 'Retrieve the tasks associated with an SDK job.',
      parameters: {
        type: 'object',
        properties: {
          job_id: {
            type: 'string',
            description: 'The ID of the SDK job.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['job_id', 'vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };