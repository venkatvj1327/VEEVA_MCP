/**
 * Function to remove users and groups from roles on multiple documents and binders in bulk.
 *
 * @param {Object} args - Arguments for the removal.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {Buffer} args.csvData - The CSV data containing users and groups to remove.
 * @returns {Promise<Object>} - The result of the removal operation.
 */
const executeFunction = async ({ sessionId, clientId, csvData }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/objects/documents/roles/batch`;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'text/csv',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers,
      body: csvData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error removing users and groups from roles:', error);
    return {
      error: `An error occurred while removing users and groups from roles: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for removing users and groups from roles on multiple documents and binders.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'remove_users_groups_from_roles',
      description: 'Remove users and groups from roles on multiple documents and binders in bulk.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          csvData: {
            type: 'string',
            description: 'The CSV data containing users and groups to remove.'
          }
        },
        required: ['sessionId', 'clientId', 'csvData']
      }
    }
  }
};

export { apiTool };