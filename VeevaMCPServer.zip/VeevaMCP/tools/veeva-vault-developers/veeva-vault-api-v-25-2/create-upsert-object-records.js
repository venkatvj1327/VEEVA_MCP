/**
 * Function to create or upsert object records in Veeva Vault.
 *
 * @param {Object} args - Arguments for the upsert operation.
 * @param {string} args.object_name - The name of the object to create or upsert records for.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.idParam - The unique field name for upserting records.
 * @param {Buffer} args.fileData - The CSV file data to be uploaded.
 * @returns {Promise<Object>} - The result of the create or upsert operation.
 */
const executeFunction = async ({ object_name, sessionId, clientId, idParam, fileData }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}${idParam ? `?idParam=${idParam}` : ''}`;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'text/csv',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: fileData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating or upserting object records:', error);
    return {
      error: `An error occurred while creating or upserting object records: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating or upserting object records in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_upsert_object_records',
      description: 'Create or upsert object records in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object to create or upsert records for.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          idParam: {
            type: 'string',
            description: 'The unique field name for upserting records.'
          },
          fileData: {
            type: 'string',
            format: 'binary',
            description: 'The CSV file data to be uploaded.'
          }
        },
        required: ['object_name', 'sessionId', 'clientId', 'fileData']
      }
    }
  }
};

export { apiTool };