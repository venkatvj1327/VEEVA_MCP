/**
 * Function to import document version annotations from a PDF to Veeva Vault.
 *
 * @param {Object} args - Arguments for the import.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.major_version - The major version number of the document.
 * @param {string} args.minor_version - The minor version number of the document.
 * @param {File} args.file - The PDF file containing annotations to import.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for API usage logs.
 * @returns {Promise<Object>} - The result of the import operation.
 */
const executeFunction = async ({ doc_id, major_version, minor_version, file, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/annotations/file`;

  const formData = new FormData();
  formData.append('file', file);

  try {
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId,
    };

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error importing document version annotations:', error);
    return {
      error: `An error occurred while importing annotations: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for importing document version annotations to Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'import_document_annotations',
      description: 'Import document version annotations from a PDF to Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the document.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the document.'
          },
          file: {
            type: 'string',
            description: 'The PDF file containing annotations to import.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for API usage logs.'
          }
        },
        required: ['doc_id', 'major_version', 'minor_version', 'file', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };