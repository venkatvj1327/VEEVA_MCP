/**
 * Function to read replies of a parent annotation from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.major_version - The major version number of the document.
 * @param {string} args.minor_version - The minor version number of the document.
 * @param {string} args.annotation_id - The parent annotation ID.
 * @returns {Promise<Object>} - The response containing replies to the specified annotation.
 */
const executeFunction = async ({ vaultDNS, version, doc_id, major_version, minor_version, annotation_id }) => {
  const token = process.env.VEEVA_VAULT_DEVELOPERS_API_KEY;
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/annotations/${annotation_id}/replies`;

  try {
    const headers = {
      'Authorization': token,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error reading replies of parent annotation:', error);
    return {
      error: `An error occurred while reading replies: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for reading replies of a parent annotation from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'read_replies_of_parent_annotation',
      description: 'Read replies of a parent annotation from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the document.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the document.'
          },
          annotation_id: {
            type: 'string',
            description: 'The parent annotation ID.'
          }
        },
        required: ['vaultDNS', 'version', 'doc_id', 'major_version', 'minor_version', 'annotation_id']
      }
    }
  }
};

export { apiTool };