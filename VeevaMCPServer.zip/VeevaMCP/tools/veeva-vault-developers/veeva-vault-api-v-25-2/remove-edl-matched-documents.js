/**
 * Function to remove EDL matched documents from Veeva Vault.
 *
 * @param {Object} args - Arguments for the removal.
 * @param {Array} args.documents - An array of document objects to be removed, each containing id, document_id, major_version_number__v, minor_version_number__v, and remove_locked.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @returns {Promise<Object>} - The result of the removal operation.
 */
const executeFunction = async ({ documents, sessionId, clientId, vaultDNS, version }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/edl_matched_documents/batch/actions/remove`;
  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  const body = JSON.stringify(documents);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error removing EDL matched documents:', error);
    return {
      error: `An error occurred while removing EDL matched documents: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for removing EDL matched documents from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'remove_edl_matched_documents',
      description: 'Remove EDL matched documents from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          documents: {
            type: 'array',
            description: 'An array of document objects to be removed.',
            items: {
              type: 'object',
              properties: {
                id: { type: 'string', description: 'The ID of the document.' },
                document_id: { type: 'string', description: 'The document ID.' },
                major_version_number__v: { type: 'integer', description: 'The major version number.' },
                minor_version_number__v: { type: 'integer', description: 'The minor version number.' },
                remove_locked: { type: 'boolean', description: 'Flag to indicate if locked documents should be removed.' }
              },
              required: ['id', 'document_id', 'major_version_number__v', 'minor_version_number__v', 'remove_locked']
            }
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['documents', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };