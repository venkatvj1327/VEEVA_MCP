/**
 * Function to update a single document in Veeva Vault.
 *
 * @param {Object} args - Arguments for the document update.
 * @param {string} args.doc_id - The ID of the document to update.
 * @param {string} args.name__v - The new name for the document.
 * @param {string} [args.vaultDNS] - The DNS of the Vault.
 * @param {string} [args.version] - The API version.
 * @param {string} [args.sessionId] - The session ID for authorization.
 * @param {string} [args.clientId] - The client ID for tracking API usage.
 * @returns {Promise<Object>} - The result of the document update.
 */
const executeFunction = async ({ doc_id, name__v, vaultDNS, version, sessionId, clientId }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}`;
  const token = process.env.VEEVA_VAULT_DEVELOPERS_API_KEY;
  const clientID = ''; // will be provided by the user

  const formData = new URLSearchParams();
  if (name__v) {
    formData.append('name__v', name__v);
  }

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId || clientID
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'PUT',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating document:', error);
    return {
      error: `An error occurred while updating the document: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating a document in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_document',
      description: 'Update a single document in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The ID of the document to update.'
          },
          name__v: {
            type: 'string',
            description: 'The new name for the document.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for tracking API usage.'
          }
        },
        required: ['doc_id', 'name__v']
      }
    }
  }
};

export { apiTool };