/**
 * Function to retrieve annotation placemark type metadata from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.placemark_type - The name of the placemark type to retrieve metadata for.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID to identify the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @returns {Promise<Object>} - The metadata of the specified annotation placemark type.
 */
const executeFunction = async ({ placemark_type, sessionId, clientId, vaultDNS, version }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/metadata/objects/documents/annotations/placemarks/types/${placemark_type}`;
  
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving annotation placemark type metadata:', error);
    return {
      error: `An error occurred while retrieving annotation placemark type metadata: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving annotation placemark type metadata from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_annotation_placemark_metadata',
      description: 'Retrieve metadata for a specified annotation placemark type from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          placemark_type: {
            type: 'string',
            description: 'The name of the placemark type to retrieve metadata for.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID to identify the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['placemark_type', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };