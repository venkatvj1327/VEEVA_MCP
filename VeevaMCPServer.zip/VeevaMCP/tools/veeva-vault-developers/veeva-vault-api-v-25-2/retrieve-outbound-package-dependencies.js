/**
 * Function to retrieve outbound package dependencies from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.package_id - The ID of the outbound_package__v record from which to retrieve dependencies.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The Client ID to identify the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @returns {Promise<Object>} - The result of the outbound package dependencies retrieval.
 */
const executeFunction = async ({ package_id, sessionId, clientId, vaultDNS, version }) => {
  const url = `https://${vaultDNS}/api/${version}/vobjects/outbound_package__v/${package_id}/dependencies`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving outbound package dependencies:', error);
    return {
      error: `An error occurred while retrieving outbound package dependencies: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving outbound package dependencies from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_outbound_package_dependencies',
      description: 'Retrieve outbound package dependencies from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          package_id: {
            type: 'string',
            description: 'The ID of the outbound_package__v record from which to retrieve dependencies.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The Client ID to identify the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['package_id', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };