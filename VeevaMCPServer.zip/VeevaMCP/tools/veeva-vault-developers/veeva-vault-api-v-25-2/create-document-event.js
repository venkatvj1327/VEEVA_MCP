/**
 * Function to create a document event in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating the document event.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.major_version - The major version number of the document.
 * @param {string} args.minor_version - The minor version number of the document.
 * @param {string} args.event_type__v - The event type (e.g., distribution__v).
 * @param {string} args.event_subtype__v - The event subtype (e.g., approved_email__v).
 * @param {string} args.classification__v - The event classification.
 * @param {string} [args.external_id__v] - An optional external ID value for the document event.
 * @returns {Promise<Object>} - The result of the document event creation.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, doc_id, major_version, minor_version, event_type__v, event_subtype__v, classification__v, external_id__v }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/events`;
  
  const body = new URLSearchParams();
  body.append('event_type__v', event_type__v);
  body.append('event_subtype__v', event_subtype__v);
  body.append('classification__v', classification__v);
  if (external_id__v) {
    body.append('external_id__v', external_id__v);
  }

  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating document event:', error);
    return {
      error: `An error occurred while creating the document event: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a document event in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_document_event',
      description: 'Create a document event in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          },
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the document.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the document.'
          },
          event_type__v: {
            type: 'string',
            description: 'The event type (e.g., distribution__v).'
          },
          event_subtype__v: {
            type: 'string',
            description: 'The event subtype (e.g., approved_email__v).'
          },
          classification__v: {
            type: 'string',
            description: 'The event classification.'
          },
          external_id__v: {
            type: 'string',
            description: 'An optional external ID value for the document event.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version', 'doc_id', 'major_version', 'minor_version', 'event_type__v', 'event_subtype__v', 'classification__v']
      }
    }
  }
};

export { apiTool };