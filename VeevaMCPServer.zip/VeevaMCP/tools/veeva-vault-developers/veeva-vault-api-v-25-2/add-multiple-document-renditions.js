/**
 * Function to add multiple document renditions in bulk to Veeva Vault.
 *
 * @param {Object} args - Arguments for the document rendition upload.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {Buffer} args.fileData - The CSV file data to upload.
 * @param {boolean} [args.largeSizeAsset=false] - Indicates if the renditions are of the Large Size Asset type.
 * @param {string} [args.idParam] - External ID for identifying documents in the input.
 * @returns {Promise<Object>} - The result of the document rendition upload.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, fileData, largeSizeAsset = false, idParam }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/renditions/batch`;
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'text/csv',
    'X-VaultAPI-ClientID': clientId
  };

  // Add X-VaultAPI-MigrationMode header if necessary
  if (!largeSizeAsset) {
    headers['X-VaultAPI-MigrationMode'] = 'true';
  }

  const formData = new FormData();
  formData.append('file', fileData, { filename: 'renditions.csv' });

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error adding document renditions:', error);
    return {
      error: `An error occurred while adding document renditions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for adding multiple document renditions in bulk to Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'add_multiple_document_renditions',
      description: 'Add multiple document renditions in bulk to Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          fileData: {
            type: 'string',
            description: 'The CSV file data to upload.'
          },
          largeSizeAsset: {
            type: 'boolean',
            description: 'Indicates if the renditions are of the Large Size Asset type.'
          },
          idParam: {
            type: 'string',
            description: 'External ID for identifying documents in the input.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version', 'fileData']
      }
    }
  }
};

export { apiTool };