/**
 * Function to update the description of a document attachment in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.doc_id - The ID of the document.
 * @param {string} args.attachment_id - The ID of the attachment.
 * @param {string} args.description__v - The new description for the attachment (max 1000 characters).
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ doc_id, attachment_id, description__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/attachments/${attachment_id}`;
    
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    const body = new URLSearchParams();
    body.append('description__v', description__v);

    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: body.toString()
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    return await response.json();
  } catch (error) {
    console.error('Error updating document attachment description:', error);
    return {
      error: `An error occurred while updating the document attachment description: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating document attachment description in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_document_attachment_description',
      description: 'Update the description of a document attachment in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The ID of the document.'
          },
          attachment_id: {
            type: 'string',
            description: 'The ID of the attachment.'
          },
          description__v: {
            type: 'string',
            description: 'The new description for the attachment (max 1000 characters).'
          }
        },
        required: ['doc_id', 'attachment_id', 'description__v']
      }
    }
  }
};

export { apiTool };