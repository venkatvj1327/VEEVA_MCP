/**
 * Function to cancel workflow tasks in Veeva Vault.
 *
 * @param {Object} args - Arguments for the cancel workflow tasks request.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} [args.task_ids] - Comma-separated list of task IDs to cancel (optional).
 * @param {string} [args.user_ids] - Comma-separated list of user IDs to cancel tasks for (optional).
 * @returns {Promise<Object>} - The result of the cancel workflow tasks request.
 */
const executeFunction = async ({ sessionId, clientId, task_ids = '', user_ids = '' }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/object/workflow/actions/canceltasks`;
  
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId
  };

  const body = new URLSearchParams();
  if (task_ids) {
    body.append('task_ids', task_ids);
  }
  if (user_ids) {
    body.append('user_ids', user_ids);
  }

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error canceling workflow tasks:', error);
    return {
      error: `An error occurred while canceling workflow tasks: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for canceling workflow tasks in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'cancel_workflow_tasks',
      description: 'Cancel workflow tasks in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          task_ids: {
            type: 'string',
            description: 'Comma-separated list of task IDs to cancel (optional).'
          },
          user_ids: {
            type: 'string',
            description: 'Comma-separated list of user IDs to cancel tasks for (optional).'
          }
        },
        required: ['sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };