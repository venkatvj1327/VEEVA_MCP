/**
 * Function to download a specific version of a document attachment from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.doc_id - The ID of the document.
 * @param {string} args.attachment_id - The ID of the attachment.
 * @param {string} args.attachment_version - The version of the attachment to download.
 * @returns {Promise<Object>} - The response from the download request.
 */
const executeFunction = async ({ doc_id, attachment_id, attachment_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/attachments/${attachment_id}/versions/${attachment_version}/file`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId,
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading document attachment version:', error);
    return {
      error: `An error occurred while downloading the document attachment version: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading document attachment versions from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_document_attachment_version',
      description: 'Download a specific version of a document attachment from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The ID of the document.'
          },
          attachment_id: {
            type: 'string',
            description: 'The ID of the attachment.'
          },
          attachment_version: {
            type: 'string',
            description: 'The version of the attachment to download.'
          }
        },
        required: ['doc_id', 'attachment_id', 'attachment_version']
      }
    }
  }
};

export { apiTool };