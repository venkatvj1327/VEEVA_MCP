/**
 * Function to download a document rendition file from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.rendition_type - The type of rendition to download.
 * @param {boolean} [args.steadyState=false] - Set to true to download from the latest steady state version of the document.
 * @returns {Promise<Object>} - The result of the download request.
 */
const executeFunction = async ({ doc_id, rendition_type, steadyState = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path variables
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/renditions/${rendition_type}`;
    
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Add steadyState query parameter if needed
    const queryParams = new URLSearchParams();
    if (steadyState) {
      queryParams.append('steadyState', 'true');
    }

    // Perform the fetch request
    const response = await fetch(`${url}?${queryParams.toString()}`, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading document rendition file:', error);
    return {
      error: `An error occurred while downloading the document rendition file: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading document rendition files from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_document_rendition',
      description: 'Download a document rendition file from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          rendition_type: {
            type: 'string',
            description: 'The type of rendition to download.'
          },
          steadyState: {
            type: 'boolean',
            description: 'Set to true to download from the latest steady state version of the document.'
          }
        },
        required: ['doc_id', 'rendition_type']
      }
    }
  }
};

export { apiTool };