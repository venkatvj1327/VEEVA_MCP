/**
 * Function to remove users and groups from roles on object records in Veeva Vault.
 *
 * @param {Object} args - Arguments for the removal.
 * @param {string} args.object_name - The name of the object where you want to remove roles.
 * @param {Buffer} args.csvData - The CSV data containing users and groups to be removed.
 * @returns {Promise<Object>} - The result of the removal operation.
 */
const executeFunction = async ({ object_name, csvData }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/roles`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers,
      body: csvData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response data
    return await response.json();
  } catch (error) {
    console.error('Error removing users and groups from roles:', error);
    return {
      error: `An error occurred while removing users and groups from roles: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for removing users and groups from roles on object records in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'remove_users_groups_roles',
      description: 'Remove users and groups from roles on object records in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object where you want to remove roles.'
          },
          csvData: {
            type: 'string',
            description: 'The CSV data containing users and groups to be removed.'
          }
        },
        required: ['object_name', 'csvData']
      }
    }
  }
};

export { apiTool };