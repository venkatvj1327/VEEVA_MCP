/**
 * Function to reclassify a binder in Veeva Vault.
 *
 * @param {Object} args - Arguments for the reclassification.
 * @param {string} args.binder_id - The ID of the binder to be reclassified.
 * @param {string} [args.type__v] - The new type for the binder.
 * @param {string} [args.subtype__v] - The new subtype for the binder.
 * @param {string} [args.classification__v] - The new classification for the binder.
 * @param {string} [args.lifecycle__v] - The new lifecycle for the binder.
 * @returns {Promise<Object>} - The result of the reclassification.
 */
const executeFunction = async ({ binder_id, type__v = '', subtype__v = '', classification__v = '', lifecycle__v = '' }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}`;

    // Prepare the data to be sent in the request
    const data = new URLSearchParams();
    data.append('reclassify', 'true');
    if (type__v) data.append('type__v', type__v);
    if (subtype__v) data.append('subtype__v', subtype__v);
    if (classification__v) data.append('classification__v', classification__v);
    if (lifecycle__v) data.append('lifecycle__v', lifecycle__v);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: data
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const responseData = await response.json();
    return responseData;
  } catch (error) {
    console.error('Error reclassifying binder:', error);
    return {
      error: `An error occurred while reclassifying the binder: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for reclassifying a binder in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'reclassify_binder',
      description: 'Reclassify a binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder to be reclassified.'
          },
          type__v: {
            type: 'string',
            description: 'The new type for the binder.'
          },
          subtype__v: {
            type: 'string',
            description: 'The new subtype for the binder.'
          },
          classification__v: {
            type: 'string',
            description: 'The new classification for the binder.'
          },
          lifecycle__v: {
            type: 'string',
            description: 'The new lifecycle for the binder.'
          }
        },
        required: ['binder_id']
      }
    }
  }
};

export { apiTool };