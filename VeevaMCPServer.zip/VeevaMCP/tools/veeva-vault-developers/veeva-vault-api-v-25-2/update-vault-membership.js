/**
 * Function to update vault membership for a user in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.user_id - The user ID to update.
 * @param {string} args.vault_id - The vault ID to update the membership for.
 * @param {boolean} [args.active__v] - The active status of the user in the vault.
 * @param {string} [args.security_profile__v] - The security profile to assign to the user.
 * @param {string} [args.license_type__v] - The license type to assign to the user.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ user_id, vault_id, active__v, security_profile__v, license_type__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path variables
    const url = `https://${vaultDNS}/api/${version}/objects/users/${user_id}/vault_membership/${vault_id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body data
    const bodyData = new URLSearchParams();
    if (active__v !== undefined) bodyData.append('active__v', active__v);
    if (security_profile__v) bodyData.append('security_profile__v', security_profile__v);
    if (license_type__v) bodyData.append('license_type__v', license_type__v);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: bodyData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating vault membership:', error);
    return {
      error: `An error occurred while updating vault membership: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating vault membership in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_vault_membership',
      description: 'Update vault membership for a user in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          user_id: {
            type: 'string',
            description: 'The user ID to update.'
          },
          vault_id: {
            type: 'string',
            description: 'The vault ID to update the membership for.'
          },
          active__v: {
            type: 'boolean',
            description: 'The active status of the user in the vault.'
          },
          security_profile__v: {
            type: 'string',
            description: 'The security profile to assign to the user.'
          },
          license_type__v: {
            type: 'string',
            description: 'The license type to assign to the user.'
          }
        },
        required: ['user_id', 'vault_id']
      }
    }
  }
};

export { apiTool };