/**
 * Function to update an attachment field by uploading a file to Veeva Vault.
 *
 * @param {Object} args - Arguments for the file upload.
 * @param {string} args.object_name - The object name field value (e.g., product__v).
 * @param {string} args.object_record_id - The object record ID field value.
 * @param {string} args.attachment_field_name - The name of the Attachment field to update.
 * @param {string} args.filePath - The path to the file to be uploaded.
 * @returns {Promise<Object>} - The result of the file upload operation.
 */
const executeFunction = async ({ object_name, object_record_id, attachment_field_name, filePath }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/attachment_fields/${attachment_field_name}/file`;

    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId,
    };

    const formData = new FormData();
    formData.append('file', fs.createReadStream(filePath));

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData,
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating attachment field:', error);
    return {
      error: `An error occurred while updating the attachment field: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating an attachment field in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_attachment_field',
      description: 'Update an attachment field by uploading a file to Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name field value (e.g., product__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The object record ID field value.'
          },
          attachment_field_name: {
            type: 'string',
            description: 'The name of the Attachment field to update.'
          },
          filePath: {
            type: 'string',
            description: 'The path to the file to be uploaded.'
          }
        },
        required: ['object_name', 'object_record_id', 'attachment_field_name', 'filePath']
      }
    }
  }
};

export { apiTool };