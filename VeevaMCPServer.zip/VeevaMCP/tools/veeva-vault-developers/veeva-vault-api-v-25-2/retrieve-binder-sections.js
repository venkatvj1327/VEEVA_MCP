/**
 * Function to retrieve binder sections from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.binder_id - The ID of the binder.
 * @param {string} [args.section_id] - Optional: The ID of the section to retrieve subsections from.
 * @returns {Promise<Object>} - The result of the binder sections retrieval.
 */
const executeFunction = async ({ binder_id, section_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path variables
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/sections/${section_id || ''}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving binder sections:', error);
    return {
      error: `An error occurred while retrieving binder sections: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving binder sections from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_binder_sections',
      description: 'Retrieve all sections in a binder’s top-level root node or sub-level node.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder.'
          },
          section_id: {
            type: 'string',
            description: 'Optional: The ID of the section to retrieve subsections from.'
          }
        },
        required: ['binder_id']
      }
    }
  }
};

export { apiTool };