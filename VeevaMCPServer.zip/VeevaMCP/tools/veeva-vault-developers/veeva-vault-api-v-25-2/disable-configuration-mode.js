/**
 * Function to disable Configuration Mode in the currently authenticated Veeva Vault.
 *
 * @param {Object} args - Arguments for disabling Configuration Mode.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The Client ID to identify the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @returns {Promise<Object>} - The result of the disable Configuration Mode request.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version }) => {
  const url = `https://${vaultDNS}/api/${version}/services/configuration_mode/actions/disable`;
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error disabling Configuration Mode:', error);
    return {
      error: `An error occurred while disabling Configuration Mode: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for disabling Configuration Mode in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'disable_configuration_mode',
      description: 'Disable Configuration Mode in the currently authenticated Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The Client ID to identify the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };