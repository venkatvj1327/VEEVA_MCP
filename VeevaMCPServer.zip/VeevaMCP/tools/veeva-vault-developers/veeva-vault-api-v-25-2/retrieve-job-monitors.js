/**
 * Function to retrieve job monitors from Veeva Vault.
 *
 * @param {Object} args - Arguments for retrieving job monitors.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} [args.start_date] - The start date for retrieving uncompleted jobs in the format YYYY-MM-DDTHH:MM:SSZ.
 * @param {string} [args.end_date] - The end date for retrieving uncompleted jobs in the format YYYY-MM-DDTHH:MM:SSZ.
 * @param {string} [args.status] - Filter to retrieve jobs in a certain status (scheduled, queued, running).
 * @param {number} [args.limit] - The maximum number of jobs per page (1 to 200).
 * @param {number} [args.offset] - The offset from the first job instance returned.
 * @returns {Promise<Object>} - The result of the job monitors retrieval.
 */
const executeFunction = async ({ sessionId, clientId, start_date, end_date, status, limit, offset }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  try {
    // Construct the URL with query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/services/jobs/monitors`);
    if (start_date) url.searchParams.append('start_date', start_date);
    if (end_date) url.searchParams.append('end_date', end_date);
    if (status) url.searchParams.append('status', status);
    if (limit) url.searchParams.append('limit', limit.toString());
    if (offset) url.searchParams.append('offset', offset.toString());

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving job monitors:', error);
    return {
      error: `An error occurred while retrieving job monitors: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving job monitors from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_job_monitors',
      description: 'Retrieve monitors for jobs which have not yet completed in the authenticated Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          start_date: {
            type: 'string',
            description: 'The start date for retrieving uncompleted jobs in the format YYYY-MM-DDTHH:MM:SSZ.'
          },
          end_date: {
            type: 'string',
            description: 'The end date for retrieving uncompleted jobs in the format YYYY-MM-DDTHH:MM:SSZ.'
          },
          status: {
            type: 'string',
            description: 'Filter to retrieve jobs in a certain status (scheduled, queued, running).'
          },
          limit: {
            type: 'integer',
            description: 'The maximum number of jobs per page (1 to 200).'
          },
          offset: {
            type: 'integer',
            description: 'The offset from the first job instance returned.'
          }
        },
        required: ['sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };