/**
 * Function to retrieve user actions on multiple binders from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.docIds - The id and version numbers of each binder for which to retrieve the available user actions.
 * @returns {Promise<Object>} - The result of the user actions retrieval.
 */
const executeFunction = async ({ docIds }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/binders/lifecycle_actions`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body data
    const body = new URLSearchParams();
    body.append('docIds', docIds);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving user actions:', error);
    return {
      error: `An error occurred while retrieving user actions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving user actions on multiple binders from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_user_actions',
      description: 'Retrieve user actions on multiple binders from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          docIds: {
            type: 'string',
            description: 'The id and version numbers of each binder for which to retrieve the available user actions.'
          }
        },
        required: ['docIds']
      }
    }
  }
};

export { apiTool };