/**
 * Function to retrieve document template attributes from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.template_name - The document template name__v field value.
 * @returns {Promise<Object>} - The attributes of the document template.
 */
const executeFunction = async ({ template_name }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL
    const url = `https://${vaultDNS}/api/${version}/objects/documents/templates/${template_name}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving document template attributes:', error);
    return {
      error: `An error occurred while retrieving document template attributes: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document template attributes from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_template_attributes',
      description: 'Retrieve the attributes from a document template in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          template_name: {
            type: 'string',
            description: 'The document template name__v field value.'
          }
        },
        required: ['template_name']
      }
    }
  }
};

export { apiTool };