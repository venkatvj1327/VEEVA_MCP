/**
 * Function to create multiple document relationships in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating document relationships.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {Buffer} args.csvData - The CSV data for the document relationships.
 * @returns {Promise<Object>} - The result of the document relationships creation.
 */
const executeFunction = async ({ sessionId, clientId, csvData }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/objects/documents/relationships/batch`;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: csvData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating document relationships:', error);
    return {
      error: `An error occurred while creating document relationships: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating multiple document relationships in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_multiple_document_relationships',
      description: 'Create multiple document relationships in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          csvData: {
            type: 'string',
            description: 'The CSV data for the document relationships.'
          }
        },
        required: ['sessionId', 'clientId', 'csvData']
      }
    }
  }
};

export { apiTool };