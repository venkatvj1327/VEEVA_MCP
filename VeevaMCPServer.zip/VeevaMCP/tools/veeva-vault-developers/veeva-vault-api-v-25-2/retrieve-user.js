/**
 * Function to retrieve user information from Veeva Vault.
 *
 * @param {Object} args - Arguments for the user retrieval.
 * @param {string} args.id - The user ID to retrieve information for. Use 'me' to get information for the currently authenticated user.
 * @param {boolean} [args.exclude_vault_membership=false] - Optional: Set to true to omit vault_membership fields.
 * @param {boolean} [args.exclude_app_licensing=false] - Optional: Set to true to omit app_licensing fields.
 * @returns {Promise<Object>} - The user information retrieved from Veeva Vault.
 */
const executeFunction = async ({ id, exclude_vault_membership = false, exclude_app_licensing = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with the user ID
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/users/${id}`);

    // Set up query parameters if applicable
    const params = new URLSearchParams();
    if (exclude_vault_membership) {
      params.append('exclude_vault_membership', 'true');
    }
    if (exclude_app_licensing) {
      params.append('exclude_app_licensing', 'true');
    }
    if (params.toString()) {
      url.search = params.toString();
    }

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId,
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers,
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving user information:', error);
    return {
      error: `An error occurred while retrieving user information: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving user information from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_user',
      description: 'Retrieve user information from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          id: {
            type: 'string',
            description: 'The user ID to retrieve information for. Use "me" to get information for the currently authenticated user.'
          },
          exclude_vault_membership: {
            type: 'boolean',
            description: 'Optional: Set to true to omit vault_membership fields.'
          },
          exclude_app_licensing: {
            type: 'boolean',
            description: 'Optional: Set to true to omit app_licensing fields.'
          }
        },
        required: ['id']
      }
    }
  }
};

export { apiTool };