/**
 * Function to delete a single document attachment in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.doc_id - The ID of the document.
 * @param {string} args.attachment_id - The ID of the attachment to be deleted.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ doc_id, attachment_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the DELETE request
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/attachments/${attachment_id}`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return a success message or response
    return { message: 'Attachment deleted successfully.' };
  } catch (error) {
    console.error('Error deleting attachment:', error);
    return {
      error: `An error occurred while deleting the attachment: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting a document attachment in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_document_attachment',
      description: 'Delete a single document attachment in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The ID of the document.'
          },
          attachment_id: {
            type: 'string',
            description: 'The ID of the attachment to be deleted.'
          }
        },
        required: ['doc_id', 'attachment_id']
      }
    }
  }
};

export { apiTool };