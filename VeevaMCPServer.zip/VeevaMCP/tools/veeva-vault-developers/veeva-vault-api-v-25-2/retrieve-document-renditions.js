/**
 * Function to retrieve document renditions from Veeva Vault.
 *
 * @param {Object} args - Arguments for the document rendition retrieval.
 * @param {string} args.doc_id - The ID of the document to retrieve renditions for.
 * @returns {Promise<Object>} - The result of the document rendition retrieval.
 */
const executeFunction = async ({ doc_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/renditions`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving document renditions:', error);
    return {
      error: `An error occurred while retrieving document renditions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document renditions from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_renditions',
      description: 'Retrieve document renditions from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The ID of the document to retrieve renditions for.'
          }
        },
        required: ['doc_id']
      }
    }
  }
};

export { apiTool };