/**
 * Function to initiate a document user action in Veeva Vault.
 *
 * @param {Object} args - Arguments for the user action initiation.
 * @param {string} args.id - The document id field value from which to retrieve available user actions.
 * @param {string} args.major_version - The major version number of the document.
 * @param {string} args.minor_version - The minor version number of the document.
 * @param {string} args.name__v - The action name__v field value to initiate.
 * @returns {Promise<Object>} - The result of the user action initiation.
 */
const executeFunction = async ({ id, major_version, minor_version, name__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${id}/versions/${major_version}/${minor_version}/lifecycle_actions/${name__v}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error initiating user action:', error);
    return {
      error: `An error occurred while initiating the user action: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for initiating a document user action in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'initiate_document_user_action',
      description: 'Initiate a user action for a document in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          id: {
            type: 'string',
            description: 'The document id field value from which to retrieve available user actions.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the document.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the document.'
          },
          name__v: {
            type: 'string',
            description: 'The action name__v field value to initiate.'
          }
        },
        required: ['id', 'major_version', 'minor_version', 'name__v']
      }
    }
  }
};

export { apiTool };