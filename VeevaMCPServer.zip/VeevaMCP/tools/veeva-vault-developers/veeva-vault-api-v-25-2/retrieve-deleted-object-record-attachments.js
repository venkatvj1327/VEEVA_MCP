/**
 * Function to retrieve deleted object record attachments from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.object_name - The object name field value (e.g., product__v, country__v).
 * @param {string} args.object_record_id - The object record ID field value.
 * @param {string} args.attachment_id - The attachment ID field value.
 * @param {string} args.attachment_version - The attachment version field value.
 * @returns {Promise<Object>} - The result of the retrieval of deleted object record attachments.
 */
const executeFunction = async ({ object_name, object_record_id, attachment_id, attachment_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/attachments/${attachment_id}/versions/${attachment_version}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving deleted object record attachments:', error);
    return {
      error: `An error occurred while retrieving deleted object record attachments: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving deleted object record attachments from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_deleted_object_record_attachments',
      description: 'Retrieve deleted object record attachments from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name field value (e.g., product__v, country__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The object record ID field value.'
          },
          attachment_id: {
            type: 'string',
            description: 'The attachment ID field value.'
          },
          attachment_version: {
            type: 'string',
            description: 'The attachment version field value.'
          }
        },
        required: ['object_name', 'object_record_id', 'attachment_id', 'attachment_version']
      }
    }
  }
};

export { apiTool };