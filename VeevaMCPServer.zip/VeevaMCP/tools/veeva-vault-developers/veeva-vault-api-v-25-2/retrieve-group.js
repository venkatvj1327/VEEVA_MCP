/**
 * Function to retrieve a group from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.group_id - The ID of the group to retrieve.
 * @param {boolean} [args.includeImplied=true] - When true, includes implied members in the response.
 * @returns {Promise<Object>} - The result of the group retrieval.
 */
const executeFunction = async ({ group_id, includeImplied = true }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with the group ID and query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/groups/${group_id}`);
    if (includeImplied) {
      url.searchParams.append('includeImplied', 'true');
    }

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving group:', error);
    return {
      error: `An error occurred while retrieving the group: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving a group from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_group',
      description: 'Retrieve a group from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          group_id: {
            type: 'string',
            description: 'The ID of the group to retrieve.'
          },
          includeImplied: {
            type: 'boolean',
            description: 'When true, includes implied members in the response.'
          }
        },
        required: ['group_id']
      }
    }
  }
};

export { apiTool };