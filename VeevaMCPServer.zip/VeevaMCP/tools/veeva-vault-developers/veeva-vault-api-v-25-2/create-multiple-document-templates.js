/**
 * Function to create multiple document templates in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating document templates.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.csvData - The CSV data for the document templates.
 * @returns {Promise<Object>} - The result of the document template creation.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, csvData }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/templates`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'text/csv',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId,
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: csvData,
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating document templates:', error);
    return {
      error: `An error occurred while creating document templates: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating multiple document templates in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_multiple_document_templates',
      description: 'Create multiple document templates in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          csvData: {
            type: 'string',
            description: 'The CSV data for the document templates.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version', 'csvData']
      }
    }
  }
};

export { apiTool };