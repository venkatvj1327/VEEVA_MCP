/**
 * Function to delete a specific version of a document attachment in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.doc_id - The ID of the document.
 * @param {string} args.attachment_id - The ID of the attachment.
 * @param {string} args.attachment_version - The version of the attachment to delete.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ doc_id, attachment_id, attachment_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the DELETE request
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/attachments/${attachment_id}/versions/${attachment_version}`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response data
    return await response.json();
  } catch (error) {
    console.error('Error deleting document attachment version:', error);
    return {
      error: `An error occurred while deleting the document attachment version: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting a document attachment version in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_document_attachment_version',
      description: 'Delete a specific version of a document attachment in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The ID of the document.'
          },
          attachment_id: {
            type: 'string',
            description: 'The ID of the attachment.'
          },
          attachment_version: {
            type: 'string',
            description: 'The version of the attachment to delete.'
          }
        },
        required: ['doc_id', 'attachment_id', 'attachment_version']
      }
    }
  }
};

export { apiTool };