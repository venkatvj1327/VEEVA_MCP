/**
 * Function to download a document file from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.doc_id - The ID of the document to download.
 * @param {boolean} [args.lockDocument=false] - Set to true to check out the document before retrieval.
 * @returns {Promise<Object>} - The result of the document download.
 */
const executeFunction = async ({ doc_id, lockDocument = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the document download
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/file`);
    if (lockDocument) {
      url.searchParams.append('lockDocument', 'true');
    }

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading document file:', error);
    return {
      error: `An error occurred while downloading the document file: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading a document file from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_document_file',
      description: 'Download a document file from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The ID of the document to download.'
          },
          lockDocument: {
            type: 'boolean',
            description: 'Set to true to check out the document before retrieval.'
          }
        },
        required: ['doc_id']
      }
    }
  }
};

export { apiTool };