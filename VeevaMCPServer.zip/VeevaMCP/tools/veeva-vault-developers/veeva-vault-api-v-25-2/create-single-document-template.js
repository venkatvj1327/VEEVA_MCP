/**
 * Function to create a single document template in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating the document template.
 * @param {File} args.file - The file to be uploaded as the document template.
 * @param {string} args.label__v - The label of the new document template.
 * @param {string} args.type__v - The name of the document type to which the template will be associated.
 * @param {string} args.subtype__v - The name of the document subtype to which the template will be associated.
 * @param {string} args.classification__v - The name of the document classification to which the template will be associated.
 * @param {boolean} [args.active__v=true] - Indicates whether the new document template should be set to active.
 * @returns {Promise<Object>} - The result of the document template creation.
 */
const executeFunction = async ({ file, label__v, type__v, subtype__v, classification__v, active__v = true }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/objects/documents/templates`;

  // Create a FormData object to hold the file and other parameters
  const formData = new FormData();
  formData.append('file', file);
  formData.append('label__v', label__v);
  formData.append('type__v', type__v);
  if (subtype__v) formData.append('subtype__v', subtype__v);
  if (classification__v) formData.append('classification__v', classification__v);
  formData.append('active__v', active__v.toString());

  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating document template:', error);
    return {
      error: `An error occurred while creating the document template: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a document template in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_document_template',
      description: 'Create a single document template in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          file: {
            type: 'object',
            description: 'The file to be uploaded as the document template.'
          },
          label__v: {
            type: 'string',
            description: 'The label of the new document template.'
          },
          type__v: {
            type: 'string',
            description: 'The name of the document type to which the template will be associated.'
          },
          subtype__v: {
            type: 'string',
            description: 'The name of the document subtype to which the template will be associated.'
          },
          classification__v: {
            type: 'string',
            description: 'The name of the document classification to which the template will be associated.'
          },
          active__v: {
            type: 'boolean',
            description: 'Indicates whether the new document template should be set to active.'
          }
        },
        required: ['file', 'label__v', 'type__v']
      }
    }
  }
};

export { apiTool };