/**
 * Function to retrieve object metadata from Veeva Vault.
 *
 * @param {Object} args - Arguments for the metadata retrieval.
 * @param {string} args.object_name - The name of the object to retrieve metadata for.
 * @param {boolean} [args.loc=false] - To retrieve localized (translated) strings.
 * @returns {Promise<Object>} - The metadata of the specified object.
 */
const executeFunction = async ({ object_name, loc = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with the object name
    const url = `https://${vaultDNS}/api/${version}/metadata/vobjects/${object_name}?loc=${loc}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving object metadata:', error);
    return {
      error: `An error occurred while retrieving object metadata: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving object metadata from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_object_metadata',
      description: 'Retrieve metadata for a specified object from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object to retrieve metadata for.'
          },
          loc: {
            type: 'boolean',
            description: 'To retrieve localized (translated) strings.'
          }
        },
        required: ['object_name']
      }
    }
  }
};

export { apiTool };