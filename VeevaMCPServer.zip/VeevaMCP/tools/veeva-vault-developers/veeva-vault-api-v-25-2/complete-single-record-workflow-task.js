/**
 * Function to complete a single record workflow task in Veeva Vault.
 *
 * @param {Object} args - Arguments for completing the workflow task.
 * @param {string} args.task_id - The ID of the workflow task to complete.
 * @param {string} [args.verdict_public_key__c] - The verdict name.
 * @param {string} [args.reason__c] - The reason name.
 * @param {string} [args.capacity__c] - The capacity name.
 * @returns {Promise<Object>} - The result of the workflow task completion.
 */
const executeFunction = async ({ task_id, verdict_public_key__c, reason__c, capacity__c }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/objectworkflows/tasks/${task_id}/actions/complete`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body parameters
    const bodyParams = new URLSearchParams();
    if (verdict_public_key__c) bodyParams.append('verdict_public_key__c', verdict_public_key__c);
    if (reason__c) bodyParams.append('reason__c', reason__c);
    if (capacity__c) bodyParams.append('capacity__c', capacity__c);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: bodyParams
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error completing workflow task:', error);
    return {
      error: `An error occurred while completing the workflow task: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for completing a single record workflow task in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'complete_single_record_workflow_task',
      description: 'Complete a single record workflow task in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          task_id: {
            type: 'string',
            description: 'The ID of the workflow task to complete.'
          },
          verdict_public_key__c: {
            type: 'string',
            description: 'The verdict name.'
          },
          reason__c: {
            type: 'string',
            description: 'The reason name.'
          },
          capacity__c: {
            type: 'string',
            description: 'The capacity name.'
          }
        },
        required: ['task_id']
      }
    }
  }
};

export { apiTool };