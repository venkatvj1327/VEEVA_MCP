/**
 * Function to create a group in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating a group.
 * @param {string} args.label__v - [Required] Enter a group label. Vault uses this to create the group name__v value.
 * @param {string} [args.members__v] - Optional: Add a comma-separated list of user IDs. This manually assigns individual users to the group.
 * @param {string} [args.security_profile__v] - Optional: Add a comma-separated list of security profiles. This automatically adds all users with the security profile to the group. These are implied_members__v.
 * @param {boolean} [args.active__v=true] - Optional: By default, the new group will be created as active. To set the group to inactive, set this value to false.
 * @param {string} [args.group_description__v] - Optional: Add a description of the group.
 * @param {boolean} [args.allow_delegation_among_members__v=false] - Optional: When set to true, members of this group will only be allowed to delegate access to other members of the same group.
 * @returns {Promise<Object>} - The result of the group creation.
 */
const executeFunction = async ({ label__v, members__v, security_profile__v, active__v = true, group_description__v, allow_delegation_among_members__v = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  
  const url = `https://${vaultDNS}/api/${version}/objects/groups`;

  // Prepare the form data
  const formData = new URLSearchParams();
  formData.append('label__v', label__v);
  if (members__v) formData.append('members__v', members__v);
  if (security_profile__v) formData.append('security_profile__v', security_profile__v);
  formData.append('active__v', active__v);
  if (group_description__v) formData.append('group_description__v', group_description__v);
  formData.append('allow_delegation_among_members__v', allow_delegation_among_members__v);

  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating group:', error);
    return {
      error: `An error occurred while creating the group: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a group in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_group',
      description: 'Create a group in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          label__v: {
            type: 'string',
            description: '[Required] Enter a group label. Vault uses this to create the group name__v value.'
          },
          members__v: {
            type: 'string',
            description: 'Optional: Add a comma-separated list of user IDs. This manually assigns individual users to the group.'
          },
          security_profile__v: {
            type: 'string',
            description: 'Optional: Add a comma-separated list of security profiles. This automatically adds all users with the security profile to the group.'
          },
          active__v: {
            type: 'boolean',
            description: 'Optional: By default, the new group will be created as active. To set the group to inactive, set this value to false.'
          },
          group_description__v: {
            type: 'string',
            description: 'Optional: Add a description of the group.'
          },
          allow_delegation_among_members__v: {
            type: 'boolean',
            description: 'Optional: When set to true, members of this group will only be allowed to delegate access to other members of the same group.'
          }
        },
        required: ['label__v']
      }
    }
  }
};

export { apiTool };