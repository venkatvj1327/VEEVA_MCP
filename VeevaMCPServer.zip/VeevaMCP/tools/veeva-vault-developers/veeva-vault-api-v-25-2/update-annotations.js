/**
 * Function to update annotations in Veeva Vault.
 *
 * @param {Object} args - Arguments for updating annotations.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault instance.
 * @param {string} args.version - The API version to use.
 * @param {Array<Object>} args.annotations - The list of annotation objects to update.
 * @returns {Promise<Object>} - The result of the update annotations request.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, annotations }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/annotations/batch`;
  const token = process.env.VEEVA_VAULT_DEVELOPERS_API_KEY;
  const clientID = clientId || ''; // will be provided by the user

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientID
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: JSON.stringify(annotations)
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating annotations:', error);
    return {
      error: `An error occurred while updating annotations: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating annotations in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_annotations',
      description: 'Update multiple annotations in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault instance.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          annotations: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                id__sys: { type: 'string', description: 'The ID of the annotation.' },
                document_version_id__sys: { type: 'string', description: 'The document version ID.' },
                comment__sys: { type: 'string', description: 'The comment to update.' },
                color__sys: { type: 'string', description: 'The color to update.' }
              },
              required: ['id__sys', 'document_version_id__sys']
            },
            description: 'The list of annotation objects to update.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version', 'annotations']
      }
    }
  }
};

export { apiTool };