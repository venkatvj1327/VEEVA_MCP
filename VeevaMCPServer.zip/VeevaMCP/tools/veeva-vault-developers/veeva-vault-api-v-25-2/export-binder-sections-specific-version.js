/**
 * Function to export specific sections from a binder in Veeva Vault.
 *
 * @param {Object} args - Arguments for the export.
 * @param {string} args.binder_id - The ID of the binder to export sections from.
 * @param {string} args.major_version - The major version number of the binder.
 * @param {string} args.minor_version - The minor version number of the binder.
 * @param {string} [args.depth="all"] - The depth of the export.
 * @returns {Promise<Object>} - The result of the export operation.
 */
const executeFunction = async ({ binder_id, major_version, minor_version, depth = 'all' }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL with path parameters
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/versions/${major_version}/${minor_version}/actions/export`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify({ depth }) // Include depth in the request body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error exporting binder sections:', error);
    return {
      error: `An error occurred while exporting binder sections: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for exporting binder sections in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'export_binder_sections',
      description: 'Export specific sections from a binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder to export sections from.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the binder.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the binder.'
          },
          depth: {
            type: 'string',
            description: 'The depth of the export.'
          }
        },
        required: ['binder_id', 'major_version', 'minor_version']
      }
    }
  }
};

export { apiTool };