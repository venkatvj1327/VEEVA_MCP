/**
 * Function to authenticate using OAuth 2.0 / OpenID Connect and obtain a Vault Session ID.
 *
 * @param {Object} args - Arguments for the authentication.
 * @param {string} args.oath_oidc_profile_id - The OIDC profile ID for the authentication request.
 * @param {string} [args.vaultDNS] - Optional: The DNS of the vault for which you want to generate a session.
 * @param {string} [args.client_id] - Optional: The ID of the client application at the Authorization server.
 * @param {string} [args.access_token] - The access token for authorization.
 * @param {string} [args.clientId] - The client ID to identify the request.
 * @returns {Promise<Object>} - The result of the authentication request.
 */
const executeFunction = async ({ oath_oidc_profile_id, vaultDNS, client_id, access_token, clientId }) => {
  const url = `https://login.veevavault.com/auth/oauth/session/${oath_oidc_profile_id}`;
  const headers = {
    'Authorization': `Bearer ${access_token}`, // Bearer token for authorization
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId // Client ID for identifying the request
  };

  const body = new URLSearchParams();
  if (vaultDNS) body.append('vaultDNS', vaultDNS);
  if (client_id) body.append('client_id', client_id);

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error during authentication:', error);
    return {
      error: `An error occurred during authentication: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for authenticating using OAuth 2.0 / OpenID Connect.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'oauth2_oidc_auth',
      description: 'Authenticate using OAuth 2.0 / OpenID Connect to obtain a Vault Session ID.',
      parameters: {
        type: 'object',
        properties: {
          oath_oidc_profile_id: {
            type: 'string',
            description: 'The OIDC profile ID for the authentication request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'Optional: The DNS of the vault for which you want to generate a session.'
          },
          client_id: {
            type: 'string',
            description: 'Optional: The ID of the client application at the Authorization server.'
          },
          access_token: {
            type: 'string',
            description: 'The access token for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID to identify the request.'
          }
        },
        required: ['oath_oidc_profile_id', 'access_token', 'clientId']
      }
    }
  }
};

export { apiTool };