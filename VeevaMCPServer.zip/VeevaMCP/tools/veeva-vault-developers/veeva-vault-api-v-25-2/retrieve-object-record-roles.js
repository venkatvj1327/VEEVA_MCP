/**
 * Function to retrieve object record roles from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.object_name - The name of the object.
 * @param {string} args.id - The ID of the document, binder, or object record.
 * @param {string} [args.role_name] - Optional role name to filter for a specific role.
 * @returns {Promise<Object>} - The result of the object record roles retrieval.
 */
const executeFunction = async ({ object_name, id, role_name }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path parameters
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${id}/roles/${role_name || ''}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving object record roles:', error);
    return {
      error: `An error occurred while retrieving object record roles: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving object record roles from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_object_record_roles',
      description: 'Retrieve manually assigned roles on an object record.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object.'
          },
          id: {
            type: 'string',
            description: 'The ID of the document, binder, or object record.'
          },
          role_name: {
            type: 'string',
            description: 'Optional: Include a role name to filter for a specific role.'
          }
        },
        required: ['object_name', 'id']
      }
    }
  }
};

export { apiTool };