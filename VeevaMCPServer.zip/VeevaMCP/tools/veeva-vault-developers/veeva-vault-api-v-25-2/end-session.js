/**
 * Function to end a session in Veeva Vault API.
 *
 * @param {Object} args - Arguments for ending the session.
 * @param {string} args.sessionId - The Vault sessionId to end.
 * @param {string} args.clientId - The Client ID to identify this request.
 * @returns {Promise<Object>} - The result of the session ending operation.
 */
const executeFunction = async ({ sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/session`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response data
    return {};
  } catch (error) {
    console.error('Error ending session:', error);
    return {
      error: `An error occurred while ending the session: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for ending a session in Veeva Vault API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'end_session',
      description: 'End a session in Veeva Vault API.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The Vault sessionId to end.'
          },
          clientId: {
            type: 'string',
            description: 'The Client ID to identify this request.'
          }
        },
        required: ['sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };