/**
 * Function to create a new binder template in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating the binder template.
 * @param {string} args.label__v - The label of the new binder template.
 * @param {string} [args.name__v] - The name of the new binder template. If not included, Vault will generate a value based on label__v.
 * @param {string} args.type__v - The name of the document type to which the template will be associated.
 * @param {string} [args.subtype__v] - The name of the document subtype to which the template will be associated.
 * @param {string} [args.classification__v] - The name of the document classification to which the template will be associated.
 * @param {boolean} args.active__v - Indicates whether the new binder template should be set to active.
 * @returns {Promise<Object>} - The result of the binder template creation.
 */
const executeFunction = async ({ label__v, name__v = '', type__v, subtype__v = '', classification__v = '', active__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/objects/binders/templates`;

  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId
  };

  const body = new URLSearchParams({
    'label__v': label__v,
    'name__v': name__v,
    'type__v': type__v,
    'subtype__v': subtype__v,
    'classification__v': classification__v,
    'active__v': active__v
  }).toString();

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating binder template:', error);
    return {
      error: `An error occurred while creating the binder template: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a binder template in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_binder_template',
      description: 'Create a new binder template in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          label__v: {
            type: 'string',
            description: 'The label of the new binder template.'
          },
          name__v: {
            type: 'string',
            description: 'The name of the new binder template.'
          },
          type__v: {
            type: 'string',
            description: 'The name of the document type to which the template will be associated.'
          },
          subtype__v: {
            type: 'string',
            description: 'The name of the document subtype to which the template will be associated.'
          },
          classification__v: {
            type: 'string',
            description: 'The name of the document classification to which the template will be associated.'
          },
          active__v: {
            type: 'boolean',
            description: 'Indicates whether the new binder template should be set to active.'
          }
        },
        required: ['label__v', 'type__v', 'active__v']
      }
    }
  }
};

export { apiTool };