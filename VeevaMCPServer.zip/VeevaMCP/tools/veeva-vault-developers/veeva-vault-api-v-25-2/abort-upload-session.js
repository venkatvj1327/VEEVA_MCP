/**
 * Function to abort an active upload session in Veeva Vault.
 *
 * @param {Object} args - Arguments for the abort upload session.
 * @param {string} args.upload_session_id - The ID of the upload session to abort.
 * @returns {Promise<Object>} - The result of the abort upload session request.
 */
const executeFunction = async ({ upload_session_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/services/file_staging/upload/${upload_session_id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response data
    return await response.json();
  } catch (error) {
    console.error('Error aborting upload session:', error);
    return {
      error: `An error occurred while aborting the upload session: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for aborting an upload session in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'abort_upload_session',
      description: 'Abort an active upload session in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          upload_session_id: {
            type: 'string',
            description: 'The ID of the upload session to abort.'
          }
        },
        required: ['upload_session_id']
      }
    }
  }
};

export { apiTool };