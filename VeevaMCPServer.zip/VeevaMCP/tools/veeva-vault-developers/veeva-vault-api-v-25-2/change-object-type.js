/**
 * Function to change the object type in Veeva Vault.
 *
 * @param {Object} args - Arguments for changing the object type.
 * @param {string} args.object_name - The name of the object to change.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.csvData - The CSV data to set field values on the new object type.
 * @returns {Promise<Object>} - The result of the change object type request.
 */
const executeFunction = async ({ object_name, sessionId, clientId, csvData }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/actions/changetype`;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'text/csv',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId,
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: csvData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error changing object type:', error);
    return {
      error: `An error occurred while changing object type: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for changing object type in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'change_object_type',
      description: 'Change the object type in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object to change.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          csvData: {
            type: 'string',
            description: 'The CSV data to set field values on the new object type.'
          }
        },
        required: ['object_name', 'sessionId', 'clientId', 'csvData']
      }
    }
  }
};

export { apiTool };