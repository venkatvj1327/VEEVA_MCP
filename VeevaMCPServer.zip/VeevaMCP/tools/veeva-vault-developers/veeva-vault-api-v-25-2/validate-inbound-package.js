/**
 * Function to validate an inbound package in Veeva Vault.
 *
 * @param {Object} args - Arguments for the validation.
 * @param {string} args.package_id - The id field value of the vault_package__v object record to validate.
 * @returns {Promise<Object>} - The result of the validation request.
 */
const executeFunction = async ({ package_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL
    const url = `https://${vaultDNS}/api/${version}/services/package/actions/validate`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body data
    const body = new URLSearchParams();
    body.append('package_id', package_id);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error validating inbound package:', error);
    return {
      error: `An error occurred while validating the inbound package: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for validating an inbound package in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'validate_inbound_package',
      description: 'Validate an imported VPK package before deploying it to your Vault.',
      parameters: {
        type: 'object',
        properties: {
          package_id: {
            type: 'string',
            description: 'The id field value of the vault_package__v object record to validate.'
          }
        },
        required: ['package_id']
      }
    }
  }
};

export { apiTool };