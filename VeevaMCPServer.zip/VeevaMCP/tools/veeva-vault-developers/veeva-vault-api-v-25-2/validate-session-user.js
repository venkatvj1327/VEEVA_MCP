/**
 * Function to validate the session user in Veeva Vault.
 *
 * @param {Object} args - Arguments for the session validation.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {boolean} [args.exclude_vault_membership=false] - Optional: Set to true to omit vault_membership fields.
 * @param {boolean} [args.exclude_app_licensing=false] - Optional: Set to true to omit app_licensing fields.
 * @returns {Promise<Object>} - The result of the session validation.
 */
const executeFunction = async ({ sessionId, clientId, exclude_vault_membership = false, exclude_app_licensing = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  try {
    // Construct the URL
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/users/me`);
    
    // Set up query parameters
    if (exclude_vault_membership) {
      url.searchParams.append('exclude_vault_membership', 'true');
    }
    if (exclude_app_licensing) {
      url.searchParams.append('exclude_app_licensing', 'true');
    }

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error validating session user:', error);
    return {
      error: `An error occurred while validating the session user: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for validating session user in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'validate_session_user',
      description: 'Validate the session user in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          exclude_vault_membership: {
            type: 'boolean',
            description: 'Optional: Set to true to omit vault_membership fields.'
          },
          exclude_app_licensing: {
            type: 'boolean',
            description: 'Optional: Set to true to omit app_licensing fields.'
          }
        },
        required: ['sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };