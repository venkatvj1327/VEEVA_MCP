/**
 * Function to retrieve deleted object record IDs from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.object_name - The object name__v field value (e.g., product__v, country__v, custom_object__c).
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID to identify the request.
 * @returns {Promise<Object>} - The result of the retrieval of deleted object record IDs.
 */
const executeFunction = async ({ object_name, sessionId, clientId }) => {
  const baseUrl = `https://${process.env.vaultDNS}/api/${process.env.version}/objects/deletions/vobjects/${object_name}`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving deleted object record IDs:', error);
    return {
      error: `An error occurred while retrieving deleted object record IDs: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving deleted object record IDs from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_deleted_object_record_ids',
      description: 'Retrieve deleted object record IDs from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name__v field value (e.g., product__v, country__v, custom_object__c).'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID to identify the request.'
          }
        },
        required: ['object_name', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };