/**
 * Function to initiate a record merge operation in Veeva Vault.
 *
 * @param {Object} args - Arguments for the record merge.
 * @param {string} args.object_name - The object name__v field value (e.g., account__v).
 * @param {Array<Object>} args.mergeSets - An array of merge sets, each containing main and duplicate record IDs.
 * @returns {Promise<Object>} - The result of the record merge initiation.
 */
const executeFunction = async ({ object_name, mergeSets }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/actions/merge`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body for the request
    const body = JSON.stringify(mergeSets);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error initiating record merge:', error);
    return {
      error: `An error occurred while initiating record merge: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for initiating record merges in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'initiate_record_merge',
      description: 'Initiate a record merge operation in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name__v field value (e.g., account__v).'
          },
          mergeSets: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                main_record_id: {
                  type: 'string',
                  description: 'The ID of the main record.'
                },
                duplicate_record_id: {
                  type: 'string',
                  description: 'The ID of the duplicate record.'
                }
              },
              required: ['main_record_id', 'duplicate_record_id']
            },
            description: 'An array of merge sets, each containing main and duplicate record IDs.'
          }
        },
        required: ['object_name', 'mergeSets']
      }
    }
  }
};

export { apiTool };