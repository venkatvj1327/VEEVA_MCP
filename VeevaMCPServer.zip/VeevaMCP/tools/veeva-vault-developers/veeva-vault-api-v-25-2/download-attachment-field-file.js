/**
 * Function to download an attachment field file from a Veeva Vault object record.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.object_name - The object name__v field value (e.g., product__v).
 * @param {string} args.object_record_id - The object record id field value.
 * @param {string} args.attachment_field_name - The name of the Attachment field from which to retrieve the file.
 * @returns {Promise<Object>} - The result of the download request.
 */
const executeFunction = async ({ object_name, object_record_id, attachment_field_name }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // assuming version is constant as per the collection
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path parameters
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/:${object_record_id}/attachment_fields/${attachment_field_name}/file`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading attachment field file:', error);
    return {
      error: `An error occurred while downloading the attachment field file: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading an attachment field file from a Veeva Vault object record.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_attachment_field_file',
      description: 'Download an attachment field file from a Veeva Vault object record.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name__v field value (e.g., product__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The object record id field value.'
          },
          attachment_field_name: {
            type: 'string',
            description: 'The name of the Attachment field from which to retrieve the file.'
          }
        },
        required: ['object_name', 'object_record_id', 'attachment_field_name']
      }
    }
  }
};

export { apiTool };