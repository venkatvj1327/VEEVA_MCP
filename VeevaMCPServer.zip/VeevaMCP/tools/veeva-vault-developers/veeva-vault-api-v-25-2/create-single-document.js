/**
 * Function to create a single document in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating the document.
 * @param {string} args.name__v - The name of the new document.
 * @param {string} args.type__v - The label of the document type to assign to the new document.
 * @param {string} [args.lifecycle__v] - The label of the document lifecycle to assign the new document.
 * @param {string} [args.subtype__v] - The label of the document subtype (if one exists on the document type).
 * @param {string} [args.classification__v] - The label of the document classification (if one exists on the document subtype).
 * @param {string} [args.major_version_number__v] - The major version number to assign to the new document.
 * @param {string} [args.minor_version_number__v] - The minor version number to assign to the new document.
 * @param {string} [args.fromTemplate] - The name of the template to apply. Required when creating a document from a template.
 * @param {string} [args.source_vault_id__v] - The vault id field value of the vault containing the source document that will be bound to the new CrossLink document.
 * @param {string} [args.source_document_id__v] - The document id field value of the source document that will be bound to the new CrossLink document.
 * @param {string} [args.source_binding_rule__v] - Optional: Possible values are Latest version, Latest Steady State version, or Specific Document version.
 * @param {string} [args.bound_source_major_version__v] - Optional: Major version number of the source document to bind to the CrossLink document.
 * @param {string} [args.bound_source_minor_version__v] - Optional: Minor version number of the source document to bind to the CrossLink document.
 * @returns {Promise<Object>} - The result of the document creation.
 */
const executeFunction = async ({
  name__v,
  type__v,
  lifecycle__v = '',
  subtype__v = '',
  classification__v = '',
  major_version_number__v = '',
  minor_version_number__v = '',
  fromTemplate = '',
  source_vault_id__v = '',
  source_document_id__v = '',
  source_binding_rule__v = '',
  bound_source_major_version__v = '',
  bound_source_minor_version__v = ''
}) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/objects/documents`;

  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  // Prepare the body of the request
  const body = {
    name__v,
    type__v,
    lifecycle__v,
    subtype__v,
    classification__v,
    major_version_number__v,
    minor_version_number__v,
    fromTemplate,
    source_vault_id__v,
    source_document_id__v,
    source_binding_rule__v,
    bound_source_major_version__v,
    bound_source_minor_version__v
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating document:', error);
    return {
      error: `An error occurred while creating the document: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a single document in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_single_document',
      description: 'Create a single document in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          name__v: {
            type: 'string',
            description: 'The name of the new document.'
          },
          type__v: {
            type: 'string',
            description: 'The label of the document type to assign to the new document.'
          },
          lifecycle__v: {
            type: 'string',
            description: 'The label of the document lifecycle to assign the new document.'
          },
          subtype__v: {
            type: 'string',
            description: 'The label of the document subtype (if one exists on the document type).'
          },
          classification__v: {
            type: 'string',
            description: 'The label of the document classification (if one exists on the document subtype).'
          },
          major_version_number__v: {
            type: 'string',
            description: 'The major version number to assign to the new document.'
          },
          minor_version_number__v: {
            type: 'string',
            description: 'The minor version number to assign to the new document.'
          },
          fromTemplate: {
            type: 'string',
            description: 'The name of the template to apply. Required when creating a document from a template.'
          },
          source_vault_id__v: {
            type: 'string',
            description: 'The vault id field value of the vault containing the source document that will be bound to the new CrossLink document.'
          },
          source_document_id__v: {
            type: 'string',
            description: 'The document id field value of the source document that will be bound to the new CrossLink document.'
          },
          source_binding_rule__v: {
            type: 'string',
            description: 'Optional: Possible values are Latest version, Latest Steady State version, or Specific Document version.'
          },
          bound_source_major_version__v: {
            type: 'string',
            description: 'Optional: Major version number of the source document to bind to the CrossLink document.'
          },
          bound_source_minor_version__v: {
            type: 'string',
            description: 'Optional: Minor version number of the source document to bind to the CrossLink document.'
          }
        },
        required: ['name__v', 'type__v']
      }
    }
  }
};

export { apiTool };