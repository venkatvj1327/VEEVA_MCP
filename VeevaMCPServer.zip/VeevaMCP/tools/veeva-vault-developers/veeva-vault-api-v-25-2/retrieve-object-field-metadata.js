/**
 * Function to retrieve object field metadata from Veeva Vault.
 *
 * @param {Object} args - Arguments for the metadata retrieval.
 * @param {string} args.object_name - The name of the object (e.g., product__v).
 * @param {string} args.object_field_name - The name of the object field (e.g., id, name__v).
 * @param {boolean} [args.loc=false] - To retrieve localized (translated) strings.
 * @returns {Promise<Object>} - The result of the metadata retrieval.
 */
const executeFunction = async ({ object_name, object_field_name, loc = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  
  try {
    // Construct the URL with path variables and query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/metadata/vobjects/${object_name}/fields/${object_field_name}`);
    if (loc) {
      url.searchParams.append('loc', 'true');
    }

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving object field metadata:', error);
    return {
      error: `An error occurred while retrieving object field metadata: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving object field metadata from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_object_field_metadata',
      description: 'Retrieve object field metadata from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object (e.g., product__v).'
          },
          object_field_name: {
            type: 'string',
            description: 'The name of the object field (e.g., id, name__v).'
          },
          loc: {
            type: 'boolean',
            description: 'To retrieve localized (translated) strings.'
          }
        },
        required: ['object_name', 'object_field_name']
      }
    }
  }
};

export { apiTool };