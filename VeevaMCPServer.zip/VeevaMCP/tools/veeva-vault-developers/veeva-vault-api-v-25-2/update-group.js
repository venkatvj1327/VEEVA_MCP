/**
 * Function to update a group in Veeva Vault.
 *
 * @param {Object} args - Arguments for the group update.
 * @param {string} args.group_id - The ID of the group to update.
 * @param {string} [args.label__v] - Updates the label of the group.
 * @param {string} [args.members__v] - Comma-separated list of user IDs to assign to the group.
 * @param {string} [args.security_profiles__v] - Comma-separated list of security profiles.
 * @param {boolean} [args.active__v] - Set to false to mark the group as inactive.
 * @param {string} [args.group_description__v] - Updates the description of the group.
 * @param {boolean} [args.allow_delegation_among_members__v] - Set to true to allow delegation among group members.
 * @returns {Promise<Object>} - The result of the group update.
 */
const executeFunction = async ({ group_id, label__v, members__v, security_profiles__v, active__v, group_description__v, allow_delegation_among_members__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/objects/groups/${group_id}`;
  
  const body = new URLSearchParams();
  if (label__v) body.append('label__v', label__v);
  if (members__v) body.append('members__v', members__v);
  if (security_profiles__v) body.append('security_profiles__v', security_profiles__v);
  if (active__v !== undefined) body.append('active__v', active__v);
  if (group_description__v) body.append('group_description__v', group_description__v);
  if (allow_delegation_among_members__v !== undefined) body.append('allow_delegation_among_members__v', allow_delegation_among_members__v);

  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: body.toString()
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating group:', error);
    return {
      error: `An error occurred while updating the group: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating a group in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_group',
      description: 'Update a group in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          group_id: {
            type: 'string',
            description: 'The ID of the group to update.'
          },
          label__v: {
            type: 'string',
            description: 'Updates the label of the group.'
          },
          members__v: {
            type: 'string',
            description: 'Comma-separated list of user IDs to assign to the group.'
          },
          security_profiles__v: {
            type: 'string',
            description: 'Comma-separated list of security profiles.'
          },
          active__v: {
            type: 'boolean',
            description: 'Set to false to mark the group as inactive.'
          },
          group_description__v: {
            type: 'string',
            description: 'Updates the description of the group.'
          },
          allow_delegation_among_members__v: {
            type: 'boolean',
            description: 'Set to true to allow delegation among group members.'
          }
        },
        required: ['group_id']
      }
    }
  }
};

export { apiTool };