/**
 * Function to delete multiple object record attachments in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.object_name - The name of the object for which attachments are to be deleted.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {Buffer} args.fileData - The CSV file data containing the attachments to delete.
 * @returns {Promise<Object>} - The result of the deletion request.
 */
const executeFunction = async ({ object_name, sessionId, clientId, vaultDNS, version, fileData }) => {
  const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/attachments/batch`;
  
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers,
      body: fileData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error deleting attachments:', error);
    return {
      error: `An error occurred while deleting attachments: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting multiple object record attachments in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_multiple_attachments',
      description: 'Delete multiple object record attachments in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object for which attachments are to be deleted.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          fileData: {
            type: 'string',
            description: 'The CSV file data containing the attachments to delete.'
          }
        },
        required: ['object_name', 'sessionId', 'clientId', 'vaultDNS', 'version', 'fileData']
      }
    }
  }
};

export { apiTool };