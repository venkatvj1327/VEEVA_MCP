/**
 * Function to retrieve workflows from Veeva Vault.
 *
 * @param {Object} args - Arguments for retrieving workflows.
 * @param {string} [args.object__v] - The Vault object name to filter workflows.
 * @param {string} [args.record_id__v] - The object record ID to filter workflows.
 * @param {string} [args.participant] - The user ID to retrieve workflows for a specific user.
 * @param {string} [args.status__v] - The status of workflows to filter by.
 * @param {number} [args.offset] - The offset for pagination.
 * @param {number} [args.page_size] - The number of records to display per page.
 * @param {boolean} [args.loc] - Whether to retrieve localized strings.
 * @returns {Promise<Object>} - The result of the workflow retrieval.
 */
const executeFunction = async ({ object__v, record_id__v, participant, status__v, offset, page_size, loc }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/objectworkflows`);
    if (object__v && record_id__v) {
      url.searchParams.append('object__v', object__v);
      url.searchParams.append('record_id__v', record_id__v);
    } else if (participant) {
      url.searchParams.append('participant', participant);
    }
    if (status__v) {
      url.searchParams.append('status__v', status__v);
    }
    if (offset) {
      url.searchParams.append('offset', offset);
    }
    if (page_size) {
      url.searchParams.append('page_size', page_size);
    }
    if (loc) {
      url.searchParams.append('loc', loc);
    }

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving workflows:', error);
    return {
      error: `An error occurred while retrieving workflows: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving workflows from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_workflows',
      description: 'Retrieve workflows from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object__v: {
            type: 'string',
            description: 'The Vault object name to filter workflows.'
          },
          record_id__v: {
            type: 'string',
            description: 'The object record ID to filter workflows.'
          },
          participant: {
            type: 'string',
            description: 'The user ID to retrieve workflows for a specific user.'
          },
          status__v: {
            type: 'string',
            description: 'The status of workflows to filter by.'
          },
          offset: {
            type: 'integer',
            description: 'The offset for pagination.'
          },
          page_size: {
            type: 'integer',
            description: 'The number of records to display per page.'
          },
          loc: {
            type: 'boolean',
            description: 'Whether to retrieve localized strings.'
          }
        }
      }
    }
  }
};

export { apiTool };