/**
 * Function to initiate a document workflow in Veeva Vault.
 *
 * @param {Object} args - Arguments for initiating the document workflow.
 * @param {string} args.workflow_name - The name of the document workflow to initiate.
 * @param {string} args.documents__sys - A comma-separated list of document id field values (max 100 documents).
 * @param {string} args.description__sys - Description of the workflow (max 128 characters).
 * @returns {Promise<Object>} - The result of the workflow initiation.
 */
const executeFunction = async ({ workflow_name, documents__sys, description__sys }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/documents/actions/${workflow_name}`;
    
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    const body = JSON.stringify({
      documents__sys,
      description__sys
    });

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error initiating document workflow:', error);
    return {
      error: `An error occurred while initiating the document workflow: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for initiating a document workflow in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'initiate_document_workflow',
      description: 'Initiate a document workflow in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          workflow_name: {
            type: 'string',
            description: 'The name of the document workflow to initiate.'
          },
          documents__sys: {
            type: 'string',
            description: 'A comma-separated list of document id field values (max 100 documents).'
          },
          description__sys: {
            type: 'string',
            description: 'Description of the workflow (max 128 characters).'
          }
        },
        required: ['workflow_name', 'documents__sys']
      }
    }
  }
};

export { apiTool };