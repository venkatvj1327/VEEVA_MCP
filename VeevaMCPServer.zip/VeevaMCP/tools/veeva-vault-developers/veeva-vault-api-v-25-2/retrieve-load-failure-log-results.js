/**
 * Function to retrieve load failure log results from Veeva Vault API.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.job_id - The id value of the requested load job.
 * @param {string} args.task_id - The id value of the requested load task.
 * @returns {Promise<Object>} - The result of the load failure log retrieval.
 */
const executeFunction = async ({ job_id, task_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path variables
    const url = `https://${vaultDNS}/api/${version}/services/loader/${job_id}/tasks/${task_id}/failurelog`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(errorData);
    }

    // Parse and return the response data
    const data = await response.text(); // Assuming the response is in CSV format
    return data;
  } catch (error) {
    console.error('Error retrieving load failure log results:', error);
    return {
      error: `An error occurred while retrieving load failure log results: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving load failure log results from Veeva Vault API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_load_failure_log',
      description: 'Retrieve load failure log results from Veeva Vault API.',
      parameters: {
        type: 'object',
        properties: {
          job_id: {
            type: 'string',
            description: 'The id value of the requested load job.'
          },
          task_id: {
            type: 'string',
            description: 'The id value of the requested load task.'
          }
        },
        required: ['job_id', 'task_id']
      }
    }
  }
};

export { apiTool };