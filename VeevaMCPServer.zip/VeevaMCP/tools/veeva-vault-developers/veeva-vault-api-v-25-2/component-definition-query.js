/**
 * Function to perform a Component Definition Query on Veeva Vault API.
 *
 * @param {Object} args - Arguments for the query.
 * @param {string} args.q - A VQL query on the vault_component__v or vault_package_component__v query target.
 * @returns {Promise<Object>} - The result of the component definition query.
 */
const executeFunction = async ({ q }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/query/components`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body of the request
    const body = new URLSearchParams();
    body.append('q', q);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error performing component definition query:', error);
    return {
      error: `An error occurred while performing the component definition query: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for performing a Component Definition Query on Veeva Vault API.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'component_definition_query',
      description: 'Perform a Component Definition Query on Veeva Vault API.',
      parameters: {
        type: 'object',
        properties: {
          q: {
            type: 'string',
            description: 'A VQL query on the vault_component__v or vault_package_component__v query target.'
          }
        },
        required: ['q']
      }
    }
  }
};

export { apiTool };