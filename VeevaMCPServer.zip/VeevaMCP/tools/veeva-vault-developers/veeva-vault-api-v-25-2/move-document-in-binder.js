/**
 * Function to move a document within a binder in Veeva Vault.
 *
 * @param {Object} args - Arguments for moving the document.
 * @param {string} args.binder_id - The ID of the binder where the document is located.
 * @param {string} args.section_id - The ID of the section where the document is located.
 * @param {number} [args.order__v] - The new position of the document within the binder or section (optional).
 * @param {string} [args.parent_id__v] - The ID of the new parent node to move the document to (optional).
 * @returns {Promise<Object>} - The result of the move document operation.
 */
const executeFunction = async ({ binder_id, section_id, order__v, parent_id__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/documents/${section_id}`;
    
    // Prepare the request body
    const body = new URLSearchParams();
    if (order__v) body.append('order__v', order__v);
    if (parent_id__v) body.append('parent_id__v', parent_id__v);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error moving document in binder:', error);
    return {
      error: `An error occurred while moving the document: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for moving a document in a binder in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'move_document_in_binder',
      description: 'Move a document within a binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder where the document is located.'
          },
          section_id: {
            type: 'string',
            description: 'The ID of the section where the document is located.'
          },
          order__v: {
            type: 'number',
            description: 'The new position of the document within the binder or section (optional).'
          },
          parent_id__v: {
            type: 'string',
            description: 'The ID of the new parent node to move the document to (optional).'
          }
        },
        required: ['binder_id', 'section_id']
      }
    }
  }
};

export { apiTool };