/**
 * Function to reclassify a single document in Veeva Vault.
 *
 * @param {Object} args - Arguments for the reclassification.
 * @param {string} args.doc_id - The document ID for the document to be reclassified.
 * @param {string} [args.type__v] - The name of the document type.
 * @param {string} [args.lifecycle__v] - The name of the document lifecycle.
 * @param {boolean} [args.reclassify=true] - Set to true to perform reclassification.
 * @param {string} [args.subtype__v] - The name of the document subtype (if one exists on the type).
 * @param {string} [args.classification__v] - The name of the document classification (if one exists on the subtype).
 * @param {string} [args.document_number__v] - The document number for the reclassified document.
 * @param {string} [args.status__v] - Specifies the document lifecycle state for the reclassified document.
 * @returns {Promise<Object>} - The result of the reclassification operation.
 */
const executeFunction = async ({ doc_id, type__v, lifecycle__v, reclassify = true, subtype__v, classification__v, document_number__v, status__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}`;
  
  // Prepare the body of the request
  const body = new URLSearchParams();
  if (type__v) body.append('type__v', type__v);
  if (lifecycle__v) body.append('lifecycle__v', lifecycle__v);
  body.append('reclassify', reclassify.toString());
  if (subtype__v) body.append('subtype__v', subtype__v);
  if (classification__v) body.append('classification__v', classification__v);
  if (document_number__v) body.append('document_number__v', document_number__v);
  if (status__v) body.append('status__v', status__v);

  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId,
    'X-VaultAPI-MigrationMode': 'true' // Optional, can be enabled based on user needs
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error reclassifying document:', error);
    return {
      error: `An error occurred while reclassifying the document: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for reclassifying a single document in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'reclassify_single_document',
      description: 'Reclassify a single document in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID for the document to be reclassified.'
          },
          type__v: {
            type: 'string',
            description: 'The name of the document type.'
          },
          lifecycle__v: {
            type: 'string',
            description: 'The name of the document lifecycle.'
          },
          reclassify: {
            type: 'boolean',
            description: 'Set to true to perform reclassification.'
          },
          subtype__v: {
            type: 'string',
            description: 'The name of the document subtype (if one exists on the type).'
          },
          classification__v: {
            type: 'string',
            description: 'The name of the document classification (if one exists on the subtype).'
          },
          document_number__v: {
            type: 'string',
            description: 'The document number for the reclassified document.'
          },
          status__v: {
            type: 'string',
            description: 'Specifies the document lifecycle state for the reclassified document.'
          }
        },
        required: ['doc_id']
      }
    }
  }
};

export { apiTool };