/**
 * Function to download controlled copy job results from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.lifecycle_and_state_and_action - The lifecycle, state, and action in the format `{lifecycle_name}.{state_name}.{action_name}`.
 * @param {string} args.job_id - The ID of the job for which to download results.
 * @returns {Promise<Object>} - The result of the download request.
 */
const executeFunction = async ({ lifecycle_and_state_and_action, job_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL
    const url = `https://${vaultDNS}/api/${version}/objects/documents/actions/${lifecycle_and_state_and_action}/${job_id}/results`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading controlled copy job results:', error);
    return {
      error: `An error occurred while downloading controlled copy job results: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading controlled copy job results from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_controlled_copy_job_results',
      description: 'Download controlled copy job results from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          lifecycle_and_state_and_action: {
            type: 'string',
            description: 'The lifecycle, state, and action in the format `{lifecycle_name}.{state_name}.{action_name}`.'
          },
          job_id: {
            type: 'string',
            description: 'The ID of the job for which to download results.'
          }
        },
        required: ['lifecycle_and_state_and_action', 'job_id']
      }
    }
  }
};

export { apiTool };