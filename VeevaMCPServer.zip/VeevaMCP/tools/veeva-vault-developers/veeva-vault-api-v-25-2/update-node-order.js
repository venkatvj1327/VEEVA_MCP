/**
 * Function to update the order of a child node in the Veeva Vault hierarchy.
 *
 * @param {Object} args - Arguments for updating the node order.
 * @param {string} args.parent_node_id - The ID of the parent node in the hierarchy.
 * @param {string} args.id - The ID of the child node to update.
 * @param {string} args.order__v - The new order for the node in the hierarchy.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ parent_node_id, id, order__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // fixed version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/composites/trees/edl_hierarchy__v/${parent_node_id}/children`;

  const body = new URLSearchParams();
  body.append('id', id);
  body.append('order__v', order__v);

  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: body.toString()
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating node order:', error);
    return {
      error: `An error occurred while updating the node order: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating the node order in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_node_order',
      description: 'Update the order of a child node in the Veeva Vault hierarchy.',
      parameters: {
        type: 'object',
        properties: {
          parent_node_id: {
            type: 'string',
            description: 'The ID of the parent node in the hierarchy.'
          },
          id: {
            type: 'string',
            description: 'The ID of the child node to update.'
          },
          order__v: {
            type: 'string',
            description: 'The new order for the node in the hierarchy.'
          }
        },
        required: ['parent_node_id', 'id', 'order__v']
      }
    }
  }
};

export { apiTool };