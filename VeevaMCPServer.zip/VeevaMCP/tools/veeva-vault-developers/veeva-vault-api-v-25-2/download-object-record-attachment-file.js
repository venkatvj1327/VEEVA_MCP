/**
 * Function to download an object record attachment file from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.object_name - The object name (e.g., product__v, country__v).
 * @param {string} args.object_record_id - The object record ID.
 * @param {string} args.attachment_id - The attachment ID.
 * @param {string} args.attachment_version - The attachment version.
 * @returns {Promise<Buffer>} - The file data of the attachment.
 */
const executeFunction = async ({ object_name, object_record_id, attachment_id, attachment_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/attachments/${attachment_id}/versions/${attachment_version}/file`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response as a Buffer
    const data = await response.buffer();
    return data;
  } catch (error) {
    console.error('Error downloading attachment file:', error);
    return {
      error: `An error occurred while downloading the attachment file: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading object record attachment files from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_object_record_attachment_file',
      description: 'Download an object record attachment file from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name (e.g., product__v, country__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The object record ID.'
          },
          attachment_id: {
            type: 'string',
            description: 'The attachment ID.'
          },
          attachment_version: {
            type: 'string',
            description: 'The attachment version.'
          }
        },
        required: ['object_name', 'object_record_id', 'attachment_id', 'attachment_version']
      }
    }
  }
};

export { apiTool };