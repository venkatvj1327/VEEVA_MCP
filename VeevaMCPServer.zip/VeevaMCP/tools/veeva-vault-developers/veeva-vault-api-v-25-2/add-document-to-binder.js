/**
 * Function to add a document to a binder in Veeva Vault.
 *
 * @param {Object} args - Arguments for adding a document to a binder.
 * @param {string} args.binder_id - The ID of the binder to which the document will be added.
 * @param {string} args.document_id__v - The ID of the document being added to the binder.
 * @param {string} [args.parent_id__v] - Section ID of the parent section, if the document will be in a section rather than top-level.
 * @param {number} [args.order__v] - Position of the document within the binder or section.
 * @param {string} [args.binding_rule__v] - Binding rule indicating which version of the document will be linked to the binder.
 * @param {number} [args.major_version__v] - Major version of the document to be linked if binding_rule is specific.
 * @param {number} [args.minor_version__v] - Minor version of the document to be linked if binding_rule is specific.
 * @returns {Promise<Object>} - The result of the add document operation.
 */
const executeFunction = async ({ binder_id, document_id__v, parent_id__v, order__v, binding_rule__v, major_version__v, minor_version__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/documents`;

  const body = new URLSearchParams();
  body.append('document_id__v', document_id__v);
  if (parent_id__v) body.append('parent_id__v', parent_id__v);
  if (order__v) body.append('order__v', order__v);
  if (binding_rule__v) body.append('binding_rule__v', binding_rule__v);
  if (major_version__v) body.append('major_version__v', major_version__v);
  if (minor_version__v) body.append('minor_version__v', minor_version__v);

  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error adding document to binder:', error);
    return {
      error: `An error occurred while adding the document to the binder: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for adding a document to a binder in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'add_document_to_binder',
      description: 'Add a document to a binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder to which the document will be added.'
          },
          document_id__v: {
            type: 'string',
            description: 'The ID of the document being added to the binder.'
          },
          parent_id__v: {
            type: 'string',
            description: 'Section ID of the parent section, if the document will be in a section rather than top-level.'
          },
          order__v: {
            type: 'integer',
            description: 'Position of the document within the binder or section.'
          },
          binding_rule__v: {
            type: 'string',
            description: 'Binding rule indicating which version of the document will be linked to the binder.'
          },
          major_version__v: {
            type: 'integer',
            description: 'Major version of the document to be linked if binding_rule is specific.'
          },
          minor_version__v: {
            type: 'integer',
            description: 'Minor version of the document to be linked if binding_rule is specific.'
          }
        },
        required: ['binder_id', 'document_id__v']
      }
    }
  }
};

export { apiTool };