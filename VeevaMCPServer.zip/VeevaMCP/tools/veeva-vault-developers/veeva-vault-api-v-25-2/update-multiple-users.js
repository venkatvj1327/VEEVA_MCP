/**
 * Function to update multiple users in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version.
 * @param {Object} args.userData - The user data to update, formatted as JSON.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, userData }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/users`;
  const token = process.env.VEEVA_VAULT_DEVELOPERS_API_KEY;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/json',
      'Accept': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: JSON.stringify(userData)
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating users:', error);
    return {
      error: `An error occurred while updating users: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating multiple users in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_multiple_users',
      description: 'Update multiple users in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          },
          userData: {
            type: 'object',
            description: 'The user data to update, formatted as JSON.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version', 'userData']
      }
    }
  }
};

export { apiTool };