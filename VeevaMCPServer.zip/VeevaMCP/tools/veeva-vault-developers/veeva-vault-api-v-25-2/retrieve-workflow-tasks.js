/**
 * Function to retrieve workflow tasks from Veeva Vault.
 *
 * @param {Object} args - Arguments for retrieving workflow tasks.
 * @param {string} [args.object__v] - The Vault object name for which to retrieve tasks.
 * @param {string} [args.record_id__v] - The record ID of the object.
 * @param {string} [args.assignee__v] - The user ID to filter tasks by assignee. Use 'me' to retrieve your own tasks.
 * @param {string} [args.status__v] - Specific statuses to filter tasks.
 * @param {number} [args.offset] - The offset for pagination.
 * @param {number} [args.page_size] - The number of records to display per page.
 * @param {boolean} [args.loc] - Set to true to retrieve localized strings.
 * @returns {Promise<Object>} - The result of the workflow tasks retrieval.
 */
const executeFunction = async ({ object__v, record_id__v, assignee__v, status__v, offset, page_size, loc }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/objectworkflows/tasks`);
    if (object__v && record_id__v) {
      url.searchParams.append('object__v', object__v);
      url.searchParams.append('record_id__v', record_id__v);
    } else if (assignee__v) {
      url.searchParams.append('assignee__v', assignee__v);
    }
    if (status__v) url.searchParams.append('status__v', status__v);
    if (offset) url.searchParams.append('offset', offset.toString());
    if (page_size) url.searchParams.append('page_size', page_size.toString());
    if (loc) url.searchParams.append('loc', 'true');

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving workflow tasks:', error);
    return {
      error: `An error occurred while retrieving workflow tasks: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving workflow tasks from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_workflow_tasks',
      description: 'Retrieve all available tasks across all workflows in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object__v: {
            type: 'string',
            description: 'The Vault object name for which to retrieve tasks.'
          },
          record_id__v: {
            type: 'string',
            description: 'The record ID of the object.'
          },
          assignee__v: {
            type: 'string',
            description: 'The user ID to filter tasks by assignee.'
          },
          status__v: {
            type: 'string',
            description: 'Specific statuses to filter tasks.'
          },
          offset: {
            type: 'integer',
            description: 'The offset for pagination.'
          },
          page_size: {
            type: 'integer',
            description: 'The number of records to display per page.'
          },
          loc: {
            type: 'boolean',
            description: 'Set to true to retrieve localized strings.'
          }
        }
      }
    }
  }
};

export { apiTool };