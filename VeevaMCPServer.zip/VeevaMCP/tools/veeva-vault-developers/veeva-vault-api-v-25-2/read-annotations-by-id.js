/**
 * Function to read annotations by ID from Veeva Vault.
 *
 * @param {Object} args - Arguments for the annotation retrieval.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.major_version - The major version number of the document.
 * @param {string} args.minor_version - The minor version number of the document.
 * @param {string} args.annotation_id - The annotation ID.
 * @returns {Promise<Object>} - The result of the annotation retrieval.
 */
const executeFunction = async ({ doc_id, major_version, minor_version, annotation_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path parameters
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/annotations/${annotation_id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error reading annotation by ID:', error);
    return {
      error: `An error occurred while reading the annotation: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for reading annotations by ID from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'read_annotations_by_id',
      description: 'Retrieve a specific annotation by the annotation ID.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the document.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the document.'
          },
          annotation_id: {
            type: 'string',
            description: 'The annotation ID.'
          }
        },
        required: ['doc_id', 'major_version', 'minor_version', 'annotation_id']
      }
    }
  }
};

export { apiTool };