/**
 * Function to upload a document version rendition to Veeva Vault.
 *
 * @param {Object} args - Arguments for the upload.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.major_version - The document major version number.
 * @param {string} args.minor_version - The document minor version number.
 * @param {string} args.rendition_type - The document rendition type.
 * @param {Buffer} args.file - The file to upload.
 * @returns {Promise<Object>} - The result of the upload operation.
 */
const executeFunction = async ({ doc_id, major_version, minor_version, rendition_type, file }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/renditions/${rendition_type}`;
    
    const formData = new FormData();
    formData.append('file', file);

    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error uploading document version rendition:', error);
    return {
      error: `An error occurred while uploading the document version rendition: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for uploading a document version rendition to Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'upload_document_version_rendition',
      description: 'Upload a document version rendition to Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          major_version: {
            type: 'string',
            description: 'The document major version number.'
          },
          minor_version: {
            type: 'string',
            description: 'The document minor version number.'
          },
          rendition_type: {
            type: 'string',
            description: 'The document rendition type.'
          },
          file: {
            type: 'string',
            description: 'The file to upload.'
          }
        },
        required: ['doc_id', 'major_version', 'minor_version', 'rendition_type', 'file']
      }
    }
  }
};

export { apiTool };