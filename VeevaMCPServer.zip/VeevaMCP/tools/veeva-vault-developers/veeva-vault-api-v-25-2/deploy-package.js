/**
 * Function to deploy a package in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deployment.
 * @param {string} args.package_id - The ID of the package to be deployed.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @param {string} args.vaultDNS - The DNS of the vault.
 * @param {string} args.version - The API version.
 * @returns {Promise<Object>} - The result of the package deployment.
 */
const executeFunction = async ({ package_id, sessionId, clientId, vaultDNS, version }) => {
  const url = `https://${vaultDNS}/api/${version}/vobject/vault_package__v/${package_id}/actions/deploy`;
  
  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error deploying package:', error);
    return {
      error: `An error occurred while deploying the package: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deploying a package in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'deploy_package',
      description: 'Deploy a package in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          package_id: {
            type: 'string',
            description: 'The ID of the package to be deployed.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the vault.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          }
        },
        required: ['package_id', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };