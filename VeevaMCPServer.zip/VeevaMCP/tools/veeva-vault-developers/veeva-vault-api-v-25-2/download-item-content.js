/**
 * Function to download item content from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.item - The absolute path to the file or folder to download.
 * @param {string} [args.sessionId=''] - The session ID for authorization.
 * @param {string} [args.clientId=''] - The client ID for identifying the request.
 * @param {string} [args.range=''] - Optional range of bytes to include in the download.
 * @returns {Promise<Object>} - The result of the download request.
 */
const executeFunction = async ({ item, sessionId = '', clientId = '', range = '' }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/services/file_staging/items/content/${item}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // If a range is provided, add it to the headers
    if (range) {
      headers['Range'] = range;
    }

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading item content:', error);
    return {
      error: `An error occurred while downloading item content: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading item content from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_item_content',
      description: 'Download item content from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          item: {
            type: 'string',
            description: 'The absolute path to the file or folder to download.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          range: {
            type: 'string',
            description: 'Optional range of bytes to include in the download.'
          }
        },
        required: ['item']
      }
    }
  }
};

export { apiTool };