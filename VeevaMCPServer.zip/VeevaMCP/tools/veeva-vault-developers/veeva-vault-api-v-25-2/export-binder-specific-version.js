/**
 * Function to export a specific version of a binder from Veeva Vault.
 *
 * @param {Object} args - Arguments for the export.
 * @param {string} args.binder_id - The ID of the binder to export.
 * @param {string} args.major_version - The major version number of the binder.
 * @param {string} args.minor_version - The minor version number of the binder.
 * @param {Object} [options] - Optional parameters for the export.
 * @param {boolean} [options.source=true] - Whether to include source content.
 * @param {string} [options.renditiontype='viewable_rendition__v'] - The type of rendition to include.
 * @param {string} [options.docversion='major'] - The version of documents to include.
 * @param {string} [options.attachments='all'] - The version of attachments to include.
 * @param {string} [options.export='name__v,title__v,document_number__v'] - Configurable filename metadata.
 * @param {boolean} [options.docfield=false] - Whether to exclude document metadata CSV.
 * @returns {Promise<Object>} - The result of the export operation.
 */
const executeFunction = async ({ binder_id, major_version, minor_version, options = {} }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL for the export request
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/versions/${major_version}/${minor_version}/actions/export`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Set up query parameters
    const queryParams = new URLSearchParams();
    queryParams.append('source', options.source !== undefined ? options.source : true);
    queryParams.append('renditiontype', options.renditiontype || 'viewable_rendition__v');
    queryParams.append('docversion', options.docversion || 'major');
    queryParams.append('attachments', options.attachments || 'all');
    queryParams.append('export', options.export || 'name__v,title__v,document_number__v');
    queryParams.append('docfield', options.docfield !== undefined ? options.docfield : false);

    // Perform the fetch request
    const response = await fetch(`${url}?${queryParams.toString()}`, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error exporting binder:', error);
    return {
      error: `An error occurred while exporting the binder: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for exporting a binder from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'export_binder',
      description: 'Export a specific version of a binder from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder to export.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the binder.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the binder.'
          },
          options: {
            type: 'object',
            properties: {
              source: {
                type: 'boolean',
                description: 'Whether to include source content.'
              },
              renditiontype: {
                type: 'string',
                description: 'The type of rendition to include.'
              },
              docversion: {
                type: 'string',
                description: 'The version of documents to include.'
              },
              attachments: {
                type: 'string',
                description: 'The version of attachments to include.'
              },
              export: {
                type: 'string',
                description: 'Configurable filename metadata.'
              },
              docfield: {
                type: 'boolean',
                description: 'Whether to exclude document metadata CSV.'
              }
            }
          }
        },
        required: ['binder_id', 'major_version', 'minor_version']
      }
    }
  }
};

export { apiTool };