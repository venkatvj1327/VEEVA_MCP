/**
 * Function to retrieve user permissions from Veeva Vault.
 *
 * @param {Object} args - Arguments for the user permissions retrieval.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} [args.vaultDNS] - The DNS of the Vault (default is required).
 * @param {string} [args.version] - The API version (default is required).
 * @param {string} [args.filter] - Optional filter for specific permissions.
 * @returns {Promise<Object>} - The result of the user permissions retrieval.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, filter }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/objects/users/me/permissions`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Construct the URL with query parameters if filter is provided
    const url = new URL(baseUrl);
    if (filter) {
      url.searchParams.append('filter', filter);
    }

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving user permissions:', error);
    return {
      error: `An error occurred while retrieving user permissions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving user permissions from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_user_permissions',
      description: 'Retrieve all object and object field permissions assigned to the currently authenticated user.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          },
          filter: {
            type: 'string',
            description: 'Optional filter for specific permissions.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };