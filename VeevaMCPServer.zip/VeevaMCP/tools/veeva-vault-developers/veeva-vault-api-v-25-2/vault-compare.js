/**
 * Function to compare the configuration of two different Vaults in Veeva Vault.
 *
 * @param {Object} args - Arguments for the comparison.
 * @param {string} args.vault_id - The ID of the target Vault for the comparison.
 * @param {string} [args.results_type="differences"] - The type of results to include in the comparison.
 * @param {string} [args.details_type="complex"] - The level of detail to include in the comparison.
 * @param {boolean} [args.include_doc_binder_templates=true] - Whether to include Document and Binder Templates in the comparison.
 * @param {boolean} [args.include_vault_settings=true] - Whether to include Vault Settings in the comparison.
 * @param {string} [args.component_types="Doctype, Object, Docfield"] - Comma-separated list of component types to include in the comparison.
 * @param {boolean} [args.generate_outbound_packages=false] - Whether to generate an Outbound Package based on differences.
 * @returns {Promise<Object>} - The result of the Vault comparison.
 */
const executeFunction = async ({ vault_id, results_type = 'differences', details_type = 'complex', include_doc_binder_templates = true, include_vault_settings = true, component_types = 'Doctype, Object, Docfield', generate_outbound_packages = false }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/vault/actions/compare`;

    // Prepare the request body
    const body = new URLSearchParams();
    body.append('vault_id', vault_id);
    body.append('results_type', results_type);
    body.append('details_type', details_type);
    body.append('include_doc_binder_templates', include_doc_binder_templates.toString());
    body.append('include_vault_settings', include_vault_settings.toString());
    body.append('component_types', component_types);
    body.append('generate_outbound_packages', generate_outbound_packages.toString());

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error comparing Vaults:', error);
    return {
      error: `An error occurred while comparing Vaults: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for comparing Vaults in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'vault_compare',
      description: 'Compare the configuration of two different Vaults in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vault_id: {
            type: 'string',
            description: 'The ID of the target Vault for the comparison.'
          },
          results_type: {
            type: 'string',
            enum: ['differences', 'complete'],
            description: 'The type of results to include in the comparison.'
          },
          details_type: {
            type: 'string',
            enum: ['none', 'simple', 'complex'],
            description: 'The level of detail to include in the comparison.'
          },
          include_doc_binder_templates: {
            type: 'boolean',
            description: 'Whether to include Document and Binder Templates in the comparison.'
          },
          include_vault_settings: {
            type: 'boolean',
            description: 'Whether to include Vault Settings in the comparison.'
          },
          component_types: {
            type: 'string',
            description: 'Comma-separated list of component types to include in the comparison.'
          },
          generate_outbound_packages: {
            type: 'boolean',
            description: 'Whether to generate an Outbound Package based on differences.'
          }
        },
        required: ['vault_id']
      }
    }
  }
};

export { apiTool };