/**
 * Function to assign users and groups to roles on a single document in Veeva Vault.
 *
 * @param {Object} args - Arguments for the role assignment.
 * @param {string} args.id - The ID of the document to which roles are being assigned.
 * @param {string} args.role_name__v_users - A comma-separated list of user IDs to assign to the role.
 * @param {string} args.role_name__v_groups - A comma-separated list of group IDs to assign to the role.
 * @returns {Promise<Object>} - The result of the role assignment operation.
 */
const executeFunction = async ({ id, role_name__v_users, role_name__v_groups }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${id}/roles`;

    const body = new URLSearchParams();
    if (role_name__v_users) {
      body.append('role_name__v.users', role_name__v_users);
    }
    if (role_name__v_groups) {
      body.append('role_name__v.groups', role_name__v_groups);
    }

    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error assigning users and groups to roles:', error);
    return {
      error: `An error occurred while assigning users and groups to roles: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for assigning users and groups to roles on a single document in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'assign_users_groups_to_roles',
      description: 'Assign users and groups to roles on a single document in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          id: {
            type: 'string',
            description: 'The ID of the document to which roles are being assigned.'
          },
          role_name__v_users: {
            type: 'string',
            description: 'A comma-separated list of user IDs to assign to the role.'
          },
          role_name__v_groups: {
            type: 'string',
            description: 'A comma-separated list of group IDs to assign to the role.'
          }
        },
        required: ['id']
      }
    }
  }
};

export { apiTool };