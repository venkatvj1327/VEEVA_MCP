/**
 * Function to assign users and groups to roles on object records in Veeva Vault.
 *
 * @param {Object} args - Arguments for the assignment.
 * @param {string} args.object_name - The name of the object where you want to update records.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.csvData - The CSV data to be sent in the request body.
 * @returns {Promise<Object>} - The result of the assignment operation.
 */
const executeFunction = async ({ object_name, sessionId, clientId, csvData }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/roles`;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: csvData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error assigning users and groups to roles:', error);
    return {
      error: `An error occurred while assigning users and groups to roles: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for assigning users and groups to roles on object records in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'assign_users_groups_to_roles',
      description: 'Assign users and groups to roles on object records in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object where you want to update records.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          csvData: {
            type: 'string',
            description: 'The CSV data to be sent in the request body.'
          }
        },
        required: ['object_name', 'sessionId', 'clientId', 'csvData']
      }
    }
  }
};

export { apiTool };