/**
 * Function to reassign workflow tasks in Veeva Vault.
 *
 * @param {Object} args - Arguments for the task reassignment.
 * @param {string} args.current_task_assignee - The user ID of the user whose tasks you wish to reassign.
 * @param {string} args.new_task_assignee - The user ID of the user who will receive the newly assigned tasks.
 * @returns {Promise<Object>} - The result of the task reassignment.
 */
const executeFunction = async ({ current_task_assignee, new_task_assignee }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/object/workflow/actions/reassigntasks`;

  const body = new URLSearchParams();
  body.append('current_task_assignee', current_task_assignee);
  body.append('new_task_assignee', new_task_assignee);

  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId,
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString(),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error reassigning workflow tasks:', error);
    return {
      error: `An error occurred while reassigning workflow tasks: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for reassigning workflow tasks in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'reassign_workflow_tasks',
      description: 'Reassign workflow tasks in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          current_task_assignee: {
            type: 'string',
            description: 'The user ID of the user whose tasks you wish to reassign.'
          },
          new_task_assignee: {
            type: 'string',
            description: 'The user ID of the user who will receive the newly assigned tasks.'
          }
        },
        required: ['current_task_assignee', 'new_task_assignee']
      }
    }
  }
};

export { apiTool };