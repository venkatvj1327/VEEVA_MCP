/**
 * Function to retrieve the plain text of a specific document version from Veeva Vault.
 *
 * @param {Object} args - Arguments for the document retrieval.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.major_version - The document major version number.
 * @param {string} args.minor_version - The document minor version number.
 * @returns {Promise<string>} - The plain text of the specified document version.
 */
const executeFunction = async ({ doc_id, major_version, minor_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/text`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'text/plain',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(errorData);
    }

    // Return the plain text response
    const text = await response.text();
    return text;
  } catch (error) {
    console.error('Error retrieving document version text:', error);
    return {
      error: `An error occurred while retrieving document version text: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document version text from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_version_text',
      description: 'Retrieve the plain text of a specific document version from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          major_version: {
            type: 'string',
            description: 'The document major version number.'
          },
          minor_version: {
            type: 'string',
            description: 'The document minor version number.'
          }
        },
        required: ['doc_id', 'major_version', 'minor_version']
      }
    }
  }
};

export { apiTool };