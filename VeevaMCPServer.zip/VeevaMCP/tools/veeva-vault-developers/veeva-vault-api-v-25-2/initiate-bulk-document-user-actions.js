/**
 * Function to initiate bulk document user actions in Veeva Vault.
 *
 * @param {Object} args - Arguments for the bulk document user action.
 * @param {string} args.user_action_name - The user action name__v field value.
 * @param {string} args.docIds - A comma-separated list of document IDs, major and minor version numbers.
 * @param {string} args.lifecycle - The name of the document lifecycle.
 * @param {string} args.state - The current state of the document.
 * @returns {Promise<Object>} - The result of the bulk document user action initiation.
 */
const executeFunction = async ({ user_action_name, docIds, lifecycle, state }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/documents/lifecycle_actions/${user_action_name}`;

    // Prepare the form data
    const formData = new URLSearchParams();
    formData.append('docIds', docIds);
    formData.append('lifecycle', lifecycle);
    formData.append('state', state);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error initiating bulk document user actions:', error);
    return {
      error: `An error occurred while initiating bulk document user actions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for initiating bulk document user actions in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'initiate_bulk_document_user_actions',
      description: 'Initiate bulk document user actions in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          user_action_name: {
            type: 'string',
            description: 'The user action name__v field value.'
          },
          docIds: {
            type: 'string',
            description: 'A comma-separated list of document IDs, major and minor version numbers.'
          },
          lifecycle: {
            type: 'string',
            description: 'The name of the document lifecycle.'
          },
          state: {
            type: 'string',
            description: 'The current state of the document.'
          }
        },
        required: ['user_action_name', 'docIds', 'lifecycle', 'state']
      }
    }
  }
};

export { apiTool };