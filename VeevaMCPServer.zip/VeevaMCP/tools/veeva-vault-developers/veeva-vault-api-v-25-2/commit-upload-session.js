/**
 * Function to commit an upload session in Veeva Vault.
 *
 * @param {Object} args - Arguments for the commit upload session.
 * @param {string} args.upload_session_id - The ID of the upload session to commit.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} [args.vaultDNS] - The DNS of the Veeva Vault instance.
 * @param {string} [args.version] - The API version to use.
 * @returns {Promise<Object>} - The result of the commit upload session request.
 */
const executeFunction = async ({ upload_session_id, sessionId, clientId, vaultDNS, version }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/services/file_staging/upload/${upload_session_id}`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error committing upload session:', error);
    return {
      error: `An error occurred while committing the upload session: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for committing an upload session in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'commit_upload_session',
      description: 'Commit an upload session in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          upload_session_id: {
            type: 'string',
            description: 'The ID of the upload session to commit.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault instance.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['upload_session_id', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };