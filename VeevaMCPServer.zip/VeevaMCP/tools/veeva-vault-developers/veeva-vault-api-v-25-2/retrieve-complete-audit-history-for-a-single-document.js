/**
 * Function to retrieve the complete audit history for a single document in Veeva Vault.
 *
 * @param {Object} args - Arguments for the audit history retrieval.
 * @param {string} args.doc_id - The document ID for which to retrieve audit history.
 * @param {string} [args.start_date] - Specify a start date to retrieve audit history (YYYY-MM-DDTHH:MM:SSZ format).
 * @param {string} [args.end_date] - Specify an end date to retrieve audit history (YYYY-MM-DDTHH:MM:SSZ format).
 * @param {string} [args.format_result] - To request a CSV file of your audit history, use 'csv'.
 * @param {number} [args.limit] - Maximum number of histories per page (1 to 1000, defaults to 200).
 * @param {number} [args.offset] - Amount of offset from the entry returned for pagination.
 * @param {string} [args.events] - Comma-separated list of one or more audit events to retrieve their audit history.
 * @returns {Promise<Object>} - The result of the audit history retrieval.
 */
const executeFunction = async ({ doc_id, start_date, end_date, format_result, limit, offset, events }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path variable and query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/audittrail`);
    if (start_date) url.searchParams.append('start_date', start_date);
    if (end_date) url.searchParams.append('end_date', end_date);
    if (format_result) url.searchParams.append('format_result', format_result);
    if (limit) url.searchParams.append('limit', limit.toString());
    if (offset) url.searchParams.append('offset', offset.toString());
    if (events) url.searchParams.append('events', events);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving document audit history:', error);
    return {
      error: `An error occurred while retrieving document audit history: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document audit history in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_audit_history',
      description: 'Retrieve complete audit history for a single document in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID for which to retrieve audit history.'
          },
          start_date: {
            type: 'string',
            description: 'Specify a start date to retrieve audit history (YYYY-MM-DDTHH:MM:SSZ format).'
          },
          end_date: {
            type: 'string',
            description: 'Specify an end date to retrieve audit history (YYYY-MM-DDTHH:MM:SSZ format).'
          },
          format_result: {
            type: 'string',
            description: 'To request a CSV file of your audit history, use "csv".'
          },
          limit: {
            type: 'integer',
            description: 'Maximum number of histories per page (1 to 1000, defaults to 200).'
          },
          offset: {
            type: 'integer',
            description: 'Amount of offset from the entry returned for pagination.'
          },
          events: {
            type: 'string',
            description: 'Comma-separated list of one or more audit events to retrieve their audit history.'
          }
        },
        required: ['doc_id']
      }
    }
  }
};

export { apiTool };