/**
 * Function to create a binder from a template in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating the binder.
 * @param {string} args.fromTemplate - The name of the template to create the binder from.
 * @param {string} [args.lifecycle__v] - The lifecycle version (optional).
 * @param {string} [args.name__v] - The name of the binder (optional).
 * @param {string} [args.type__v] - The type of the binder (optional).
 * @param {string} [args.subtype__v] - The subtype of the binder (optional).
 * @param {string} [args.classification__v] - The classification of the binder (optional).
 * @param {string} [args.major_version_number__v] - The major version number (optional).
 * @param {string} [args.minor_version_number__v] - The minor version number (optional).
 * @returns {Promise<Object>} - The result of the binder creation.
 */
const executeFunction = async ({ fromTemplate, lifecycle__v, name__v, type__v, subtype__v, classification__v, major_version_number__v, minor_version_number__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/objects/binders`;

  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  const body = new URLSearchParams();
  body.append('fromTemplate', fromTemplate);
  if (lifecycle__v) body.append('lifecycle__v', lifecycle__v);
  if (name__v) body.append('name__v', name__v);
  if (type__v) body.append('type__v', type__v);
  if (subtype__v) body.append('subtype__v', subtype__v);
  if (classification__v) body.append('classification__v', classification__v);
  if (major_version_number__v) body.append('major_version_number__v', major_version_number__v);
  if (minor_version_number__v) body.append('minor_version_number__v', minor_version_number__v);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating binder from template:', error);
    return {
      error: `An error occurred while creating the binder: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a binder from a template in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_binder_from_template',
      description: 'Create a binder from a specified template in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          fromTemplate: {
            type: 'string',
            description: 'The name of the template to create the binder from.'
          },
          lifecycle__v: {
            type: 'string',
            description: 'The lifecycle version (optional).'
          },
          name__v: {
            type: 'string',
            description: 'The name of the binder (optional).'
          },
          type__v: {
            type: 'string',
            description: 'The type of the binder (optional).'
          },
          subtype__v: {
            type: 'string',
            description: 'The subtype of the binder (optional).'
          },
          classification__v: {
            type: 'string',
            description: 'The classification of the binder (optional).'
          },
          major_version_number__v: {
            type: 'string',
            description: 'The major version number (optional).'
          },
          minor_version_number__v: {
            type: 'string',
            description: 'The minor version number (optional).'
          }
        },
        required: ['fromTemplate']
      }
    }
  }
};

export { apiTool };