/**
 * Function to delete multiple document attachments in Veeva Vault.
 *
 * @param {Object} args - Arguments for the delete operation.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {Buffer} args.fileData - The CSV file data to be sent in the request.
 * @returns {Promise<Object>} - The result of the delete operation.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, fileData }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/attachments/batch`;
  const headers = {
    'Accept': 'application/json',
    'Authorization': sessionId,
    'Content-Type': 'text/csv',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'DELETE',
      headers,
      body: fileData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response data
    return await response.json();
  } catch (error) {
    console.error('Error deleting document attachments:', error);
    return {
      error: `An error occurred while deleting document attachments: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting multiple document attachments in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_multiple_document_attachments',
      description: 'Delete multiple document attachments in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          fileData: {
            type: 'string',
            description: 'The CSV file data to be sent in the request.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version', 'fileData']
      }
    }
  }
};

export { apiTool };