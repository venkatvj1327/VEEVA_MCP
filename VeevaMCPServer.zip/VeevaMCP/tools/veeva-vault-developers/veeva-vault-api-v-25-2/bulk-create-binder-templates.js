/**
 * Function to bulk create binder templates in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating binder templates.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @param {Buffer} args.csvData - The CSV data for the binder templates.
 * @returns {Promise<Object>} - The result of the bulk create operation.
 */
const executeFunction = async ({ vaultDNS, version, sessionId, clientId, csvData }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/binders/templates`;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: csvData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating binder templates:', error);
    return {
      error: `An error occurred while creating binder templates: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for bulk creating binder templates in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'bulk_create_binder_templates',
      description: 'Bulk create binder templates in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          csvData: {
            type: 'string',
            description: 'The CSV data for the binder templates.'
          }
        },
        required: ['vaultDNS', 'version', 'sessionId', 'clientId', 'csvData']
      }
    }
  }
};

export { apiTool };