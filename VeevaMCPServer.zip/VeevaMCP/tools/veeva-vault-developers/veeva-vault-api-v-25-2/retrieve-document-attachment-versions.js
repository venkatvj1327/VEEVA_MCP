/**
 * Function to retrieve document attachment versions from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.attachment_id - The attachment ID.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @returns {Promise<Object>} - The result of the document attachment versions retrieval.
 */
const executeFunction = async ({ doc_id, attachment_id, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/attachments/${attachment_id}/versions`;

  // Set up headers for the request
  const headers = {
    'Accept': 'application/json',
    'Authorization': sessionId,
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving document attachment versions:', error);
    return {
      error: `An error occurred while retrieving document attachment versions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document attachment versions from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_attachment_versions',
      description: 'Retrieve document attachment versions from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          attachment_id: {
            type: 'string',
            description: 'The attachment ID.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['doc_id', 'attachment_id', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };