/**
 * Function to import a VPK package to Veeva Vault.
 *
 * @param {Object} args - Arguments for the import.
 * @param {File} args.file - The .vpk file to be imported.
 * @returns {Promise<Object>} - The result of the import operation.
 */
const executeFunction = async ({ file }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/services/package`;

    const formData = new FormData();
    formData.append('file', file);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error importing package:', error);
    return {
      error: `An error occurred while importing the package: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for importing a VPK package to Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'import_package',
      description: 'Import a VPK package to Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          file: {
            type: 'string',
            description: 'The .vpk file to be imported.'
          }
        },
        required: ['file']
      }
    }
  }
};

export { apiTool };