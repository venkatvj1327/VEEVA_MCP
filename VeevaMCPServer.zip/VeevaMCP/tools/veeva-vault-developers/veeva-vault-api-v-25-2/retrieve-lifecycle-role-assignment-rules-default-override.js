/**
 * Function to retrieve Lifecycle Role Assignment Rules from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} [args.lifecycle] - The name of the lifecycle to retrieve information from.
 * @param {string} [args.role] - The name of the role to retrieve information from.
 * @param {string} [args.product] - The ID/name of a specific product for product-based override rules.
 * @param {string} [args.country] - The ID/name of a specific country for country-based override rules.
 * @param {string} [args.study] - The ID/name of a specific study for study-based override rules.
 * @param {string} [args.study_country] - The ID/name of a specific study country for study country-based override rules.
 * @returns {Promise<Object>} - The result of the retrieval.
 */
const executeFunction = async ({ vaultDNS, version, lifecycle, role, product, country, study, study_country }) => {
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  try {
    // Construct the URL with query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/configuration/role_assignment_rule`);
    if (lifecycle) url.searchParams.append('lifecycle__v', lifecycle);
    if (role) url.searchParams.append('role__v', role);
    if (product) url.searchParams.append('product__v', product);
    if (country) url.searchParams.append('country__v', country);
    if (study) url.searchParams.append('study__v', study);
    if (study_country) url.searchParams.append('study_country__v', study_country);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving Lifecycle Role Assignment Rules:', error);
    return {
      error: `An error occurred while retrieving Lifecycle Role Assignment Rules: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving Lifecycle Role Assignment Rules from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_lifecycle_role_assignment_rules',
      description: 'Retrieve Lifecycle Role Assignment Rules from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          lifecycle: {
            type: 'string',
            description: 'The name of the lifecycle to retrieve information from.'
          },
          role: {
            type: 'string',
            description: 'The name of the role to retrieve information from.'
          },
          product: {
            type: 'string',
            description: 'The ID/name of a specific product for product-based override rules.'
          },
          country: {
            type: 'string',
            description: 'The ID/name of a specific country for country-based override rules.'
          },
          study: {
            type: 'string',
            description: 'The ID/name of a specific study for study-based override rules.'
          },
          study_country: {
            type: 'string',
            description: 'The ID/name of a specific study country for study country-based override rules.'
          }
        },
        required: ['vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };