/**
 * Function to retrieve binder entry criteria from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.id - The binder ID from which to retrieve entry criteria.
 * @param {string} args.major_version - The major version number of the binder.
 * @param {string} args.minor_version - The minor version number of the binder.
 * @param {string} args.name__v - The lifecycle name from which to retrieve entry criteria.
 * @returns {Promise<Object>} - The result of the binder entry criteria retrieval.
 */
const executeFunction = async ({ id, major_version, minor_version, name__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // assuming version is fixed as per the collection
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with path parameters
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${id}/versions/${major_version}/${minor_version}/lifecycle_actions/${name__v}/entry_requirements`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving binder entry criteria:', error);
    return {
      error: `An error occurred while retrieving binder entry criteria: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving binder entry criteria from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_binder_entry_criteria',
      description: 'Retrieve entry criteria for a binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          id: {
            type: 'string',
            description: 'The binder ID from which to retrieve entry criteria.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the binder.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the binder.'
          },
          name__v: {
            type: 'string',
            description: 'The lifecycle name from which to retrieve entry criteria.'
          }
        },
        required: ['id', 'major_version', 'minor_version', 'name__v']
      }
    }
  }
};

export { apiTool };