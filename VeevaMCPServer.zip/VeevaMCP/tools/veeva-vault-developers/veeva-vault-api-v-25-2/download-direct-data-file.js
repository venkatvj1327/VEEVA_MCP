/**
 * Function to download a Direct Data file from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.name - The name of the Direct Data file part.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @returns {Promise<Object>} - The result of the download request.
 */
const executeFunction = async ({ name, vaultDNS, version, sessionId, clientId }) => {
  const url = `https://${vaultDNS}/api/${version}/services/directdata/files/${name}`;
  
  // Set up headers for the request
  const headers = {
    'Accept': 'application/json',
    'Authorization': sessionId,
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading Direct Data file:', error);
    return {
      error: `An error occurred while downloading the Direct Data file: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading a Direct Data file from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_direct_data_file',
      description: 'Download a Direct Data file from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          name: {
            type: 'string',
            description: 'The name of the Direct Data file part.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['name', 'vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };