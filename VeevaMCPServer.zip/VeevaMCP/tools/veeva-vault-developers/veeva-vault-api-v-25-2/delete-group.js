/**
 * Function to delete a user-defined group in Veeva Vault.
 *
 * @param {Object} args - Arguments for the delete operation.
 * @param {string} args.group_id - The ID of the group to be deleted.
 * @returns {Promise<Object>} - The result of the delete operation.
 */
const executeFunction = async ({ group_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the DELETE request
    const url = `https://${vaultDNS}/api/${version}/objects/groups/${group_id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return a success message or response
    return { message: 'Group deleted successfully.' };
  } catch (error) {
    console.error('Error deleting group:', error);
    return {
      error: `An error occurred while deleting the group: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting a group in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_group',
      description: 'Delete a user-defined group in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          group_id: {
            type: 'string',
            description: 'The ID of the group to be deleted.'
          }
        },
        required: ['group_id']
      }
    }
  }
};

export { apiTool };