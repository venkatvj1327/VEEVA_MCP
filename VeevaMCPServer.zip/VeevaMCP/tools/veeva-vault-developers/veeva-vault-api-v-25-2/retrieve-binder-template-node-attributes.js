/**
 * Function to retrieve binder template node attributes from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.template_name - The binder template name__v field value.
 * @returns {Promise<Object>} - The attributes of each node of the specified binder template.
 */
const executeFunction = async ({ template_name }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/binders/templates/${template_name}/bindernodes`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving binder template node attributes:', error);
    return {
      error: `An error occurred while retrieving binder template node attributes: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving binder template node attributes from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_binder_template_node_attributes',
      description: 'Retrieve the attributes of each node of a specific binder template in your Vault.',
      parameters: {
        type: 'object',
        properties: {
          template_name: {
            type: 'string',
            description: 'The binder template name__v field value.'
          }
        },
        required: ['template_name']
      }
    }
  }
};

export { apiTool };