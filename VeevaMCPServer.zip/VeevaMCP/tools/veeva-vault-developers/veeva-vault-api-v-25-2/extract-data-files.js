/**
 * Function to extract data files from Veeva Vault.
 *
 * @param {Object} args - Arguments for the extraction.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for the request.
 * @param {Array} args.extractData - The data to extract.
 * @returns {Promise<Object>} - The result of the extraction request.
 */
const executeFunction = async ({ vaultDNS, version, sessionId, clientId, extractData }) => {
  const url = `https://${vaultDNS}/api/${version}/services/loader/extract`;
  const token = process.env.VEEVA_VAULT_DEVELOPERS_API_KEY;
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(extractData)
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error extracting data files:', error);
    return {
      error: `An error occurred while extracting data files: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for extracting data files from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'extract_data_files',
      description: 'Extract data files from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          extractData: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                object_type: { type: 'string' },
                extract_options: { type: 'string' },
                fields: { type: 'array', items: { type: 'string' } },
                vql_criteria__v: { type: 'string' },
                object: { type: 'string' }
              }
            },
            description: 'The data to extract.'
          }
        },
        required: ['vaultDNS', 'version', 'sessionId', 'clientId', 'extractData']
      }
    }
  }
};

export { apiTool };