/**
 * Function to import document annotations from a PDF to Veeva Vault.
 *
 * @param {Object} args - Arguments for the import.
 * @param {string} args.doc_id - The document ID to which the annotations will be uploaded.
 * @param {Buffer} args.file - The PDF file containing the annotations.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault instance.
 * @param {string} args.version - The API version.
 * @returns {Promise<Object>} - The result of the import operation.
 */
const executeFunction = async ({ doc_id, file, sessionId, clientId, vaultDNS, version }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/annotations/file`;
  const formData = new FormData();
  formData.append('file', file);

  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error importing document annotations:', error);
    return {
      error: `An error occurred while importing document annotations: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for importing document annotations to Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'import_document_annotations',
      description: 'Import document annotations from a PDF to Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID to which the annotations will be uploaded.'
          },
          file: {
            type: 'string',
            description: 'The PDF file containing the annotations.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault instance.'
          },
          version: {
            type: 'string',
            description: 'The API version.'
          }
        },
        required: ['doc_id', 'file', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };