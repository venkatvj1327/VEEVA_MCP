/**
 * Function to replace a document rendition in Veeva Vault.
 *
 * @param {Object} args - Arguments for the document rendition replacement.
 * @param {string} args.doc_id - The ID of the document to update.
 * @param {string} args.rendition_type - The type of rendition to replace.
 * @param {Buffer} args.file - The file data to upload as the new rendition.
 * @param {string} [args.sessionId=''] - The session ID for authentication.
 * @param {string} [args.clientId=''] - The client ID for the request.
 * @param {string} [args.vaultDNS=''] - The DNS of the Veeva Vault.
 * @param {string} [args.version='v25.2'] - The API version to use.
 * @returns {Promise<Object>} - The result of the document rendition replacement.
 */
const executeFunction = async ({ doc_id, rendition_type, file, sessionId = '', clientId = '', vaultDNS = '', version = '25.2' }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/renditions/${rendition_type}`;
  
  const formData = new FormData();
  formData.append('file', file);

  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error replacing document rendition:', error);
    return {
      error: `An error occurred while replacing the document rendition: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for replacing document renditions in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'replace_document_rendition',
      description: 'Replace a document rendition in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The ID of the document to update.'
          },
          rendition_type: {
            type: 'string',
            description: 'The type of rendition to replace.'
          },
          file: {
            type: 'string',
            description: 'The file data to upload as the new rendition.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['doc_id', 'rendition_type', 'file']
      }
    }
  }
};

export { apiTool };