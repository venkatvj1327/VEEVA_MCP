/**
 * Function to cascade delete an object record in Veeva Vault.
 *
 * @param {Object} args - Arguments for the cascade delete operation.
 * @param {string} args.object_name - The name of the object to delete.
 * @param {string} args.object_record_id - The ID of the object record to delete.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @returns {Promise<Object>} - The result of the cascade delete operation.
 */
const executeFunction = async ({ object_name, object_record_id, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  try {
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/actions/cascadedelete`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error cascading delete object record:', error);
    return {
      error: `An error occurred while cascading delete object record: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for cascading delete object record in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'cascade_delete_object_record',
      description: 'Cascade delete an object record in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object to delete.'
          },
          object_record_id: {
            type: 'string',
            description: 'The ID of the object record to delete.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          }
        },
        required: ['object_name', 'object_record_id', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };