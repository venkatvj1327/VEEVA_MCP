/**
 * Function to remove a document from a binder in Veeva Vault.
 *
 * @param {Object} args - Arguments for the removal.
 * @param {string} args.binder_id - The ID of the binder from which to remove the document.
 * @param {string} args.section_id - The ID of the document to remove from the binder.
 * @returns {Promise<Object>} - The result of the removal operation.
 */
const executeFunction = async ({ binder_id, section_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the DELETE request
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/documents/${section_id}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return a success message or response data
    return { message: 'Document removed successfully.' };
  } catch (error) {
    console.error('Error removing document from binder:', error);
    return {
      error: `An error occurred while removing the document: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for removing a document from a binder in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'remove_document_from_binder',
      description: 'Remove a document from a binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder from which to remove the document.'
          },
          section_id: {
            type: 'string',
            description: 'The ID of the document to remove from the binder.'
          }
        },
        required: ['binder_id', 'section_id']
      }
    }
  }
};

export { apiTool };