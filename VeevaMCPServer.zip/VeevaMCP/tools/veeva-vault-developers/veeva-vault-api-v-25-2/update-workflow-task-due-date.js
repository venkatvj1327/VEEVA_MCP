/**
 * Function to update the due date of a workflow task in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.task_id - The ID of the task to update.
 * @param {string} args.task_due_date__v - The new due date for the task in the format YYYY-MM-DD.
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ task_id, task_due_date__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/objectworkflows/tasks/${task_id}/actions/updateduedate`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body data
    const body = new URLSearchParams();
    body.append('task_due_date__v', task_due_date__v);

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: body.toString()
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating task due date:', error);
    return {
      error: `An error occurred while updating the task due date: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating workflow task due date in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_workflow_task_due_date',
      description: 'Update the due date of a workflow task in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          task_id: {
            type: 'string',
            description: 'The ID of the task to update.'
          },
          task_due_date__v: {
            type: 'string',
            description: 'The new due date for the task in the format YYYY-MM-DD.'
          }
        },
        required: ['task_id', 'task_due_date__v']
      }
    }
  }
};

export { apiTool };