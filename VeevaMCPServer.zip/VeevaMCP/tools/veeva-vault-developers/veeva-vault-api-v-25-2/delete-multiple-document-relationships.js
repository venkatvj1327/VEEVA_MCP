/**
 * Function to delete multiple document relationships in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID to identify the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {Buffer} args.csvData - The CSV data containing the relationships to delete.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, csvData }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/relationships/batch`;
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'text/csv',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers,
      body: csvData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error deleting document relationships:', error);
    return {
      error: `An error occurred while deleting document relationships: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting multiple document relationships in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_multiple_document_relationships',
      description: 'Delete multiple document relationships in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID to identify the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          csvData: {
            type: 'string',
            description: 'The CSV data containing the relationships to delete.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version', 'csvData']
      }
    }
  }
};

export { apiTool };