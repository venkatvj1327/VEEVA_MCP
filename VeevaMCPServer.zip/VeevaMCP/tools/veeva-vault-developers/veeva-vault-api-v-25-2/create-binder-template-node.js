/**
 * Function to create a binder template node in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating the binder template node.
 * @param {string} args.template_name - The name of the binder template.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {Buffer} args.data - The binary data to be sent as part of the request.
 * @returns {Promise<Object>} - The result of the binder template node creation.
 */
const executeFunction = async ({ template_name, sessionId, clientId, data }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/objects/binders/templates/${template_name}/bindernodes`;

  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: data
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const responseData = await response.json();
    return responseData;
  } catch (error) {
    console.error('Error creating binder template node:', error);
    return {
      error: `An error occurred while creating the binder template node: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a binder template node in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_binder_template_node',
      description: 'Create a binder template node in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          template_name: {
            type: 'string',
            description: 'The name of the binder template.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          data: {
            type: 'string',
            description: 'The binary data to be sent as part of the request.'
          }
        },
        required: ['template_name', 'sessionId', 'clientId', 'data']
      }
    }
  }
};

export { apiTool };