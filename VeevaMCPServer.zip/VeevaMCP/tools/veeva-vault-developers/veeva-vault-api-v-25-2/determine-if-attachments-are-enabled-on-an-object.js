/**
 * Function to determine if attachments are enabled on a specified object in Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.object_name - The name of the object to check for attachment capabilities.
 * @returns {Promise<Object>} - The response indicating if attachments are enabled.
 */
const executeFunction = async ({ object_name }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2';
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL
    const url = `https://${vaultDNS}/api/${version}/metadata/vobjects/${object_name}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error determining if attachments are enabled:', error);
    return {
      error: `An error occurred while determining if attachments are enabled: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for determining if attachments are enabled on an object in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'determine_attachments_enabled',
      description: 'Determine if attachments are enabled on a specified object in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object to check for attachment capabilities.'
          }
        },
        required: ['object_name']
      }
    }
  }
};

export { apiTool };