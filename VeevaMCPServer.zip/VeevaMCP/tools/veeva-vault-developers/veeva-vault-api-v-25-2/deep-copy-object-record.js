/**
 * Function to perform a deep copy of an object record in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deep copy operation.
 * @param {string} args.object_name - The object name (e.g., product__v, country__v).
 * @param {string} args.object_record_id - The ID of the object record to copy.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @returns {Promise<Object>} - The result of the deep copy operation.
 */
const executeFunction = async ({ object_name, object_record_id, sessionId, clientId, vaultDNS, version }) => {
  const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/actions/deepcopy`;
  
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error performing deep copy of object record:', error);
    return {
      error: `An error occurred while performing deep copy: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deep copying an object record in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'deep_copy_object_record',
      description: 'Perform a deep copy of an object record in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name (e.g., product__v, country__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The ID of the object record to copy.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['object_name', 'object_record_id', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };