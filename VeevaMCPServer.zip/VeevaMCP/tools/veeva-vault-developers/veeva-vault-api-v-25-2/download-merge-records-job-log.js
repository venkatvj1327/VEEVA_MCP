/**
 * Function to download the job log for a merge records job from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.job_id - The job_id of the merge records job.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault instance.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for the request.
 * @returns {Promise<Buffer>} - The job log file as a binary buffer.
 */
const executeFunction = async ({ job_id, vaultDNS, version, sessionId, clientId }) => {
  const url = `https://${vaultDNS}/api/${version}/vobjects/merges/${job_id}/log`;
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response as a buffer
    const data = await response.buffer();
    return data;
  } catch (error) {
    console.error('Error downloading job log:', error);
    throw new Error(`An error occurred while downloading the job log: ${error instanceof Error ? error.message : JSON.stringify(error)}`);
  }
};

/**
 * Tool configuration for downloading the job log for a merge records job from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_merge_records_job_log',
      description: 'Download the job log for a merge records job from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          job_id: {
            type: 'string',
            description: 'The job_id of the merge records job.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault instance.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for the request.'
          }
        },
        required: ['job_id', 'vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };