/**
 * Function to enable Configuration Mode in the currently authenticated Veeva Vault.
 *
 * @param {Object} args - Arguments for enabling Configuration Mode.
 * @param {string} args.vaultDNS - The DNS of the Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The Client ID to identify the request.
 * @returns {Promise<Object>} - The result of the enable configuration mode request.
 */
const executeFunction = async ({ vaultDNS, version, sessionId, clientId }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/services/configuration_mode/actions/enable`;
  
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error enabling Configuration Mode:', error);
    return {
      error: `An error occurred while enabling Configuration Mode: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for enabling Configuration Mode in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'enable_configuration_mode',
      description: 'Enable Configuration Mode in the currently authenticated Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The Client ID to identify the request.'
          }
        },
        required: ['vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };