/**
 * Function to retrieve user actions for a specific version of a document in Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.id - The document ID from which to retrieve available user actions.
 * @param {number} args.major_version - The major version number of the document.
 * @param {number} args.minor_version - The minor version number of the document.
 * @returns {Promise<Object>} - The result of the user actions retrieval.
 */
const executeFunction = async ({ id, major_version, minor_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${id}/versions/${major_version}/${minor_version}/lifecycle_actions`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving document user actions:', error);
    return {
      error: `An error occurred while retrieving document user actions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document user actions in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_user_actions',
      description: 'Retrieve available user actions for a specific version of a document in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          id: {
            type: 'string',
            description: 'The document ID from which to retrieve available user actions.'
          },
          major_version: {
            type: 'integer',
            description: 'The major version number of the document.'
          },
          minor_version: {
            type: 'integer',
            description: 'The minor version number of the document.'
          }
        },
        required: ['id', 'major_version', 'minor_version']
      }
    }
  }
};

export { apiTool };