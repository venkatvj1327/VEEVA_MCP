/**
 * Function to create a new draft version of a document in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating a document version.
 * @param {string} args.doc_id - The ID of the document to create a new version for.
 * @param {string} [args.createDraft] - Specify 'latestContent' to create a draft from the existing document or 'uploadedContent' to upload a new source file.
 * @param {string} [args.file] - The filepath of the source document. Required if createDraft is 'uploadedContent'.
 * @param {string} [args.description__v] - Optional description for the new draft version.
 * @param {boolean} [args.suppressRendition] - Set to true to suppress automatic generation of the viewable rendition.
 * @returns {Promise<Object>} - The result of the document version creation.
 */
const executeFunction = async ({ doc_id, createDraft, file, description__v, suppressRendition }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}`;
  
  const formData = new FormData();
  if (createDraft) formData.append('createDraft', createDraft);
  if (file) formData.append('file', file);
  if (description__v) formData.append('description__v', description__v);
  if (suppressRendition) formData.append('suppressRendition', suppressRendition);

  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating document version:', error);
    return {
      error: `An error occurred while creating the document version: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a new draft version of a document in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_document_version',
      description: 'Create a new draft version of a document in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The ID of the document to create a new version for.'
          },
          createDraft: {
            type: 'string',
            enum: ['latestContent', 'uploadedContent'],
            description: 'Specify how to create the draft version.'
          },
          file: {
            type: 'string',
            description: 'The filepath of the source document.'
          },
          description__v: {
            type: 'string',
            description: 'Optional description for the new draft version.'
          },
          suppressRendition: {
            type: 'boolean',
            description: 'Set to true to suppress automatic generation of the viewable rendition.'
          }
        },
        required: ['doc_id']
      }
    }
  }
};

export { apiTool };