/**
 * Function to delete a document version rendition in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.major_version - The major version number of the document.
 * @param {string} args.minor_version - The minor version number of the document.
 * @param {string} args.rendition_type - The type of rendition to delete.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ doc_id, major_version, minor_version, rendition_type }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the DELETE request
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/versions/${major_version}/${minor_version}/renditions/${rendition_type}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return the response data
    return await response.json();
  } catch (error) {
    console.error('Error deleting document version rendition:', error);
    return {
      error: `An error occurred while deleting the document version rendition: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting a document version rendition in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_document_version_rendition',
      description: 'Delete a document version rendition in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the document.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the document.'
          },
          rendition_type: {
            type: 'string',
            description: 'The type of rendition to delete.'
          }
        },
        required: ['doc_id', 'major_version', 'minor_version', 'rendition_type']
      }
    }
  }
};

export { apiTool };