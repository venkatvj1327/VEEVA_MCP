/**
 * Function to retrieve auto managed groups from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {number} [args.limit=1000] - The maximum number of records per page (1-1000).
 * @param {number} [args.offset=0] - The offset for pagination.
 * @returns {Promise<Object>} - The result of the retrieval of auto managed groups.
 */
const executeFunction = async ({ limit = 1000, offset = 0 }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with query parameters
    const url = new URL(`https://${vaultDNS}/api/${version}/objects/groups/auto`);
    if (limit) url.searchParams.append('limit', limit.toString());
    if (offset) url.searchParams.append('offset', offset.toString());

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving auto managed groups:', error);
    return {
      error: `An error occurred while retrieving auto managed groups: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving auto managed groups from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_auto_managed_groups',
      description: 'Retrieve all Auto Managed groups from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          limit: {
            type: 'integer',
            description: 'The maximum number of records per page (1-1000).'
          },
          offset: {
            type: 'integer',
            description: 'The offset for pagination.'
          }
        },
        required: []
      }
    }
  }
};

export { apiTool };