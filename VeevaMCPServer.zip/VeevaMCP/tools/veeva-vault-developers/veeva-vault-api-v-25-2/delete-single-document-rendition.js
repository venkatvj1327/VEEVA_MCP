/**
 * Function to delete a single document rendition in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.doc_id - The document ID of the rendition to delete.
 * @param {string} args.rendition_type - The type of the rendition to delete.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ doc_id, rendition_type }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the API request
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/renditions/${rendition_type}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'DELETE',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Return success response
    return { message: 'Document rendition deleted successfully.' };
  } catch (error) {
    console.error('Error deleting document rendition:', error);
    return {
      error: `An error occurred while deleting the document rendition: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting a document rendition in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_document_rendition',
      description: 'Delete a single document rendition in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID of the rendition to delete.'
          },
          rendition_type: {
            type: 'string',
            description: 'The type of the rendition to delete.'
          }
        },
        required: ['doc_id', 'rendition_type']
      }
    }
  }
};

export { apiTool };