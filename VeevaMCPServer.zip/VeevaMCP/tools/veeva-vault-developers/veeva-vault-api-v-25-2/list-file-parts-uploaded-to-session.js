/**
 * Function to list file parts uploaded to a session in Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.upload_session_id - The ID of the upload session.
 * @param {number} [args.limit=1000] - Optional: The maximum number of items per page in the response.
 * @returns {Promise<Object>} - The result of the file parts listing.
 */
const executeFunction = async ({ upload_session_id, limit = 1000 }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL with the upload session ID
    const url = `https://${vaultDNS}/api/${version}/services/file_staging/upload/${upload_session_id}/parts`;
    
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Add query parameters if limit is provided
    const queryParams = new URLSearchParams();
    if (limit) {
      queryParams.append('limit', limit);
    }

    // Perform the fetch request
    const response = await fetch(`${url}?${queryParams.toString()}`, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error listing file parts:', error);
    return {
      error: `An error occurred while listing file parts: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for listing file parts uploaded to a session in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'list_file_parts_uploaded_to_session',
      description: 'List file parts uploaded to a session in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          upload_session_id: {
            type: 'string',
            description: 'The ID of the upload session.'
          },
          limit: {
            type: 'integer',
            description: 'Optional: The maximum number of items per page in the response.'
          }
        },
        required: ['upload_session_id']
      }
    }
  }
};

export { apiTool };