/**
 * Function to retrieve document attachment version metadata from Veeva Vault.
 *
 * @param {Object} args - Arguments for the retrieval.
 * @param {string} args.doc_id - The document ID.
 * @param {string} args.attachment_id - The attachment ID.
 * @param {string} args.attachment_version - The attachment version.
 * @returns {Promise<Object>} - The metadata of the document attachment version.
 */
const executeFunction = async ({ doc_id, attachment_id, attachment_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  try {
    // Construct the URL with path variables
    const url = `https://${vaultDNS}/api/${version}/objects/documents/${doc_id}/attachments/${attachment_id}/versions/${attachment_version}`;

    // Set up headers for the request
    const headers = {
      'Accept': 'application/json',
      'Authorization': sessionId,
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving document attachment version metadata:', error);
    return {
      error: `An error occurred while retrieving document attachment version metadata: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving document attachment version metadata from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_document_attachment_version_metadata',
      description: 'Retrieve document attachment version metadata from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          doc_id: {
            type: 'string',
            description: 'The document ID.'
          },
          attachment_id: {
            type: 'string',
            description: 'The attachment ID.'
          },
          attachment_version: {
            type: 'string',
            description: 'The attachment version.'
          }
        },
        required: ['doc_id', 'attachment_id', 'attachment_version']
      }
    }
  }
};

export { apiTool };