/**
 * Function to deep copy an object record in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deep copy operation.
 * @param {string} args.object_name - The name of the object to copy (e.g., product__v, country__v).
 * @param {string} args.object_record_id - The ID of the object record to copy.
 * @param {Object} args.copyData - The data for the copied record.
 * @returns {Promise<Object>} - The result of the deep copy operation.
 */
const executeFunction = async ({ object_name, object_record_id, copyData }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/actions/deepcopy`;

    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'X-VaultAPI-ClientID': clientId,
    };

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(copyData),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error deep copying object record:', error);
    return {
      error: `An error occurred while deep copying the object record: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deep copying object records in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'deep_copy_object_record',
      description: 'Deep copy an object record in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The name of the object to copy (e.g., product__v, country__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The ID of the object record to copy.'
          },
          copyData: {
            type: 'object',
            description: 'The data for the copied record.',
            properties: {
              name__v: {
                type: 'string',
                description: 'The name of the copied record.'
              },
              external_id__v: {
                type: 'string',
                description: 'The external ID for the copied record.'
              }
            },
            required: ['name__v']
          }
        },
        required: ['object_name', 'object_record_id', 'copyData']
      }
    }
  }
};

export { apiTool };