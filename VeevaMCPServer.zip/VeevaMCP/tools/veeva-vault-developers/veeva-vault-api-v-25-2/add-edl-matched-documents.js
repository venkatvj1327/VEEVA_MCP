/**
 * Function to add matched documents to EDL Items in Veeva Vault.
 *
 * @param {Object} args - Arguments for adding matched documents.
 * @param {Array<Object>} args.documents - An array of documents to be added.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @returns {Promise<Object>} - The result of the add matched documents operation.
 */
const executeFunction = async ({ documents, sessionId, clientId, vaultDNS, version }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/edl_matched_documents/batch/actions/add`;
  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(documents)
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error adding matched documents:', error);
    return {
      error: `An error occurred while adding matched documents: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for adding matched documents to EDL Items in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'add_edl_matched_documents',
      description: 'Add matched documents to EDL Items in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          documents: {
            type: 'array',
            description: 'An array of documents to be added.',
            items: {
              type: 'object',
              properties: {
                id: {
                  type: 'string',
                  description: 'The ID of the document.'
                },
                document_id: {
                  type: 'string',
                  description: 'The document ID associated with the EDL item.'
                },
                major_version_number__v: {
                  type: 'integer',
                  description: 'The major version number of the document.'
                },
                minor_version_number__v: {
                  type: 'integer',
                  description: 'The minor version number of the document.'
                },
                lock: {
                  type: 'boolean',
                  description: 'Indicates whether the document is locked.'
                }
              },
              required: ['id', 'document_id', 'major_version_number__v', 'minor_version_number__v', 'lock']
            }
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['documents', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };