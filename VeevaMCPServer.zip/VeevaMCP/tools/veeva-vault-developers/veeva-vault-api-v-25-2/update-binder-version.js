/**
 * Function to update the version of a binder in Veeva Vault.
 *
 * @param {Object} args - Arguments for the update.
 * @param {string} args.binder_id - The ID of the binder to update.
 * @param {string} args.major_version - The major version number of the binder.
 * @param {string} args.minor_version - The minor version number of the binder.
 * @param {string} [args.name__v] - The new name for the binder (optional).
 * @returns {Promise<Object>} - The result of the update operation.
 */
const executeFunction = async ({ binder_id, major_version, minor_version, name__v }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the request
    const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/versions/${major_version}/${minor_version}`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Prepare the body data
    const bodyData = new URLSearchParams();
    if (name__v) {
      bodyData.append('name__v', name__v);
    }

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'PUT',
      headers,
      body: bodyData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error updating binder version:', error);
    return {
      error: `An error occurred while updating the binder version: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for updating binder versions in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'update_binder_version',
      description: 'Update the version of a binder in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The ID of the binder to update.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the binder.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the binder.'
          },
          name__v: {
            type: 'string',
            description: 'The new name for the binder (optional).'
          }
        },
        required: ['binder_id', 'major_version', 'minor_version']
      }
    }
  }
};

export { apiTool };