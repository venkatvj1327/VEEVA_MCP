/**
 * Function to create a binder relationship in Veeva Vault.
 *
 * @param {Object} args - Arguments for creating the binder relationship.
 * @param {string} args.binder_id - The binder ID to which the relationship will be established.
 * @param {string} args.major_version - The major version number of the binder.
 * @param {string} args.minor_version - The minor version number of the binder.
 * @param {string} args.target_doc_id - The document ID of the target document.
 * @param {string} args.relationship_type - The type of relationship to establish.
 * @param {string} [args.target_major_version] - The major version number of the target document (optional).
 * @param {string} [args.target_minor_version] - The minor version number of the target document (optional).
 * @returns {Promise<Object>} - The result of the binder relationship creation.
 */
const executeFunction = async ({ binder_id, major_version, minor_version, target_doc_id, relationship_type, target_major_version, target_minor_version }) => {
  const vaultDNS = ''; // will be provided by the user
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user
  const version = 'v25.2'; // API version

  const url = `https://${vaultDNS}/api/${version}/objects/binders/${binder_id}/versions/${major_version}/${minor_version}/relationships`;

  // Prepare the form data
  const formData = new URLSearchParams();
  formData.append('target_doc_id__v', target_doc_id);
  formData.append('relationship_type__v', relationship_type);
  if (target_major_version) {
    formData.append('target_major_version__v', target_major_version);
  }
  if (target_minor_version) {
    formData.append('target_minor_version__v', target_minor_version);
  }

  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: formData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating binder relationship:', error);
    return {
      error: `An error occurred while creating the binder relationship: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for creating a binder relationship in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'create_binder_relationship',
      description: 'Create a binder relationship in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          binder_id: {
            type: 'string',
            description: 'The binder ID to which the relationship will be established.'
          },
          major_version: {
            type: 'string',
            description: 'The major version number of the binder.'
          },
          minor_version: {
            type: 'string',
            description: 'The minor version number of the binder.'
          },
          target_doc_id: {
            type: 'string',
            description: 'The document ID of the target document.'
          },
          relationship_type: {
            type: 'string',
            description: 'The type of relationship to establish.'
          },
          target_major_version: {
            type: 'string',
            description: 'The major version number of the target document (optional).'
          },
          target_minor_version: {
            type: 'string',
            description: 'The minor version number of the target document (optional).'
          }
        },
        required: ['binder_id', 'major_version', 'minor_version', 'target_doc_id', 'relationship_type']
      }
    }
  }
};

export { apiTool };