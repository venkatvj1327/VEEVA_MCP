/**
 * Function to generate a Vault Configuration Report in Veeva Vault.
 *
 * @param {Object} args - Arguments for generating the report.
 * @param {boolean} [args.include_vault_settings=true] - To exclude Vault Settings for comparison.
 * @param {boolean} [args.include_inactive_components=false] - Include inactive components in the report.
 * @param {string} [args.include_components_modified_since] - Only include components modified since the specified date (yyyy-mm-dd).
 * @param {boolean} [args.include_doc_binder_templates=true] - To exclude document and binder templates.
 * @param {boolean} [args.suppress_empty_results=false] - Exclude tabs with only header rows from the report.
 * @param {string} [args.component_types] - Comma separated list of component types to include.
 * @param {string} [args.output_format='Excel_Macro_Enabled'] - Output report format (Excel or Excel_Macro_Enabled).
 * @returns {Promise<Object>} - The result of the report generation.
 */
const executeFunction = async ({
  include_vault_settings = true,
  include_inactive_components = false,
  include_components_modified_since,
  include_doc_binder_templates = true,
  suppress_empty_results = false,
  component_types,
  output_format = 'Excel_Macro_Enabled'
}) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  const url = `https://${vaultDNS}/api/${version}/objects/vault/actions/configreport`;

  const params = new URLSearchParams();
  params.append('include_vault_settings', include_vault_settings);
  params.append('include_inactive_components', include_inactive_components);
  if (include_components_modified_since) {
    params.append('include_components_modified_since', include_components_modified_since);
  }
  params.append('include_doc_binder_templates', include_doc_binder_templates);
  params.append('suppress_empty_results', suppress_empty_results);
  if (component_types) {
    params.append('component_types', component_types);
  }
  params.append('output_format', output_format);

  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/x-www-form-urlencoded',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body: params
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error generating Vault Configuration Report:', error);
    return {
      error: `An error occurred while generating the report: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for generating a Vault Configuration Report in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'generate_vault_configuration_report',
      description: 'Generate a Vault Configuration Report in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          include_vault_settings: {
            type: 'boolean',
            description: 'To exclude Vault Settings for comparison.'
          },
          include_inactive_components: {
            type: 'boolean',
            description: 'Include inactive components in the report.'
          },
          include_components_modified_since: {
            type: 'string',
            description: 'Only include components modified since the specified date (yyyy-mm-dd).'
          },
          include_doc_binder_templates: {
            type: 'boolean',
            description: 'To exclude document and binder templates.'
          },
          suppress_empty_results: {
            type: 'boolean',
            description: 'Exclude tabs with only header rows from the report.'
          },
          component_types: {
            type: 'string',
            description: 'Comma separated list of component types to include.'
          },
          output_format: {
            type: 'string',
            description: 'Output report format (Excel or Excel_Macro_Enabled).'
          }
        }
      }
    }
  }
};

export { apiTool };