/**
 * Function to change the password for the currently authenticated user in Veeva Vault.
 *
 * @param {Object} args - Arguments for changing the password.
 * @param {string} args.password - The current password of the user.
 * @param {string} args.new_password - The new password to set for the user.
 * @returns {Promise<Object>} - The result of the password change operation.
 */
const executeFunction = async ({ password, new_password }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    const url = `https://${vaultDNS}/api/${version}/objects/users/me/password`;

    // Prepare the request body
    const body = new URLSearchParams();
    body.append('password__v', password);
    body.append('new_password__v', new_password);

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Content-Type': 'application/x-www-form-urlencoded',
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers,
      body
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error changing password:', error);
    return {
      error: `An error occurred while changing the password: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for changing the user password in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'change_user_password',
      description: 'Change the password for the currently authenticated user in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          password: {
            type: 'string',
            description: 'The current password of the user.'
          },
          new_password: {
            type: 'string',
            description: 'The new password to set for the user.'
          }
        },
        required: ['password', 'new_password']
      }
    }
  }
};

export { apiTool };