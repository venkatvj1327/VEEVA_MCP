/**
 * Function to download all object record attachment files from Veeva Vault.
 *
 * @param {Object} args - Arguments for the download.
 * @param {string} args.object_name - The object name (e.g., product__v, country__v).
 * @param {string} args.object_record_id - The object record ID.
 * @returns {Promise<Object>} - The response from the Veeva Vault API.
 */
const executeFunction = async ({ object_name, object_record_id }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const sessionId = ''; // will be provided by the user
  const clientId = ''; // will be provided by the user

  try {
    // Construct the URL for the API request
    const url = `https://${vaultDNS}/api/${version}/vobjects/${object_name}/${object_record_id}/attachments/file`;

    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'application/json',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(url, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error downloading attachment files:', error);
    return {
      error: `An error occurred while downloading attachment files: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for downloading object record attachment files from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'download_object_record_attachments',
      description: 'Download all object record attachment files from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          object_name: {
            type: 'string',
            description: 'The object name (e.g., product__v, country__v).'
          },
          object_record_id: {
            type: 'string',
            description: 'The object record ID.'
          }
        },
        required: ['object_name', 'object_record_id']
      }
    }
  }
};

export { apiTool };