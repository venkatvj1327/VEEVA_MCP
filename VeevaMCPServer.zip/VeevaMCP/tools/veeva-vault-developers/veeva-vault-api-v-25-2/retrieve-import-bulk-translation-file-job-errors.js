/**
 * Function to retrieve errors from an Import Bulk Translation File job in Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.job_id - The ID of the requested import job.
 * @param {string} args.sessionId - The session ID for authentication.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault instance.
 * @param {string} args.version - The API version to use.
 * @returns {Promise<Object>} - The result of the error retrieval request.
 */
const executeFunction = async ({ job_id, sessionId, clientId, vaultDNS, version }) => {
  const baseUrl = `https://${vaultDNS}/api/${version}/services/jobs/${job_id}/errors`;
  const token = process.env.VEEVA_VAULT_DEVELOPERS_API_KEY;
  try {
    // Set up headers for the request
    const headers = {
      'Authorization': sessionId,
      'Accept': 'text/csv',
      'X-VaultAPI-ClientID': clientId
    };

    // Perform the fetch request
    const response = await fetch(baseUrl, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(errorData);
    }

    // Parse and return the response data
    const data = await response.text();
    return data;
  } catch (error) {
    console.error('Error retrieving job errors:', error);
    return {
      error: `An error occurred while retrieving job errors: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving Import Bulk Translation File job errors in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_import_bulk_translation_file_job_errors',
      description: 'Retrieve errors from an Import Bulk Translation File job in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          job_id: {
            type: 'string',
            description: 'The ID of the requested import job.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authentication.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault instance.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          }
        },
        required: ['job_id', 'sessionId', 'clientId', 'vaultDNS', 'version']
      }
    }
  }
};

export { apiTool };