/**
 * Function to delete multiple document versions in Veeva Vault.
 *
 * @param {Object} args - Arguments for the deletion.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.idParam - Optional external ID for identifying documents.
 * @param {string} args.csvData - The CSV data containing document versions to delete.
 * @returns {Promise<Object>} - The result of the deletion operation.
 */
const executeFunction = async ({ sessionId, clientId, vaultDNS, version, idParam, csvData }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/documents/versions/batch`;
  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'text/csv',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    const response = await fetch(url, {
      method: 'DELETE',
      headers,
      body: csvData
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error deleting document versions:', error);
    return {
      error: `An error occurred while deleting document versions: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for deleting multiple document versions in Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'delete_multiple_document_versions',
      description: 'Delete multiple document versions in Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          idParam: {
            type: 'string',
            description: 'Optional external ID for identifying documents.'
          },
          csvData: {
            type: 'string',
            description: 'The CSV data containing document versions to delete.'
          }
        },
        required: ['sessionId', 'clientId', 'vaultDNS', 'version', 'csvData']
      }
    }
  }
};

export { apiTool };