/**
 * Function to retrieve all groups from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.vaultDNS - The DNS of the Veeva Vault.
 * @param {string} args.version - The API version to use.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @param {boolean} [args.includeImplied=false] - Whether to include implied members in the response.
 * @returns {Promise<Object>} - The response containing the groups.
 */
const executeFunction = async ({ vaultDNS, version, sessionId, clientId, includeImplied = false }) => {
  const url = `https://${vaultDNS}/api/${version}/objects/groups`;
  const headers = {
    'Authorization': sessionId,
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  // Add query parameters if needed
  const queryParams = new URLSearchParams();
  if (includeImplied) {
    queryParams.append('includeImplied', 'true');
  }

  try {
    const response = await fetch(`${url}?${queryParams.toString()}`, {
      method: 'GET',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving groups:', error);
    return {
      error: `An error occurred while retrieving groups: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving all groups from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_all_groups',
      description: 'Retrieve all groups from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          vaultDNS: {
            type: 'string',
            description: 'The DNS of the Veeva Vault.'
          },
          version: {
            type: 'string',
            description: 'The API version to use.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          },
          includeImplied: {
            type: 'boolean',
            description: 'Whether to include implied members in the response.'
          }
        },
        required: ['vaultDNS', 'version', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };