/**
 * Function to retrieve specific root nodes from Veeva Vault.
 *
 * @param {Object} args - Arguments for the request.
 * @param {string} args.edl_hierarchy_or_template - The EDL hierarchy or template to retrieve nodes for.
 * @param {string} args.sessionId - The session ID for authorization.
 * @param {string} args.clientId - The client ID for identifying the request.
 * @returns {Promise<Object>} - The result of the root nodes retrieval.
 */
const executeFunction = async ({ edl_hierarchy_or_template, sessionId, clientId }) => {
  const vaultDNS = ''; // will be provided by the user
  const version = 'v25.2'; // API version
  const url = `https://${vaultDNS}/api/${version}/composites/trees/${edl_hierarchy_or_template}/actions/listnodes`;

  // Set up headers for the request
  const headers = {
    'Authorization': sessionId,
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-VaultAPI-ClientID': clientId
  };

  try {
    // Perform the fetch request
    const response = await fetch(url, {
      method: 'POST',
      headers
    });

    // Check if the response was successful
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(JSON.stringify(errorData));
    }

    // Parse and return the response data
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error retrieving root nodes:', error);
    return {
      error: `An error occurred while retrieving root nodes: ${error instanceof Error ? error.message : JSON.stringify(error)}`
    };
  }
};

/**
 * Tool configuration for retrieving specific root nodes from Veeva Vault.
 * @type {Object}
 */
const apiTool = {
  function: executeFunction,
  definition: {
    type: 'function',
    function: {
      name: 'retrieve_specific_root_nodes',
      description: 'Retrieve specific root nodes from Veeva Vault.',
      parameters: {
        type: 'object',
        properties: {
          edl_hierarchy_or_template: {
            type: 'string',
            description: 'The EDL hierarchy or template to retrieve nodes for.'
          },
          sessionId: {
            type: 'string',
            description: 'The session ID for authorization.'
          },
          clientId: {
            type: 'string',
            description: 'The client ID for identifying the request.'
          }
        },
        required: ['edl_hierarchy_or_template', 'sessionId', 'clientId']
      }
    }
  }
};

export { apiTool };