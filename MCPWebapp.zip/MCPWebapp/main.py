from fastapi import FastAPI
from pydantic import BaseModel
from llm_client import get_llm
from mcp_client import call_mcp
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
 
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")

llm = get_llm()
 
SYSTEM_PROMPT = "You are a helpful assistant"
 
class QueryRequest(BaseModel):
    query: str
 
@app.post("/ask")
async def ask(request: QueryRequest):
    # Step 1: Call MCP with user query
    mcp_result = await call_mcp(request.query)
 
    # Step 2: Pass result to LLM with system prompt
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"User asked: {request.query}"},
        {"role": "assistant", "content": f"MCP responded: {mcp_result}"}
    ]
 
    llm_response = llm.invoke(messages)
 
    return {"answer": llm_response.content}