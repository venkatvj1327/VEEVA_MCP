import httpx
 
MCP_SERVER_URL = "http://127.0.0.1:3001/mcp"
 
async def call_mcp(query: str) -> str:
    """
    Calls the MCP server with a user query.
    """
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(MCP_SERVER_URL, json={"query": query})
            response.raise_for_status()
            return response.json().get("result", "No response from MCP")
        except Exception as e:
            return f"Error calling MCP: {str(e)}"