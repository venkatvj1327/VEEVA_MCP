import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
 
# Load environment variables
load_dotenv()
 
def get_llm():
    return ChatOpenAI(
        base_url="https://router.huggingface.co/v1",
        api_key=os.getenv("HUGGINGFACEHUB_ACCESS_TOKEN"),
        model="openai/gpt-oss-120b:cerebras"
    )