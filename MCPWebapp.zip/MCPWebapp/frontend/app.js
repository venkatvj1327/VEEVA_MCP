async function sendQuery() {
  const query = document.getElementById("query").value;
  const responseDiv = document.getElementById("response");
  responseDiv.innerText = "Thinking...";
 
  try {
    const res = await fetch("/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: query })
    });
 
    if (!res.ok) {
      throw new Error(`HTTP error! status: ${res.status}`);
    }
 
    const data = await res.json();
    responseDiv.innerText = data.answer;
  } catch (err) {
    responseDiv.innerText = "Error: " + err.message;
  }
}